<?php
/*******************************************************************************
 * Copyright (c) 2018, WP Popup Maker
 ******************************************************************************/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Implements a batch processor for migrating existing popups to new data structure.
 *
 * @since 1.1.0
 *
 * @see   PUM_Abstract_Upgrade_Popups
 */
class PUM_TC_Upgrade_v1_1_Popups extends PUM_Abstract_Upgrade_Popups {

	/**
	 * Batch process ID.
	 *
	 * @var    string
	 */
	public $batch_id = 'tc-v1_1-popups';

	/**
	 * Only load popups with specific meta keys.r
	 *
	 * @return array
	 */
	public function custom_query_args() {
		return array(
			'meta_query' => array(
				'relation' => 'OR',
				array(
					'key'     => 'popup_terms_conditions_enabled',
					'compare' => 'EXISTS',
				),
			),
		);
	}

	/**
	 * Strips out prefixes.
	 *
	 * @param PUM_Model_Popup $popup
	 *
	 * @return array
	 */
	public function get_old_meta( $popup ) {
		$defaults = array(
			'enabled'           => null,
			'checkbox_style'    => 'classic',
			'agree_text'        => __( 'I Agree', 'popup-maker-terms-conditions-popups' ),
			'force_read'        => null,
			'force_read_notice' => __( 'You need to read to the bottom of these terms and conditions before you can continue.', 'popup-maker-terms-conditions-popups' ),
			'force_agree'       => null,
			'cookie_time'       => '1 month',
			'cookie_path'       => '/',
			'cookie_key'        => '',
			'defaults_set'      => true,
		);

		$data = array();

		foreach( $defaults as $key => $value ) {
			$old_value =  $popup->get_meta( 'popup_terms_conditions_' . $key );
			$data[ $key ] = ! empty( $old_value ) ? $old_value : $value;
		}

		return $data;
	}

	/**
	 * @param $content
	 *
	 * @return array
	 */
	public function get_shortcodes_from_content( $content ) {
		$pattern    = get_shortcode_regex();
		$shortcodes = array();
		if ( preg_match_all( '/' . $pattern . '/s', $content, $matches ) ) {
			foreach ( $matches[0] as $key => $value ) {
				$shortcodes[ $key ] = array(
					'full_text' => $value,
					'tag'       => $matches[2][ $key ],
					'atts'      => shortcode_parse_atts( $matches[3][ $key ] ),
					'content'   => $matches[5][ $key ],
				);

				if ( ! empty( $shortcodes[ $key ]['atts'] ) ) {
					foreach ( $shortcodes[ $key ]['atts'] as $attr_name => $attr_value ) {
						// Filter numeric keys as they are valueless/truthy attributes.
						if ( is_numeric( $attr_name ) ) {
							$shortcodes[ $key ]['atts'][ $attr_value ] = true;
							unset( $shortcodes[ $key ]['atts'] );
						}
					}
				}
			}
		}

		return $shortcodes;
	}

	/**
	 * Process needed upgrades on each popup.
	 *
	 * @param int $popup_id
	 */
	public function process_popup( $popup_id = 0 ) {

		$popup = pum_get_popup( $popup_id );

		$tc = $this->get_old_meta( $popup );

		if ( ! $tc || empty( $tc['enabled'] ) || ! $tc['enabled'] ) {
			return;
		}

		if ( has_shortcode( $popup->post_content, 'terms_conditions' ) || has_shortcode( $popup->post_content, 'terms-conditions' ) ) {

			$shortcode_atts = array();
			if ( $tc['force_read'] ) {
				$shortcode_atts['force_read'] = true;
				if ( ! empty( $tc['force_read_notice'] ) ) {
					$shortcode_atts['force_read_notice'] = $tc['force_read_notice'];
				}
			}

			$shortcode_atts['agree_text']     = $tc['agree_text'];
			$shortcode_atts['checkbox_style'] = $tc['checkbox_style'];

			$new_shortcode_atts = array();

			if ( ! empty( $shortcode_atts ) ) {
				foreach ( $shortcode_atts as $key => $value ) {


					if ( $value === true ) {
						$new_shortcode_atts[] = $key;
					} else {
						$new_shortcode_atts[] = $key . '="' . $value . '"';
					}
				}
			}

			$new_shortcode_prefix = "[pum_terms_box " . implode( ' ', $new_shortcode_atts ) . " ";
			$new_shortcode_suffix = '[/pum_terms_box';

			$popup->post_content = str_replace( "[terms_conditions", $new_shortcode_prefix, $popup->post_content );
			$popup->post_content = str_replace( "[terms-conditions", $new_shortcode_prefix, $popup->post_content );
			$popup->post_content = str_replace( "[/terms_conditions", $new_shortcode_suffix, $popup->post_content );
			$popup->post_content = str_replace( "[/terms-conditions", $new_shortcode_suffix, $popup->post_content );

		}

		$settings = $popup->get_settings();

		// Set the new cookie name.
		$cookie_name = 'popmake-terms-conditions-' . $popup->ID . ( ! empty( $tc['cookie_key'] ) ? '-' . $tc['cookie_key'] : '' );

		// Add the new cookie to the cookies array.
		$settings['cookies'][] = array(
			'event'    => 'agreed_to_terms',
			'settings' => array(
				'name'    => $cookie_name,
				'key'     => '',
				'time'    => $tc['cookie_time'],
				'path'    => isset( $tc['cookie_path'] ) ? 1 : 0,
				'session' => isset( $tc['session_cookie'] ) ? 1 : 0,
			),
		);

		// Add the new auto open trigger to the triggers array.
		if ( $tc['force_agree'] ) {
			$settings['triggers'][] = array(
				'type'     => 'force_agreement',
				'settings' => array(
					'cookie_name' => array( $cookie_name ),
				),
			);
		} else {
			// Replace the click trigger if it exists with a click blocking trigger.

			$click_block_trigger = array(
				'type' => 'click_block',
				'settings' => array(
					'extra_selector' => '',
					'requirements' => array(
						'agree_to_terms' => 'agree_to_terms',
					),
					'cookie_name' => array( $cookie_name ),
				)
			);

			if ( ! $popup->has_trigger( 'click_open' ) ) {
				$settings['triggers'][] = $click_block_trigger;
			} else {
				foreach ( $settings['triggers'] as $key => $trigger ) {
					if (  $trigger['type'] == 'click_open' ) {
						$click_block_trigger['settings']['extra_selector'] = $trigger['settings']['extra_selector'];
						$click_block_trigger['settings']['cookie_name'] = array_merge( $click_block_trigger['settings']['cookie_name'], $trigger['settings']['cookie_name'] );
						$settings['triggers'][ $key ] = $click_block_trigger;
					}
				}
			}
		}

		$popup->save();
		$popup->update_settings( $settings );
		$this->clean_up_old_meta( $popup_id );
	}

	/**
	 * @param int $popup_id
	 */
	public function clean_up_old_meta( $popup_id = 0 ) {
		global $wpdb;

		$meta_keys = implode( "','", array(
			'popup_terms_conditions_defaults_set',
			'popup_terms_conditions_cookie_key',
			'popup_terms_conditions_cookie_path',
			'popup_terms_conditions_cookie_time',
			'popup_terms_conditions_force_read_notice',
			'popup_terms_conditions_force_read',
			'popup_terms_conditions_force_agree',
			'popup_terms_conditions_agree_text',
			'popup_terms_conditions_checkbox_style',
			'popup_terms_conditions_enabled',
		) );

		$wpdb->query( "DELETE FROM $wpdb->postmeta WHERE post_id = ". (int) $popup_id ." AND meta_key IN('$meta_keys');" );
	}


	/**
	 *
	 */
	public function finish() {
	}
}
