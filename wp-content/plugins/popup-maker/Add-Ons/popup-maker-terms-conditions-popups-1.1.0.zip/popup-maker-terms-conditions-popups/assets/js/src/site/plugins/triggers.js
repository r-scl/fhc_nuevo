(function ($) {
    "use strict";

    $.extend($.fn.popmake.triggers, {
        force_agreement: function (settings) {
            var $popup = PUM.getPopup(this);

            // If the popup is already open return.
            if ($popup.popmake('state', 'isOpen')) {
                return;
            }

            // If cookie exists or conditions fail return.
            if ($popup.popmake('checkCookies', settings) || !$popup.popmake('checkConditions')) {
                return;
            }

            // Set the global last open trigger to the a text description of the trigger.
            $.fn.popmake.last_open_trigger = 'Force Terms Agreement';

            $popup.popmake('open');
        }
    });

}(window.jQuery));