(function ($) {
    "use strict";

    $.extend($.fn.popmake.cookies, {
        agreed_to_terms: function (settings) {
            var $popup = PUM.getPopup(this);
            $popup.find('.pum-tc-box__checkbox')
                .on('pumAgreedToTerms', function () {
                    $popup.popmake('setCookie', settings);
                });
        }
    });

}(window.jQuery));