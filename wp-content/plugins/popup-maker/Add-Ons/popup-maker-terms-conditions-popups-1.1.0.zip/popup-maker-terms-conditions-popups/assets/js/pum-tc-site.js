(function ($) {
    "use strict";

    if ($.fn.popmake.triggers.click_block === undefined) {

        $.fn.popmake.blocked_trigger = null;

        /**
         * Add click_block triggers to the list of click trigger types.
         *
         * @see PUM.disableClickTriggers
         */
        pum.hooks.addFilter('pum.disableClickTriggers.clickTriggerTypes', function (clickTriggerTypes) {
            clickTriggerTypes.push('click_block');
            return clickTriggerTypes;
        });

        /**
         * Register the click_block trigger.
         */
        $.fn.popmake.triggers = $.extend($.fn.popmake.triggers, {
            click_block: function (triggerSettings) {
                triggerSettings = $.extend({}, {
                    requirements: {}
                }, triggerSettings);

                var $popup = PUM.getPopup(this),
                    triggerSelector = PUM.getClickTriggerSelector(this, triggerSettings);


                $(triggerSelector)
                    .addClass('pum-trigger')
                    .css({cursor: "pointer"});


                $(document)
                    .off('click.pumTrigger', triggerSelector)
                    .on('click.pumBlockAction', triggerSelector, function (event) {
                        var $trigger = $(this),
                            allowed = true;

                        // If trigger is inside of the popup that it opens, do nothing.
                        if ($popup.has($trigger).length > 0) {
                            return;
                        }

                        // If the popup is already open return.
                        if ($popup.popmake('state', 'isOpen')) {
                            return;
                        }

                        if (triggerSettings.requirements === undefined) {
                            return;
                        }

                        for (var key in triggerSettings.requirements) {
                            if (!triggerSettings.requirements.hasOwnProperty(key)) {
                                continue;
                            }

                            if (!pum.hooks.applyFilters('pum.trigger.click_block.allowed.' + key, true, triggerSettings, $popup)) {
                                allowed = false;
                            }
                        }

                        // If cookie exists or conditions fail return.
                        if (allowed || $popup.popmake('checkCookies', triggerSettings) || !$popup.popmake('checkConditions')) {
                            return;
                        }

                        event.stopPropagation();
                        event.preventDefault();

                        // Set the global last open trigger to the clicked element.
                        $.fn.popmake.last_open_trigger = $trigger;

                        $.fn.popmake.blocked_trigger = $trigger;

                        // Open the popup.
                        $popup.popmake('open');
                    });
            }
        });

        /**
         * After a popup closes, check if there was a blocked trigger that has the reclick attribute.
         *
         * If so trigger a click on it for user flow.
         *
         * Clear the blocked_trigger value afterwards.
         */
        $(document).on('pumAfterClose', '.pum', function () {
            if ($.fn.popmake.blocked_trigger && $.fn.popmake.blocked_trigger.data('reclick')) {
                $.fn.popmake.blocked_trigger.data('reclick', false);
                $.fn.popmake.blocked_trigger.get(0).click();
                pum.hooks.doAction('pum.triggers.click_block.reclick');
            }

            $.fn.popmake.blocked_trigger = null;
        });
    }


}(window.jQuery));
(function ($) {
    "use strict";

    $.extend($.fn.popmake.cookies, {
        agreed_to_terms: function (settings) {
            var $popup = PUM.getPopup(this);
            $popup.find('.pum-tc-box__checkbox')
                .on('pumAgreedToTerms', function () {
                    $popup.popmake('setCookie', settings);
                });
        }
    });

}(window.jQuery));
(function ($) {
    "use strict";

    $.extend($.fn.popmake.triggers, {
        force_agreement: function (settings) {
            var $popup = PUM.getPopup(this);

            // If the popup is already open return.
            if ($popup.popmake('state', 'isOpen')) {
                return;
            }

            // If cookie exists or conditions fail return.
            if ($popup.popmake('checkCookies', settings) || !$popup.popmake('checkConditions')) {
                return;
            }

            // Set the global last open trigger to the a text description of the trigger.
            $.fn.popmake.last_open_trigger = 'Force Terms Agreement';

            $popup.popmake('open');
        }
    });

}(window.jQuery));
(function ($) {
    "use strict";

    var terms_agreed_to = {};

    // Clear temporary cookie on page load.
    $.pm_remove_cookie('pum_tc_agreed_to_terms');

    /**
     * Register the test callback to check if they agreed for a click block trigger.
     */
    pum.hooks.addFilter('pum.trigger.click_block.allowed.agree_to_terms', function (allowed, triggerSettings, $popup) {
        var popupID = PUM.getSetting($popup, 'id'),
            tempCookie = PUM.getCookie('pum_tc_agreed_to_terms') || {};

        if (typeof tempCookie === 'string') {
            tempCookie = JSON.parse(tempCookie);
        }

        // If the temporary cookie was set recently or the triggers cookies are found return true.
        return typeof tempCookie[popupID] !== 'undefined' || $popup.popmake('checkCookies', triggerSettings);
    });

    /**
     * B: Set a separate cookie even if they don't set one to temporarily allow it to go through.
     * x On initial page load clear the cookie so it would effectively work every time again unless explicitly setting a longer cookie.
     * - Set short cookie time (30 seconds - 5 minutes)
     * - Store object of agreedToTerms = { popupID: true }, so that multiple popup terms can be required before letting it succeed.
     * - Maybe make length of short cookie an option in the click block trigger when you check Force Agree
     */




    $('.pum.terms-conditions')
        /**
         * Initialize each term box.
         *
         * Stores the id of each popupID.formID for checking in the pumBeforeClose to prevent the popup from being closed.
         */
        .on('pumInit', function () {
            var $popup = PUM.getPopup(this),
                popupID = PUM.getSetting($popup, 'id'),
                $term_boxes = $popup.find('.pum-tc-box');

            if ( typeof terms_agreed_to[popupID] === 'undefined' ) {
                terms_agreed_to[popupID] = {};
            }

            if (!$term_boxes.length) {
                return;
            }

            $term_boxes.each(function () {
                var $box = $(this),
                    boxID = $box.data('form_id'),
                    $terms = $box.find('.pum-tc-box__terms'),
                    $input = $box.find('.pum-tc-box__checkbox'),
                    force_read = $box.find('.pum-tc-box__read-notice').length > 0;

                terms_agreed_to[popupID][boxID] = false;

                /** Set up checkbox and events. */
                $input
                    .addClass('pum-enabled')
                    .prop('checked', false)
                    .attr('checked', false)
                    .on('change', function () {
                        /** If checked set a cookie and close the popup. */
                        if ($input.is(':checked')) {
                            $input
                                .prop('checked', 'checked')
                                .attr('checked', 'checked')
                                .addClass('checked')
                                .trigger('pumAgreedToTerms');

                            terms_agreed_to[popupID][boxID] = true;

                            $popup.popmake('close');
                        }
                    });

                /**
                 * If force read is enabled, disable the checkbox until the user has scrolled to the end of the terms & conditions.
                 */
                if (force_read) {
                    $input.prop('disabled', true).parents('.popmake-tcp-agree').removeClass('pum-enabled').addClass('pum-disabled');
                    $terms.on('scroll.read-check', function () {
                        if ($terms[0].scrollHeight <= $terms.scrollTop() + $terms.innerHeight()) {
                            $input.prop('disabled', false).parents('.popmake-tcp-agree').removeClass('pum-disabled').addClass('pum-enabled');
                            $terms.off('scroll.read-check');
                        }
                    });
                }
            });
        })

        /**
         * Tests if the popups term boxes have all been agreed to. Prevents close otherwise.
         */
        .on('pumBeforeClose', function (){
            var $popup = PUM.getPopup(this),
                popupID = PUM.getSetting($popup, 'id'),
                tempCookie = PUM.getCookie('pum_tc_agreed_to_terms') || {};

            for (var key in terms_agreed_to[popupID]) {
                if (!terms_agreed_to[popupID].hasOwnProperty(key)) {
                    continue;
                }

                if (!terms_agreed_to[popupID][key]) {
                    $popup.addClass('preventClose');
                    return;
                }
            }

            if (typeof tempCookie === 'string') {
                tempCookie = JSON.parse(tempCookie);
            }

            tempCookie[popupID] = true;

            $.pm_cookie(
                'pum_tc_agreed_to_terms',
                tempCookie,
                '5 minutes',
                '/'
            );

            if ($.fn.popmake.blocked_trigger) {
                /**
                 * Set reclick to true if this was a click type trigger.
                 */
                $.fn.popmake.blocked_trigger.data('reclick', true);
            }
        });
}(window.jQuery));
