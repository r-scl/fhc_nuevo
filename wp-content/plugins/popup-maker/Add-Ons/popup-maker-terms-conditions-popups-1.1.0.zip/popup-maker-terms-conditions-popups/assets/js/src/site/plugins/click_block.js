(function ($) {
    "use strict";

    if ($.fn.popmake.triggers.click_block === undefined) {

        $.fn.popmake.blocked_trigger = null;

        /**
         * Add click_block triggers to the list of click trigger types.
         *
         * @see PUM.disableClickTriggers
         */
        pum.hooks.addFilter('pum.disableClickTriggers.clickTriggerTypes', function (clickTriggerTypes) {
            clickTriggerTypes.push('click_block');
            return clickTriggerTypes;
        });

        /**
         * Register the click_block trigger.
         */
        $.fn.popmake.triggers = $.extend($.fn.popmake.triggers, {
            click_block: function (triggerSettings) {
                triggerSettings = $.extend({}, {
                    requirements: {}
                }, triggerSettings);

                var $popup = PUM.getPopup(this),
                    triggerSelector = PUM.getClickTriggerSelector(this, triggerSettings);


                $(triggerSelector)
                    .addClass('pum-trigger')
                    .css({cursor: "pointer"});


                $(document)
                    .off('click.pumTrigger', triggerSelector)
                    .on('click.pumBlockAction', triggerSelector, function (event) {
                        var $trigger = $(this),
                            allowed = true;

                        // If trigger is inside of the popup that it opens, do nothing.
                        if ($popup.has($trigger).length > 0) {
                            return;
                        }

                        // If the popup is already open return.
                        if ($popup.popmake('state', 'isOpen')) {
                            return;
                        }

                        if (triggerSettings.requirements === undefined) {
                            return;
                        }

                        for (var key in triggerSettings.requirements) {
                            if (!triggerSettings.requirements.hasOwnProperty(key)) {
                                continue;
                            }

                            if (!pum.hooks.applyFilters('pum.trigger.click_block.allowed.' + key, true, triggerSettings, $popup)) {
                                allowed = false;
                            }
                        }

                        // If cookie exists or conditions fail return.
                        if (allowed || $popup.popmake('checkCookies', triggerSettings) || !$popup.popmake('checkConditions')) {
                            return;
                        }

                        event.stopPropagation();
                        event.preventDefault();

                        // Set the global last open trigger to the clicked element.
                        $.fn.popmake.last_open_trigger = $trigger;

                        $.fn.popmake.blocked_trigger = $trigger;

                        // Open the popup.
                        $popup.popmake('open');
                    });
            }
        });

        /**
         * After a popup closes, check if there was a blocked trigger that has the reclick attribute.
         *
         * If so trigger a click on it for user flow.
         *
         * Clear the blocked_trigger value afterwards.
         */
        $(document).on('pumAfterClose', '.pum', function () {
            if ($.fn.popmake.blocked_trigger && $.fn.popmake.blocked_trigger.data('reclick')) {
                $.fn.popmake.blocked_trigger.data('reclick', false);
                $.fn.popmake.blocked_trigger.get(0).click();
                pum.hooks.doAction('pum.triggers.click_block.reclick');
            }

            $.fn.popmake.blocked_trigger = null;
        });
    }


}(window.jQuery));