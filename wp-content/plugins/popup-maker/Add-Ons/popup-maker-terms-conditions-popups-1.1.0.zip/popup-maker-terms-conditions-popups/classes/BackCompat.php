<?php
/*******************************************************************************
 * Copyright (c) 2018, WP Popup Maker
 ******************************************************************************/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PUM_TC_BackCompat class
 *
 * @since 1.1.0
 */
class PUM_TC_BackCompat {

	/**
	 * Initialize Hooks & Filters
	 */
	public static function init() {
		add_filter( 'popmake_popup_meta_fields', array( __CLASS__, 'meta_fields' ) );
		add_filter( 'popmake_popup_meta_field_groups', array( __CLASS__, 'meta_field_groups' ) );
		add_filter( 'popmake_popup_meta_field_group_terms_conditions', array( __CLASS__, 'group_terms_conditions' ) );
	}

	/**
	 * @param $fields
	 *
	 * @return array
	 */
	public static function meta_fields( $fields ) {
		return array_merge( $fields, array(
			'popup_terms_conditions_defaults_set',
		) );
	}

	/**
	 * @param $groups
	 *
	 * @return array
	 */
	public static function meta_field_groups( $groups ) {
		return array_merge( $groups, array(
			'terms_conditions',
		) );
	}

	/**
	 * @param $fields
	 *
	 * @return array
	 */
	public static function group_terms_conditions( $fields ) {
		return array_merge( $fields, array(
			'enabled',
			'checkbox_style',
			'agree_text',
			'force_agree',
			'force_read',
			'force_read_notice',
			'cookie_time',
			'cookie_path',
			'cookie_key',
		) );
	}
}
