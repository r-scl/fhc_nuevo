<?php
/*******************************************************************************
 * Copyright (c) 2018, WP Popup Maker
 ******************************************************************************/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class PUM_TC_Site
 */
class PUM_TC_Site {

	/**
	 *
	 */
	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_filter( 'pum_generated_js', array( __CLASS__, 'generated_js' ) );
		add_filter( 'pum_generated_css', array( __CLASS__, 'generated_css' ) );
		add_action( 'pum_preload_popup', array( __CLASS__, 'enqueue_popup_assets' ) );
	}

	/**
	 *
	 */
	public static function assets() {
		if ( ! PUM_AssetCache::writeable() ) {
			wp_register_script( 'pum-tc', PUM_TC::$URL . 'assets/js/pum-tc-site' . PUM_Site_Assets::$suffix . '.js', array( 'popup-maker-site' ), PUM_TC::$VER, true );
			wp_register_style( 'pum-tc', PUM_TC::$URL . 'assets/css/pum-tc-site' . PUM_Site_Assets::$suffix . '.css', array( 'popup-maker-site' ), PUM_TC::$VER );
		}
	}

	/**
	 * @param array $js
	 *
	 * @return array
	 */
	public static function generated_js( $js = array() ) {
		$js['tc'] = array(
			'content'  => file_get_contents( PUM_TC::$DIR . '/assets/js/pum-tc-site' . PUM_Site_Assets::$suffix . '.js' ),
			'priority' => 5,
		);

		return $js;
	}

	/**
	 * @param array $css
	 *
	 * @return array
	 */
	public static function generated_css( $css = array() ) {
		$css['tc'] = array(
			'content'  => file_get_contents( PUM_TC::$DIR . '/assets/css/pum-tc-site' . PUM_Site_Assets::$suffix . '.css' ),
			'priority' => 5,
		);

		return $css;
	}

	/**
	 * @param int $popup_id
	 */
	public static function enqueue_popup_assets( $popup_id = 0 ) {
		$popup = pum_get_popup( $popup_id );

		if ( ! pum_is_popup( $popup ) || ! wp_script_is( 'pum-tc', 'registered' ) ) {
			return;
		}

		if ( PUM_TC_Popup::tc_enabled( $popup ) ) {
			wp_enqueue_script( 'pum-tc' );
			wp_enqueue_style( 'pum-tc' );
		}
	}

}
