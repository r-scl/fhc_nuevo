<?php
/*******************************************************************************
 * Copyright (c) 2018, WP Popup Maker
 ******************************************************************************/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class PUM_TC_Cookies
 */
class PUM_TC_Cookies {

	/**
	 *
	 */
	public static function init() {
		add_filter( 'pum_registered_cookies', array( __CLASS__, 'register_cookies' ) );
	}

	/**
	 * @param array $cookies
	 *
	 * @return array
	 */
	public static function register_cookies( $cookies = array() ) {
		return array_merge( $cookies, array(
			'agreed_to_terms' => array(
				'name' => __( 'Agree to Terms', 'popup-maker-terms-conditions-popups' ),
			),
		) );
	}

}
