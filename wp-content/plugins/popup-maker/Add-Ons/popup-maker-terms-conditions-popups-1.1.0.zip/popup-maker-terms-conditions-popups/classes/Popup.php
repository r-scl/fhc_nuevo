<?php
/*******************************************************************************
 * Copyright (c) 2018, WP Popup Maker
 ******************************************************************************/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class PUM_TC_Popup
 */
class PUM_TC_Popup {

	/**
	 *
	 */
	public static function init() {
		add_filter( 'pum_popup_classes', array( __CLASS__, 'classes' ), 10, 2 );
		add_filter( 'pum_popup_show_close_button', array( __CLASS__, 'show_close_button' ), 10, 2 );
		add_filter( 'pum_add_default_click_trigger', array( __CLASS__, 'add_default_click_trigger' ), 10, 2 );
	}

	/**
	 * @param $popup
	 *
	 * @return bool
	 */
	public static function tc_enabled( $popup ) {
		if ( is_numeric( $popup ) ) {
			$popup = pum_get_popup( $popup );
		}

		if ( ! pum_is_popup( $popup ) ) {
			return false;
		}

		$tests = array(
			has_shortcode( $popup->post_content, 'pum_terms_box' ),
			has_shortcode( $popup->post_content, 'terms_conditions' ),
			has_shortcode( $popup->post_content, 'terms_-conditions' ),
		);

		return in_array( true, $tests );
	}

	/**
	 * @param array $classes
	 * @param int   $popup_id
	 *
	 * @return array
	 */
	public static function classes( $classes, $popup_id ) {
		if ( self::tc_enabled( $popup_id ) ) {
			$classes['overlay'][] = 'terms-conditions';
		}

		return $classes;
	}

	/**
	 * @param $show
	 * @param $popup_id
	 *
	 * @return bool
	 */
	public static function show_close_button( $show, $popup_id ) {
		if ( pum_get_popup( $popup_id )->has_trigger( 'force_agreement' ) ) {
			return false;
		}

		return $show;
	}


	/**
	 * @param $add
	 * @param $popup_id
	 *
	 * @return bool
	 */
	public static function add_default_click_trigger( $add = true, $popup_id ) {

		remove_filter( 'pum_add_default_click_trigger', array( __CLASS__, 'add_default_click_trigger' ), 10 );

		$has_click_blocking = pum_get_popup( $popup_id )->has_trigger( 'click_block' );

		add_filter( 'pum_add_default_click_trigger', array( __CLASS__, 'add_default_click_trigger' ), 10, 2 );

		if ( $has_click_blocking ) {
			return false;
		}

		return $add;
	}

}
