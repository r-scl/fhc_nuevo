<?php
/*******************************************************************************
 * Copyright (c) 2018, WP Popup Maker
 ******************************************************************************/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PUM_TC Site class
 *
 * @since 1.1.0
 */
class PUM_TC_Admin {

	/**
	 * Initialize Hooks & Filters
	 */
	public static function init() {
		//add_action( 'admin_enqueue_scripts', array( __CLASS__, 'scripts_styles' ) );
		// Add site styles for form previews.
		add_editor_style( PUM_TC::$URL . 'assets/css/pum-tc-site.min.css' );
	}

	/**
	 * Enqueue the site scripts.
	 */
	public static function scripts_styles() {
		if ( ! pum_is_popup_editor() ) {
			return;
		}

		wp_enqueue_style( 'pum-tc-admin', PUM_TC::$URL . 'assets/css/pum-tc-admin' . PUM_Admin_Assets::$suffix . '.css', null, PUM_TC::$VER );
		wp_enqueue_script( 'pum-tc-admin', PUM_TC::$URL . 'assets/js/pum-tc-admin' . PUM_Admin_Assets::$suffix . '.js', array( 'popup-maker-admin' ), PUM_TC::$VER, true );
	}

}
