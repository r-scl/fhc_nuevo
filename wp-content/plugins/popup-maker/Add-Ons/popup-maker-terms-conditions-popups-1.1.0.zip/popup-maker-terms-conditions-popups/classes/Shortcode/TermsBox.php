<?php
/*******************************************************************************
 * Copyright (c) 2018, WP Popup Maker
 ******************************************************************************/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class PUM_TC_Shortcode_TermsBox
 *
 * Registers the pum_terms_box shortcode.
 */
class PUM_TC_Shortcode_TermsBox extends PUM_Shortcode {

	/**
	 * @var int
	 */
	public $version = 2;

	/**
	 * @var bool
	 */
	public $has_content = true;

	/**
	 * @var bool
	 */
	public $ajax_rendering = true;

	/**
	 *
	 */
	public function register() {
		// register old shortcode tag.
		add_shortcode( 'terms-conditions', array( $this, 'handler' ) );
		add_shortcode( 'terms_conditions', array( $this, 'handler' ) );
		parent::register();
	}

	/**
	 * The shortcode tag.
	 *
	 * @return string
	 */
	public function tag() {
		return 'pum_terms_box';
	}

	/**
	 * @return string
	 */
	public function label() {
		return __( 'Terms & Conditions Box', 'popup-maker-terms-conditions-popups' );
	}

	/**
	 * @return string
	 */
	public function description() {
		return __( 'Can contain other shortcodes, images, text or html content.', 'popup-maker-terms-conditions-popups' );
	}

	/**
	 * @return array
	 */
	public function post_types() {
		return array( 'popup' );
	}

	/**
	 * @return array
	 */
	public function fields() {
		return array(
			'general' => array(
				'main' => array(
					'agree_text'        => array(
						'type'  => 'text',
						'label' => __( 'Agree Text', 'popup-maker-terms-conditions-popups' ),
						'desc'  => __( 'This is the text label for the agree checkbox.', 'popup-maker-terms-conditions-popups' ),
						'std'   => __( 'I Agree', 'popup-maker-terms-conditions-popups' ),
					),
					'checkbox_style'    => array(
						'label'   => __( 'Checkbox Style', 'popup-maker-terms-conditions-popups' ),
						'type'    => 'select',
						'std'     => 'classic',
						'options' => array(
							'classic'      => __( 'Classic', 'popup-maker-terms-conditions-popups' ),
							'roundedOne'   => __( 'Rounded 1', 'popup-maker-terms-conditions-popups' ),
							'roundedTwo'   => __( 'Rounded 2', 'popup-maker-terms-conditions-popups' ),
							'squaredOne'   => __( 'Square 1', 'popup-maker-terms-conditions-popups' ),
							'squaredTwo'   => __( 'Square 2', 'popup-maker-terms-conditions-popups' ),
							'squaredThree' => __( 'Square 3', 'popup-maker-terms-conditions-popups' ),
							'squaredFour'  => __( 'Square 4', 'popup-maker-terms-conditions-popups' ),
						),
					),
					'force_read'        => array(
						'label'       => __( 'Force User to Read Terms', 'popup-maker-terms-conditions-popups' ),
						'description' => __( 'Checking this will disable the agree checkbox until user has reached the end of the terms box.', 'popup-maker-terms-conditions-popups' ),
						'type'        => 'checkbox',
						'std'         => false,
					),
					'force_read_notice' => array(
						'type'         => 'text',
						'label'        => __( 'Force to Read Notice', 'popup-maker-terms-conditions-popups' ),
						'desc'         => __( 'This is the text notice displayed if the user must read the terms.', 'popup-maker-terms-conditions-popups' ),
						'std'          => __( 'You need to read to the bottom of these terms and conditions before you can continue.', 'popup-maker-terms-conditions-popups' ),
						'dependencies' => array(
							'force_read' => true,
						),
					),
				),
			),
			'options' => array(
				'main' => array(
					'height' => array(
						'label' => __( 'Height', 'popup-maker-terms-conditions-popups' ),
						'type'  => 'measure',
						'std'   => '300px',
					),
				),
			),
		);
	}

	/**
	 * @var array
	 */
	public $instances = array();

	/**
	 * Shortcode handler
	 *
	 * @param  array  $atts    shortcode attributes
	 * @param  string $content shortcode content
	 *
	 * @return string
	 */
	public function handler( $atts, $content = null ) {
		$atts = $this->shortcode_atts( $atts );

		// Create a hash for caching purposes.
		$hash = md5( json_encode( $atts ) ) . md5( $content );

		if ( ! empty( $this->instances[ $hash ] ) ) {
			return $this->instances[ $hash ];
		}

		static $form_id = 1;

		ob_start(); ?>

		<div class="pum-tc-box" data-form_id="<?php echo esc_attr( $form_id ); ?>">

			<div class="pum-tc-box__terms  popmake-tcp-box" style="height: <?php echo esc_attr( $atts['height'] ); ?>;">
				<?php echo apply_filters( 'popmake_terms_conditions', $content ); ?>
			</div>

			<?php if ( $atts['force_read'] ) : ?>
				<p class="pum-tc-box__read-notice  popmake-tcp-read-notice">
					<?php echo esc_html( $atts['force_read_notice'] ); ?>
				</p>
			<?php endif; ?>

			<div class="pum-tc-box__agree  popmake-tcp-agree">
				<div class="pum-tc-box__checkbox-container  popmake-tcp-checkbox-container <?php echo esc_attr( $atts['checkbox_style'] ); ?>">
					<input type="checkbox" id="pum-tc-input-<?php echo $form_id; ?>" class="pum-tc-box__checkbox  popmake-tcp-input" />
					<label for="pum-tc-input-<?php echo $form_id; ?>" class="pum-tc-box__label  popmake-tcp-checkbox"></label>
				</div>
				<label for="pum-tc-input-<?php echo $form_id; ?>"><?php echo esc_html( $atts['agree_text'] ); ?></label>
			</div>

		</div>

		<?php

		$output = ob_get_clean();

		if ( doing_filter( 'pum_popup_content' ) ) {
			$form_id ++;
			$this->instances[ $hash ] = $output;
		}

		return $output;
	}

}

