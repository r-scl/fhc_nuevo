<?php
/*******************************************************************************
 * Copyright (c) 2018, WP Popup Maker
 ******************************************************************************/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Class PUM_TC_Triggers
 */
class PUM_TC_Triggers {

	/**
	 *
	 */
	public static function init() {
		add_filter( 'pum_registered_triggers', array( __CLASS__, 'register_triggers' ) );
	}

	/**
	 * @param array $triggers
	 *
	 * @return array
	 */
	public static function register_triggers( $triggers = array() ) {

		if ( ! isset( $triggers['click_block'] ) ) {
			$triggers['click_block'] = array(
				'name'        => __( 'Click Blocking', 'popup-maker-terms-conditions-popups' ),
				'modal_title' => __( 'Click Blocking Settings', 'popup-maker-terms-conditions-popups' ),
				'fields'      => array(
					'general' => array(
						'extra_selectors' => isset( $triggers['click_open']['fields']['general']['extra_selectors'] ) ? $triggers['click_open']['fields']['general']['extra_selectors'] : array(
							'label'       => __( 'Extra CSS Selectors', 'popup-maker' ),
							'desc'        => __( 'For more than one selector, separate by comma (,)', 'popup-maker' ) . '<br /><strong>eg:  </strong>' . __( ' .class-here, .class-2-here, #button_id', 'popup-maker' ),
							'placeholder' => __( '.class-here', 'popup-maker' ),
							'doclink'     => 'https://docs.wppopupmaker.com/article/147-getting-css-selectors?utm_source=plugin-popup-editor=&utm_medium=inline-doclink&utm_campaign=ContextualHelp&utm_content=extra-selectors',
						),
						'requirements'    => array(
							'type'    => 'multicheck',
							'label'   => __( 'Action Requirements?', 'popup-maker-terms-conditions-popups' ),
							'desc'    => __( 'Each item checked will be required to activate the clicked item.', 'popup-maker-terms-conditions-popups' ),
							'options' => array(),
						),
					),
				),
			);
		}

		// Add the TC force option.
		$triggers['click_block']['fields']['general']['requirements']['options']['agree_to_terms'] = __( 'Agree to Terms', 'popup-maker-terms-conditions-popups' );

		return array_merge( $triggers, array(
			'force_agreement' => array(
				'name'        => __( 'Force Terms Agreement', 'popup-maker-terms-conditions-popups' ),
				'modal_title' => __( 'Force Terms Agreement Settings', 'popup-maker-terms-conditions-popups' ),
				'fields'      => array(
					'general' => array(
						'user_notice'      => array(
							'type'    => 'html',
							'content' => sprintf( __( 'Use the Popup Maker shortcode button %s on the editor toolbar to insert and customize your terms & conditions box.', 'popup-maker-terms-conditions-popups' ), '<img src="' . POPMAKE_URL . '/assets/images/admin/popup-maker-icon.png" width="20" />' ),
						),
					),
				),
			),
		) );
	}

}
