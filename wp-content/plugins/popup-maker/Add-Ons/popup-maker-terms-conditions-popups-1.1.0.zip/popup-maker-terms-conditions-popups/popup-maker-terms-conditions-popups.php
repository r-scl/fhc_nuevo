<?php
/**
 * Plugin Name:  Popup Maker - Terms & Conditions Popups
 * Plugin URI:   https://wppopupmaker.com/extensions/terms-conditions-popups/
 * Description:  Quickly create popups requiring users to agree to your terms & conditions.
 * Version:      1.1.0
 * Author:       WP Popup Maker
 * Author URI:   https://wppopupmaker.com/
 * Text Domain:  popup-maker-terms-conditions-popups
 *
 * @author       WP Popup Maker
 * @copyright    Copyright (c) 2018, WP Popup Maker
 */


// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class PUM_TC
 */
class PUM_TC {

	/**
	 * @var int $download_id for EDD.
	 */
	public static $ID = 35837;

	/**
	 * @var string
	 */
	public static $NAME = 'Terms & Conditions Popups';

	/**
	 * @var string Plugin Version
	 */
	public static $VER = '1.1.0';

	/**
	 * @var string Required Version of Popup Maker
	 */
	public static $REQUIRED_CORE_VER = '1.7.16';

	/**
	 * @var int DB Version
	 */
	public static $DB_VER = 1;

	/**
	 * @var string Plugin Directory
	 */
	public static $DIR;

	/**
	 * @var string Plugin URL
	 */
	public static $URL;

	/**
	 * @var string Plugin FILE
	 */
	public static $FILE;

	/**
	 * @var self $instance
	 */
	private static $instance;

	/**
	 * @return self
	 */
	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self;
			self::$instance->setup_constants();
			self::$instance->load_textdomain();
			self::$instance->includes();
			self::$instance->init();
		}

		return self::$instance;
	}

	/**
	 * Set up plugin constants.
	 */
	public static function setup_constants() {
		self::$DIR  = plugin_dir_path( __FILE__ );
		self::$URL  = plugin_dir_url( __FILE__ );
		self::$FILE = __FILE__;
	}

	/**
	 * Internationalization
	 */
	public function load_textdomain() {
		load_plugin_textdomain( 'popup-maker-terms-conditions-popups', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
	}

	/**
	 * Include required files
	 */
	private function includes() {
	}

	/**
	 * Initialize the plugin.
	 */
	private function init() {
		// Get things running.
		PUM_TC_Site::init();
		PUM_TC_Admin::init();
		PUM_TC_Popup::init();
		PUM_TC_Cookies::init();
		PUM_TC_Triggers::init();
		PUM_TC_Shortcode_TermsBox::init();
		PUM_TC_BackCompat::init();

		PUM_TC_Upgrades::init();

		/**
		 * Do we need these still? Not sure they are helpful.
		 */
		add_filter( 'popmake_terms_conditions', array( $GLOBALS['wp_embed'], 'run_shortcode' ), 8 );
		add_filter( 'popmake_terms_conditions', array( $GLOBALS['wp_embed'], 'autoembed' ), 8 );
		add_filter( 'popmake_terms_conditions', 'wptexturize', 10 );
		add_filter( 'popmake_terms_conditions', 'convert_smilies', 10 );
		add_filter( 'popmake_terms_conditions', 'convert_chars', 10 );
		add_filter( 'popmake_terms_conditions', 'wpautop', 10 );
		add_filter( 'popmake_terms_conditions', 'shortcode_unautop', 10 );
		add_filter( 'popmake_terms_conditions', 'prepend_attachment', 10 );
		add_filter( 'popmake_terms_conditions', array( 'PUM_Helpers', 'do_shortcode' ), 11 );
		add_filter( 'popmake_terms_conditions', 'capital_P_dangit', 11 );

		// Handle licensing
		if ( class_exists( 'PUM_Extension_License' ) ) {
			new PUM_Extension_License( self::$FILE, self::$NAME, self::$VER, 'WP Popup Maker', null, null, self::$ID );
		}
	}

}


/**
 * Register this extensions autoload parameters to the pum_autoloaders array.
 *
 * @param array $autoloaders
 *
 * @return array
 */
function pum_tc_autoloader( $autoloaders = array() ) {
	return array_merge( $autoloaders, array(
		array(
			'prefix' => 'PUM_TC_',
			'dir'    => dirname( __FILE__ ) . '/classes/',
		),
	) );
}

add_filter( 'pum_autoloaders', 'pum_tc_autoloader' );

/**
 * Get the ball rolling.
 */
function pum_tc_init() {
	if ( ! class_exists( 'PUM_Extension_Activator' ) ) {
		require_once 'includes/pum-sdk/class-pum-extension-activator.php';
	}

	$activator = new PUM_Extension_Activator( 'PUM_TC' );
	$activator->run();
}

add_action( 'plugins_loaded', 'pum_tc_init', 11 );

if ( ! class_exists( 'PUM_TC_Activator' ) ) {
	require_once 'classes/Activator.php';
}
register_activation_hook( __FILE__, 'PUM_TC_Activator::activate' );

if ( ! class_exists( 'PUM_TC_Deactivator' ) ) {
	require_once 'classes/Deactivator.php';
}
register_deactivation_hook( __FILE__, 'PUM_TC_Deactivator::deactivate' );
