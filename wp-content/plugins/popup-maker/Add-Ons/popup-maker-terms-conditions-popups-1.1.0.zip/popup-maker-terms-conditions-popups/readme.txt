=== Popup Maker - Terms & Conditions Popups ===
Contributors: danieliser, wppopupmaker
Author URI: https://wppopupmaker.com/
Plugin URI: https://wppopupmaker.com/extensions/terms-conditions-popups/
Tags: 
Requires at least: 3.6
Tested up to: 4.9.5
Stable tag: 1.1.0

Quickly create popups requiring users to agree to your terms & conditions.

== Description ==
Quickly create popups requiring users to agree to your terms & conditions.

== Changelog ==

- v1.1.0 - 04/25/2018
* Feature: Added new Click Blocking trigger which supports multiple requirements for unblocking.
* Feature: Added new Force Agreement trigger.
  - Replaces the old "Force agreement option"
* Feature: Shortcode now uses the Popup Maker Shortcode UI for easy editing and live previews in the editor.
  - Replaces settings for checkbox style, agree text, force read & force read notice to the shortcode editor.
* Improvement: Updated for full Popup Maker v1.7 support.
  * Leveraged the new AssetCache reducing the need to load an extra JS file for this extension.
  * Class auto loading & more reliable upgrade routines.
* Tweak: Removed the Terms & Conditions meta box in favor of using existing Shortcode, Trigger & Cookie APIs.

= v1.0.5 - 08/15/2017 =
* Fix: Added support for reclicks using Popup Maker v1.4+.
* Fix: Replaced usage of deprecated filter.

= v1.0.4 =
* Fix: PHP 5.2 compatibility issue.

= v1.0.3 =
* Added ability to style the agree text and checkbox when disabled using the .disabled parent class.

= v1.0.2 =
* Added new setting for force read notice. Used to indicate to the user that they must scroll to the end of the terms & conditions to enable the agree button.

= v1.0.1 =
* Added in customizable checkbox styles.
* Added in functionality to be able to force agreement to terms before clicking buttons or links such as add-to-cart buttons. Requires Popup Maker v1.3+

= v1.0.0 =
* Initial Release