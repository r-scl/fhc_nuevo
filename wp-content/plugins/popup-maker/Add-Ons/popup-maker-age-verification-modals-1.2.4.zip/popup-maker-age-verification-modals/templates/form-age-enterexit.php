<div class='pum-age-buttons popmake-age-buttons'>

	<div class="pum-field pum-field-button pum-field-age_enter">
		<button type="button" name="enter" class="pum-age-button pum-age-enter age-enter" aria-label="<?php esc_attr_e( $atts['label_enter'] ); ?>"><?php esc_attr_e( $atts['label_enter'] ); ?></button>
	</div>

	<div class="pum-field pum-field-button pum-field-age_exit">
		<button type="button" name="exit" class="pum-age-button pum-age-exit age-exit" aria-label="<?php esc_attr_e( $atts['label_exit'] ); ?>"><?php esc_attr_e( $atts['label_exit'] ); ?></button>
	</div>

</div>