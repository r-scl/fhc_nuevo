<?php
/**
 * Plugin Name: Popup Maker - Scheduling
 * Plugin URI: https://wppopupmaker.com/extensions/scheduling/
 * Description: Adds advanced scheduling to Popup Maker popups.
 * Author: WP Popup Maker
 * Version: 1.1.0
 * Author URI: https://wppopupmaker.com/
 * Text Domain: pum-scheduling
 * GitLab Plugin URI: https://gitlab.com/PopupMaker/pum-scheduling
 * GitHub Branch:     master
 *
 * @author       WP Popup Maker
 * @copyright    Copyright (c) 2016, WP Popup Maker
 */


// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @param array $autoloaders
 *
 * @return array
 */
function pum_sch_autoloader( $autoloaders = array() ) {
	return array_merge( $autoloaders, array(
		array(
			'prefix' => 'PUM_SCH_',
			'dir'    => dirname( __FILE__ ) . '/classes/',
		),
	) );
}

add_filter( 'pum_autoloaders', 'pum_sch_autoloader' );

/**
 * Class PUM_SCH
 */
class PUM_SCH {

	/**
	 * @var int $download_id for EDD.
	 */
	public static $ID = 81063;

	/**
	 * @var string
	 */
	public static $NAME = 'Scheduling';

	/**
	 * @var string Plugin Version
	 */
	public static $VER = '1.1.0';

	/**
	 * @var string Required Version of Popup Maker
	 */
	public static $REQUIRED_CORE_VER = '1.7.0';

	/**
	 * @var int DB Version
	 */
	public static $DB_VER = 1;

	/**
	 * @var string Plugin Directory
	 */
	public static $DIR;

	/**
	 * @var string Plugin URL
	 */
	public static $URL;

	/**
	 * @var string Plugin FILE
	 */
	public static $FILE;

	/**
	 * @var self $instance
	 */
	private static $instance;

	/**
	 * Get active instance
	 *
	 * @return      object self::$instance The one true PUM_SCH
	 */
	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self;
			self::$instance->setup_constants();
			self::$instance->load_textdomain();
			self::$instance->includes();
			self::$instance->init();
		}

		return self::$instance;
	}

	/**
	 * Setup plugin constants
	 *
	 * @access      private
	 * @since       1.2.0
	 * @return      void
	 */
	private function setup_constants() {
		self::$DIR  = plugin_dir_path( __FILE__ );
		self::$URL  = plugins_url( '/', __FILE__ );
		self::$FILE = __FILE__;
	}

	/**
	 * Internationalization
	 */
	public function load_textdomain() {
		load_plugin_textdomain( 'pum-scheduling', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
	}

	/**
	 * Include necessary files
	 */
	private function includes() {}

	/**
	 * Initialize everything
	 */
	private function init() {
		PUM_SCH_Site::init();
		PUM_SCH_Admin::init();
		PUM_SCH_Popup::init();
		PUM_SCH_Upgrades::init();

		// Handle licensing
		if ( class_exists( 'PUM_Extension_License' ) ) {
			new PUM_Extension_License( self::$FILE, self::$NAME, self::$VER, 'WP Popup Maker', null, null, self::$ID );
		}
	}

}

/**
 * Get the ball rolling.
 */
function pum_sch_init() {
	if ( ( ! class_exists( 'Popup_Maker' ) && ! class_exists( 'PUM' ) ) || version_compare( Popup_Maker::$VER, PUM_SCH::$REQUIRED_CORE_VER, '<' ) ) {
		if ( ! class_exists( 'PUM_Extension_Activation' ) ) {
			require_once 'includes/pum-sdk/class-pum-extension-activation.php';
		}

		$activation = new PUM_Extension_Activation( plugin_dir_path( __FILE__ ), basename( __FILE__ ), PUM_SCH::$REQUIRED_CORE_VER );
		$activation->run();
	} else {
		PUM_SCH::instance();
	}
}

add_action( 'plugins_loaded', 'pum_sch_init' );

if ( ! class_exists( 'PUM_SCH_Activator' ) ) {
	require_once 'classes/Activator.php';
}
register_activation_hook( __FILE__, 'PUM_SCH_Activator::activate' );

if ( ! class_exists( 'PUM_SCH_Deactivator' ) ) {
	require_once 'classes/Deactivator.php';
}
register_deactivation_hook( __FILE__, 'PUM_SCH_Deactivator::deactivate' );
