<?php
/*******************************************************************************
 * Copyright (c) 2018, WP Popup Maker
 ******************************************************************************/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Implements a batch processor for migrating existing popups to new data structure.
 *
 * @since 1.1.0
 *
 * @see   PUM_Abstract_Upgrade_Popups
 */
class PUM_SCH_Upgrade_v1_1_Popups extends PUM_Abstract_Upgrade_Popups {

	/**
	 * Batch process ID.
	 *
	 * @var    string
	 */
	public $batch_id = 'sch-v1_1-popups';

	/**
	 * Only load popups with specific meta keys.r
	 *
	 * @return array
	 */
	public function custom_query_args() {
		return array(
			'meta_query' => array(
				'relation' => 'OR',
				array(
					'key'     => 'popup_schedules',
					'compare' => 'EXISTS',
				),
			),
		);
	}


	/**
	 * Process needed upgrades on each popup.
	 *
	 * @param int $popup_id
	 */
	public function process_popup( $popup_id = 0 ) {

		$popup = pum_get_popup( $popup_id );

		$schedules = $popup->get_meta( 'popup_schedules' );

		if ( ! $schedules || empty( $schedules ) ) {
			return;
		}

		$popup_settings = array(
			'schedules' => array(),
		);

		foreach ( $schedules as $key => $schedule ) {

			$settings = array(
				'type'      => $schedule['type'],
				// Move user label to new key.
				'name'      => ! empty( $schedule['settings']['label'] ) ? $schedule['settings']['label'] : __( 'Schedule', 'pum-scheduling' ) . '#' . ( $key + 1 ),
				// Force localtime to be a boolean.
				'localtime' => (bool) isset( $schedule['settings']['localtime'] ) && $schedule['settings']['localtime'],
			);

			// Set the event based on the original option.
			switch ( $schedule['type'] ) {
				case 'start':
					// Split old datetime into date & time. "2018-04-15 02:10"
					$date_time = explode( ' ', $schedule['settings']['datetime'], 2 );

					// Set start date, time & all day setting.
					$settings['start_date'] = $date_time[0];
					$settings['start_time'] = $date_time[1];
					$settings['all_day']    = $date_time[1] == '00:00' ? 'yes' : 'no';
					break;

				case 'end':
					// Split old datetime into date & time. "2018-04-24 17:00"
					$date_time = explode( ' ', $schedule['settings']['datetime'], 2 );

					// Set end date, time & all_day settings.
					$settings['end_date'] = $date_time[0];
					$settings['end_time'] = $date_time[1];
					$settings['all_day']  = $date_time[1] == '23:59' ? 'yes' : 'no';
					break;

				case 'range':
					// Split old date range into start & end datetime's. "2018-04-01 00:00 to 2018-04-11 22:00"
					$range = explode( ' to ', $schedule['settings']['daterange'], 2 );

					// Split old datetimes into date & time. "2018-04-24 17:00"
					$start_datetime = explode( ' ', $range[0], 2 );
					$end_datetime   = explode( ' ', $range[1], 2 );

					// Set start date, time & all day setting.
					$settings['start_date'] = $start_datetime[0];
					$settings['start_time'] = $start_datetime[1];
					$settings['end_date']   = $end_datetime[0];
					$settings['end_time']   = $end_datetime[1];
					$settings['all_day']    = $start_datetime == '00:00' && $end_datetime[1] == '23:59' ? 'yes' : 'no';
					break;
			}

			$popup_settings['schedules'][] = array(
				'type'     => $schedule['type'],
				'settings' => $settings,
			);
		}

		if ( ! empty( $popup_settings['schedules'] ) ) {
			$popup->update_settings( $popup_settings );
		}
	}

	/**
	 *
	 */
	public function finish() {
		global $wpdb;

		$meta_keys = implode( "','", array( 'popup_schedules' ) );

		$wpdb->query( "DELETE FROM $wpdb->postmeta WHERE meta_key IN('$meta_keys');" );
	}
}
