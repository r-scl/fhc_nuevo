<?php
/*******************************************************************************
 * Copyright (c) 2018, WP Popup Maker
 ******************************************************************************/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Class PUM_SCH_Admin_Popups
 */
class PUM_SCH_Admin_Popups {

	/**
	 * Initialize the needed actions & filters.
	 */
	public static function init() {
		add_filter( 'pum_popup_setting_pre_save', array( __CLASS__, 'pre_save' ), 10, 2 );
		add_filter( 'pum_popup_settings_tabs', array( __CLASS__, 'tabs' ) );
		add_filter( 'pum_popup_settings_sections', array( __CLASS__, 'sections' ) );
		add_filter( 'pum_popup_settings_fields', array( __CLASS__, 'fields' ) );
		add_filter( 'pum_popup_settings_editor_var', array( __CLASS__, 'settings_editor_var' ) );
	}

	/**
	 * @param array $vars
	 *
	 * @return array
	 */
	public static function settings_editor_var( $vars = array() ) {
		return array_merge( $vars, array(
			'schedules'            => PUM_SCH_Schedules::instance()->get_schedules(),
			'schedules_selectlist' => PUM_SCH_Schedules::instance()->dropdown_list(),
		) );
	}

	/**
	 * @param array $settings
	 * @param int   $popup_id
	 *
	 * @return array
	 */
	public static function pre_save( $settings, $popup_id ) {
		$settings['schedules'] = isset( $settings['schedules'] ) ? PUM_Admin_Popups::sanitize_meta( $settings['schedules'] ) : array();

		return $settings;
	}

	/**
	 * @param array $tabs
	 *
	 * @return array
	 */
	public static function tabs( $tabs = array() ) {
		return array_merge( $tabs, array(
			'scheduling' => __( 'Scheduling', 'pum-scheduling' ),
		) );
	}

	/**
	 * @param array $sections
	 *
	 * @return array
	 */
	public static function sections( $sections = array() ) {
		return array_merge( $sections, array(
			'scheduling' => array(
				'main' => __( 'Scheduling', 'pum-scheduling' ),
			),
		) );
	}

	/**
	 * @param array $sections
	 *
	 * @return array
	 */
	public static function fields( $sections = array() ) {
		return array_merge( $sections, array(
			'scheduling' => array(
				'main' => array(
					'schedules' => array(
						'type'     => 'schedules',
						'std'      => array(),
						'priority' => 10,
						'private'  => true,
					),
				),
			),
		) );
	}

}
