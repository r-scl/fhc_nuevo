<?php
/*******************************************************************************
 * Copyright (c) 2018, WP Popup Maker
 ******************************************************************************/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Class PUM_SCH_Admin_Templates
 */
class PUM_SCH_Admin_Templates {

	/**
	 *
	 */
	public static function init() {
		if ( did_action( 'admin_footer' ) || doing_action( 'admin_footer' ) ) {
			self::render();
		} else {
			add_action( 'admin_footer', array( __CLASS__, 'render' ) );
		}
	}

	/**
	 *
	 */
	public static function render() {
		self::schedules_editor();
		self::date_fields();
	}

	public static function date_fields() {
		?>

		<script type="text/html" id="tmpl-pum-field-date">
			<div class="pum-date">
				<input placeholder="{{data.placeholder}}" data-input class="{{data.size}}-text" id="{{data.id}}" name="{{data.name}}" value="{{data.value}}" {{{data.meta}}}/>
				<a class="input-button" data-toggle><i class="dashicons dashicons-calendar-alt"></i></a>
			</div>
		</script>

		<script type="text/html" id="tmpl-pum-field-time">
			<div class="pum-time">
				<input placeholder="{{data.placeholder}}" data-input class="{{data.size}}-text" id="{{data.id}}" name="{{data.name}}" value="{{data.value}}" {{{data.meta}}}/>
				<a class="input-button" data-toggle><i class="dashicons dashicons-calendar-alt"></i></a>
			</div>
		</script>

		<script type="text/html" id="tmpl-pum-field-dates">
			<div class="pum-dates">
				<input placeholder="{{data.placeholder}}" data-input class="{{data.size}}-text" id="{{data.id}}" name="{{data.name}}" value="{{data.value}}" {{{data.meta}}}/>
				<a class="input-button" data-toggle><i class="dashicons dashicons-calendar-alt"></i></a>
			</div>
		</script>

		<script type="text/html" id="tmpl-pum-field-datetime">
			<div class="pum-datetime">
				<input placeholder="{{data.placeholder}}" data-input class="{{data.size}}-text" id="{{data.id}}" name="{{data.name}}" value="{{data.value}}" {{{data.meta}}}/>
				<a class="input-button" data-toggle><i class="dashicons dashicons-calendar-alt"></i></a>
			</div>
		</script>

		<script type="text/html" id="tmpl-pum-field-datetimerange">
			<div class="pum-datetime-range">
				<input placeholder="{{data.placeholder}}" data-input class="{{data.size}}-text" id="{{data.id}}" name="{{data.name}}" value="{{data.value}}" {{{data.meta}}}/>
				<a class="input-button" data-toggle><i class="dashicons dashicons-calendar-alt"></i></a>
			</div>
		</script>

		<?php
	}

	/**
	 *
	 */
	public static function schedules_editor() {
		?>
		<script type="text/html" id="tmpl-pum-field-schedules">
			<# print(PUM_Admin.schedules.template.editor({schedules: data.value, name: data.name})); #>
		</script>

		<script type="text/html" id="tmpl-pum-schedules-editor">
			<div class="pum-popup-schedule-editor  <# if (data.schedules && data.schedules.length) { print('has-list-items'); } #>" data-field_name="{{data.name}}">
				<button type="button" class="button button-primary pum-add-new no-button"><?php _e( 'Add New Schedule', 'pum-scheduling' ); ?></button>

				<p><strong><?php _e( 'Schedules are used to limit when a popup is activated.', 'pum-scheduling' ); ?>	<a href="<?php echo esc_url( 'https://docs.wppopupmaker.com/article/350-popup-settings-box-schedules-option-settings?utm_medium=inline-doclink&utm_campaign=ContextualHelp&utm_source=plugin-popup-editor&utm_content=schedules-option-settings' ); ?>" target="_blank" class="pum-doclink dashicons dashicons-editor-help" title="<?php esc_attr_e( sprintf( __( 'Learn more about %s', 'pum-scheduling' ), __( 'Schedules', 'pum-scheduling' ) ) ); ?>"></a></strong></p>

				<table class="list-table form-table">
					<thead>
					<tr>
						<th><?php _e( 'Label', 'pum-scheduling' ); ?></th>
						<th><?php _e( 'Type', 'pum-scheduling' ); ?></th>
						<th><?php _e( 'Schedule', 'pum-scheduling' ); ?></th>
						<th><?php _e( 'Actions', 'pum-scheduling' ); ?></th>
					</tr>
					</thead>
					<tbody>
					<# _.each(data.schedules, function (schedule, index) { print(PUM_Admin.schedules.template.row({ index: index, type: schedule.type, name: data.name, settings: schedule.settings || {} })); }); #>
					</tbody>
				</table>
			</div>
		</script>

		<script type="text/html" id="tmpl-pum-schedule-row">
			<tr data-index="{{data.index}}">
				<td class="name-column">
					<button type="button" class="edit no-button link-button" aria-label="<?php _e( 'Edit this schedule', 'pum-scheduling' ); ?>">{{data.settings.name || "<?php _e( 'Schedule #', 'pum-scheduling');?>"+(data.index+1)}}</button>
				</td>
				<td class="type-column">
					<button type="button" class="edit no-button link-button" aria-label="<?php _e( 'Edit this schedule', 'pum-scheduling' ); ?>">{{PUM_Admin.schedules.getLabel(data.type)}}</button>
					<input class="popup_schedules_field_type" type="hidden" name="{{data.name}}[{{data.index}}][type]" value="{{data.type}}" />
					<input class="popup_schedules_field_settings" type="hidden" name="{{data.name}}[{{data.index}}][settings]" value="{{JSON.stringify(data.settings)}}" />
				</td>
				<td class="settings-column">{{PUM_Admin.schedules.getSettingsDesc(data.type, data.settings)}}</td>
				<td class="list-item-actions">
					<button type="button" class="edit dashicons dashicons-edit no-button" aria-label="<?php _e( 'Edit this schedule', 'pum-scheduling' ); ?>"></button>
					<button type="button" class="remove dashicons dashicons-no no-button" aria-label="<?php _e( 'Delete` this schedule', 'pum-scheduling' ); ?>"></button>
				</td>
			</tr>
		</script>

		<script type="text/html" id="tmpl-pum-schedule-add-type">
			<#
			var form_args = <?php echo json_encode( array(
				'id'     => 'pum-add-schedule',
				'fields' => array(
					'popup_schedule_add_type'         => array(
						'id'      => 'popup_schedule_add_type',
						'name'    => "",
						'label'   => __( 'Choose what type of schedule to add?', 'pum-scheduling' ),
						'type'    => 'select',
						'options' => PUM_SCH_Schedules::instance()->dropdown_list(),
					),
				),
			) ); ?>,
			content = PUM_Admin.forms.render(form_args, {});

			print(PUM_Admin.templates.modal({
				id: 'pum_schedule_add_type_modal',
				title: '<?php _e( 'What type of schedule do you need?', 'pum-scheduling' ); ?>',
				content: content,
				save_button: pum_admin_vars.I10n.add || '<?php __( 'Add', 'pum-scheduling' ); ?>'
			}));
			#>
		</script>
		<?php
	}
}
