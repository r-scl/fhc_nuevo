<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Class class PUM_SCH_Admin_Assets {
 */
class PUM_SCH_Admin_Assets {

	/**
	 * Initialization
	 */
	public static function init() {
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'scripts_styles' ) );
		add_filter( 'pum_admin_var', array( __CLASS__, 'admin_vars' ) );
		add_action( 'admin_print_footer_scripts', array( __CLASS__, 'maybe_localize_and_templates' ), - 1 );
	}

	/**
	 * Enqueue the site scripts.
	 */
	public static function scripts_styles() {
		if ( ! pum_is_popup_editor() ) {
			return;
		}

		wp_enqueue_style( 'flatpickr', PUM_SCH::$URL . 'assets/css/pum-sch-flatpickr' . PUM_Admin_Assets::$suffix . '.css', null, '2.2.4' );
		wp_enqueue_script( 'flatpickr', PUM_SCH::$URL . 'assets/js/flatpickr' . PUM_Admin_Assets::$suffix . '.js', null, '2.2.4', true );
		wp_enqueue_style( 'pum-sch-admin', PUM_SCH::$URL . 'assets/css/pum-sch-admin' . PUM_Admin_Assets::$suffix . '.css', null, PUM_SCH::$VER );
		wp_enqueue_script( 'pum-sch-admin', PUM_SCH::$URL . 'assets/js/pum-sch-admin' . PUM_Admin_Assets::$suffix . '.js', array( 'popup-maker-admin' ), PUM_SCH::$VER, true );
	}

	/**
	 * @param $vars
	 *
	 * @return mixed
	 */
	public static function admin_vars( $vars ) {
		// TODO REMOVE THESE SOON.
		$vars['I10n']['confirm_delete_schedule'] = __( "Are you sure you want to delete this schedule?", 'pum-scheduling' );
		return $vars;
	}


	/**
	 *
	 */
	public static function maybe_localize_and_templates() {
		if ( wp_script_is( 'pum-sch-admin' ) ) {
			// Register Templates.
			PUM_SCH_Admin_Templates::init();
		}
	}


}