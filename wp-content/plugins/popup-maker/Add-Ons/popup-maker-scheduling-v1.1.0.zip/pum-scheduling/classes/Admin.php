<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PUM_SCH Site class
 *
 * @since       1.2.0
 */
class PUM_SCH_Admin {

	/**
	 * Initialize Hooks & Filters
	 */
	public static function init() {
		PUM_SCH_Admin_Assets::init();
		PUM_SCH_Admin_Popups::init();
		PUM_SCH_Admin_Popups::init();
	}

}
