<?php
/**
 * Schedules
 *
 * @package     PUM
 * @subpackage  Classes/PUM_SCH_Schedules
 * @copyright   Copyright (c) 2015, Daniel Iser
 * @license     http://opensource.org/licenses/gpl-3.0.php GNU Public License
 * @since       1.4
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class PUM_SCH_Schedules
 */
class PUM_SCH_Schedules {

	/**
	 * @var
	 */
	public static $instance;

	/**
	 * @var array
	 */
	public $schedules;


	/**
	 *
	 */
	public static function init() {
		self::instance();
	}


	/**
	 * @return self
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	/**
	 * @param null $schedule
	 *
	 * @return mixed|null
	 */
	public function get_schedule( $schedule = null ) {
		$schedules = $this->get_schedules();

		return isset( $schedules[ $schedule ] ) ? $schedules[ $schedule ] : null;
	}

	/**
	 * @return array
	 */
	public function get_schedules() {
		if ( ! isset( $this->schedules ) ) {
			$this->register_schedules();
		}

		return $this->schedules;
	}

	public function days_of_week_settings_column_text() {
		return '<#
		
		var days = [];
		
		for (var k in data.days_of_week) {
            if (data.days_of_week.hasOwnProperty(k)) {
				switch(k) {
					case "d0": days.push("' . __( 'Sunday', 'pum-scheduling' ) . '");
					break;
					case "d1": days.push("' . __( 'Monday', 'pum-scheduling' ) . '");
					break;
					case "d2": days.push("' . __( 'Tuesday', 'pum-scheduling' ) . '");
					break;
					case "d3": days.push("' . __( 'Wednesday', 'pum-scheduling' ) . '");
					break;
					case "d4": days.push("' . __( 'Thursday', 'pum-scheduling' ) . '");
					break;
					case "d5": days.push("' . __( 'Friday', 'pum-scheduling' ) . '");
					break;
					case "d6": days.push("' . __( 'Saturday', 'pum-scheduling' ) . '");
					break;
				}
            }
        }
		
		if (days.length) {
			print(days.join(", "));
		}
		
		#>';
	}

	/**
	 * Registers all known schedules when called.
	 */
	public function register_schedules() {
		/*
		 * Start
		 * End
		 * Chosen Dates
		 * Range
		 * Office Hours
		 * Holidays (US/UK/Etc) (Selectable list)
		 */


		$schedules = apply_filters( 'pum_sch_registered_schedules', array(
			'start'        => array(
				'name'            => __( 'Start Date', 'pum-scheduling' ),
				'settings_column' => sprintf( __( 'Start on %s%s', 'pum-scheduling' ), '{{data.start_date}}', '{{data.all_day ==="no" ? " at " + data.start_time : ""}}' ),
				'fields'          => array_merge_recursive( $this->schedule_fields(), array(
					'main' => array(
						'start_date' => array(
							'label' => __( 'Start Date', 'pum-scheduling' ),
							'desc'  => __( 'Choose start date.', 'pum-scheduling' ),
							'type'  => 'date',
							'std'   => date( 'Y-m-d' ),
							'class' => 'pum-half',
						),
						'start_time' => array(
							'label'        => __( 'Start Time', 'pum-scheduling' ),
							'desc'         => __( 'Choose start time.', 'pum-scheduling' ),
							'type'         => 'time',
							'std'          => '00:00',
							'class'        => 'pum-half pum-last',
							'dependencies' => array(
								'all_day' => 'no',
							),
						),
						'all_day'    => array(
							'label'   => __( 'All Day?', 'pum-scheduling' ),
							'type'    => 'select',
							'options' => array(
								'yes' => __( 'Yes', 'pum-scheduling' ),
								'no'  => __( 'No', 'pum-scheduling' ),
							),
							'std'     => 'yes',
						),
					),
				) ),
			),
			'end'          => array(
				'name'            => __( 'End Date', 'pum-scheduling' ),
				'settings_column' => sprintf( __( 'End on %s%s', 'pum-scheduling' ), '{{data.end_date}}', '{{data.all_day ==="no" ? " at " + data.end_time : ""}}' ),
				'fields'          => array_merge_recursive( $this->schedule_fields(), array(
					'main' => array(
						'end_date' => array(
							'label' => __( 'End Date', 'pum-scheduling' ),
							'desc'  => __( 'Choose end date.', 'pum-scheduling' ),
							'type'  => 'date',
							'std'   => date( 'Y-m-d', strtotime( '+7 days' ) ),
							'class' => 'pum-half',
						),
						'end_time' => array(
							'label'        => __( 'End Time', 'pum-scheduling' ),
							'desc'         => __( 'Choose end time.', 'pum-scheduling' ),
							'type'         => 'time',
							'std'          => '23:59:59',
							'class'        => 'pum-half pum-last',
							'dependencies' => array(
								'all_day' => 'no',
							),
						),
						'all_day'  => array(
							'label'   => __( 'All Day?', 'pum-scheduling' ),
							'type'    => 'select',
							'options' => array(
								'yes' => __( 'Yes', 'pum-scheduling' ),
								'no'  => __( 'No', 'pum-scheduling' ),
							),
							'std'     => 'yes',
						),
					),
				) ),
			),
			'dates'        => array(
				'name'            => __( 'Chosen Dates', 'pum-scheduling' ),
				'settings_column' => sprintf( __( '%s%s', 'pum-scheduling' ), '{{data.chosen_dates}}', '{{data.all_day ==="no" ? " from " + data.start_time + " until " + data.end_time: ""}}' ),
				'fields'          => array_merge_recursive( $this->schedule_fields(), array(
					'main' => array(
						'chosen_dates' => array(
							'label' => __( 'Chosen Dates', 'pum-scheduling' ),
							'desc'  => __( 'Choose specific dates to show the popup on.', 'pum-scheduling' ),
							'type'  => 'dates',
						),
						'all_day'      => array(
							'label'   => __( 'All Day?', 'pum-scheduling' ),
							'type'    => 'select',
							'options' => array(
								'yes' => __( 'Yes', 'pum-scheduling' ),
								'no'  => __( 'No', 'pum-scheduling' ),
							),
							'std'     => 'yes',
						),
						'start_time'   => array(
							'label'        => __( 'Start Time', 'pum-scheduling' ),
							'desc'         => __( 'Choose start time.', 'pum-scheduling' ),
							'type'         => 'time',
							'std'          => '00:00',
							'class'        => 'pum-half',
							'dependencies' => array(
								'all_day' => 'no',
							),
						),
						'end_time'     => array(
							'label'        => __( 'End Time', 'pum-scheduling' ),
							'desc'         => __( 'Choose end time.', 'pum-scheduling' ),
							'type'         => 'time',
							'std'          => '23:59:59',
							'class'        => 'pum-half pum-last',
							'dependencies' => array(
								'all_day' => 'no',
							),
						),
					),
				) ),
			),
			'range'        => array(
				'name'            => __( 'Date Range', 'pum-scheduling' ),
				'settings_column' => sprintf( __( 'From: %s at %s through %s at %s', 'pum-scheduling' ), '{{data.start_date}}', '{{data.start_time}}', '{{data.end_date}}', '{{data.end_time}}' ),
				'fields'          => array_merge_recursive( $this->schedule_fields(), array(
					'main' => array(
						'start_date' => array(
							'label' => __( 'Start Date', 'pum-scheduling' ),
							'desc'  => __( 'Choose start date.', 'pum-scheduling' ),
							'type'  => 'date',
							'std'   => date( 'Y-m-d' ),
							'class' => 'pum-half',
						),
						'start_time' => array(
							'label'        => __( 'Start Time', 'pum-scheduling' ),
							'desc'         => __( 'Choose start time.', 'pum-scheduling' ),
							'type'         => 'time',
							'std'          => '00:00',
							'class'        => 'pum-half pum-last',
							'dependencies' => array(
								'all_day' => 'no',
							),
						),
						'separator'  => array(
							'type' => 'separator',
						),
						'end_date'   => array(
							'label' => __( 'End Date', 'pum-scheduling' ),
							'desc'  => __( 'Choose end date.', 'pum-scheduling' ),
							'type'  => 'date',
							'std'   => date( 'Y-m-d', strtotime( '+7 days' ) ),
							'class' => 'pum-half',
						),
						'end_time'   => array(
							'label'        => __( 'End Time', 'pum-scheduling' ),
							'desc'         => __( 'Choose end time.', 'pum-scheduling' ),
							'type'         => 'time',
							'std'          => '23:59:59',
							'class'        => 'pum-half pum-last',
							'dependencies' => array(
								'all_day' => 'no',
							),
						),
						'all_day'    => array(
							'label'   => __( 'All Day?', 'pum-scheduling' ),
							'type'    => 'select',
							'options' => array(
								'yes' => __( 'Yes', 'pum-scheduling' ),
								'no'  => __( 'No', 'pum-scheduling' ),
							),
							'std'     => 'yes',
						),
					),
				) ),
			),
			'office_hours' => array(
				'name'            => __( 'Office Hours', 'pum-scheduling' ),
				'settings_column' => sprintf( __( '%s from %s to %s', 'pum-scheduling' ), $this->days_of_week_settings_column_text(), '{{data.start_time}}', '{{data.end_time}}' ),
				'fields'          => array_merge_recursive( $this->schedule_fields(), array(
					'main' => array(
						'days_of_week' => array(
							'label'   => __( 'Days of Week', 'pum-scheduling' ),
							'desc'    => __( 'Choose start date.', 'pum-scheduling' ),
							'type'    => 'multicheck',
							'options' => array(
								'd0' => __( 'Sunday', 'pum-scheduling' ),
								'd1' => __( 'Monday', 'pum-scheduling' ),
								'd2' => __( 'Tuesday', 'pum-scheduling' ),
								'd3' => __( 'Wednesday', 'pum-scheduling' ),
								'd4' => __( 'Thursday', 'pum-scheduling' ),
								'd5' => __( 'Friday', 'pum-scheduling' ),
								'd6' => __( 'Saturday', 'pum-scheduling' ),
							),
							'std'     => array( 'd1', 'd2', 'd3', 'd4', 'd5' ),
						),
						'start_time'   => array(
							'label' => __( 'Start Time', 'pum-scheduling' ),
							'desc'  => __( 'Choose start time.', 'pum-scheduling' ),
							'type'  => 'time',
							'std'   => '09:00',
							'class' => 'pum-half pum-last',
						),
						'end_time'     => array(
							'label' => __( 'End Time', 'pum-scheduling' ),
							'desc'  => __( 'Choose end time.', 'pum-scheduling' ),
							'type'  => 'time',
							'std'   => '17:00',
							'class' => 'pum-half pum-last',
						),
					),
				) ),
			),
		) );

		// @deprecated filter.
		$schedules = apply_filters( 'pum_sch_get_schedules', $schedules );

		$this->add_schedules( $schedules );
	}

	/**
	 * @param array $schedules
	 */
	public function add_schedules( $schedules = array() ) {
		foreach ( $schedules as $key => $schedule ) {
			if ( empty( $schedule['id'] ) && ! is_numeric( $key ) ) {
				$schedule['id'] = $key;
			}

			$this->add_schedule( $schedule );
		}
	}


	/**
	 * @param null $schedule
	 */
	public function add_schedule( $schedule = null ) {
		if ( ! empty( $schedule['id'] ) && ! isset ( $this->schedules[ $schedule['id'] ] ) ) {
			$schedule = wp_parse_args( $schedule, array(
				'id'              => '',
				'name'            => __( 'Schedule', 'pum-schedule' ),
				'modal_title'     => __( 'Schedule Settings', 'pum-schedule' ),
				'settings_column' => '',
				'priority'        => 10,
				'tabs'            => $this->get_tabs(),
				'fields'          => $this->schedule_fields(),
			) );

			// Add schedule fields for all schedules automatically.
			if ( empty( $schedule['fields'] ) ) {
				$schedule['fields'] = $this->schedule_fields();
			}

			$schedule['fields'] = PUM_Admin_Helpers::parse_tab_fields( $schedule['fields'] );

			$this->schedules[ $schedule['id'] ] = $schedule;
		}
	}

	/**
	 * Returns an array of section labels for all schedules.
	 *
	 * Use the filter pum_get_schedule_section_labels to add or modify labels.
	 *
	 * @return array
	 */
	public function get_tabs() {
		/**
		 * Filter the array of schedule section labels.
		 *
		 * @param array $to_do The list of schedule section labels.
		 */
		return apply_filters( 'pum_sch_get_schedule_tabs', array(
			'main'     => __( 'General', 'pum-scheduling' ),
			'advanced' => __( 'Advanced', 'pum-scheduling' ),
		) );
	}

	/**
	 * Returns the schedule fields used for schedule options.
	 *
	 * @uses filter pum_sch_get_schedule_fields
	 *
	 * @return array
	 *
	 */
	public function schedule_fields() {
		return apply_filters( 'pum_sch_get_schedule_fields', array(
			'main'     => array(
				'name'      => array(
					'label'    => __( 'Schedule Name', 'pum-scheduling' ),
					'priority' => 1,
				),
				'localtime' => array(
					'label' => __( 'Local Time', 'pum-scheduling' ),
					'desc'  => __( 'Apply the schedule based on the users local time, rather than server time.', 'pum-scheduling' ),
					'type'  => 'checkbox',
				),
			),
			'advanced' => array(),
		) );
	}

	/**
	 * @return array
	 */
	public function dropdown_list() {
		$_schedules = $this->get_schedules();
		$schedules  = array();

		foreach ( $_schedules as $id => $schedule ) {
			$schedules[ $id ] = $schedule['name'];
		}

		return $schedules;
	}

}
