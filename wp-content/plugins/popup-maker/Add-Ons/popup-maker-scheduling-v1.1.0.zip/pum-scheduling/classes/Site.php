<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PUM_SCH Site class
 *
 * @since       1.2.0
 */
class PUM_SCH_Site {

	/**
	 * Initialize Hooks & Filters
	 */
	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_filter( 'pum_generated_js', array( __CLASS__, 'generated_js' ) );
		add_action( 'pum_preload_popup', array( __CLASS__, 'enqueue_popup_assets' ) );
		add_filter( 'pum_vars', array( __CLASS__, 'pum_vars' ) );
	}

	/**
	 *
	 */
	public static function assets() {
		wp_register_script( 'moment', PUM_SCH::$URL . 'assets/js/moment' . PUM_Site_Assets::$suffix . '.js', null, '2.22.0', true );
		wp_register_script( 'moment-timezone-2012-2022', PUM_SCH::$URL . 'assets/js/moment-timezone-with-data-2012-2022' . PUM_Site_Assets::$suffix . '.js', array( 'moment' ), '0.5.14', true );

		if ( ! PUM_AssetCache::writeable() ) {
			wp_register_script( 'pum-sch', PUM_SCH::$URL . 'assets/js/pum-sch-site' . PUM_Site_Assets::$suffix . '.js', array( 'popup-maker-site', 'moment', 'moment-timezone-2012-2022' ), PUM_SCH::$VER, true );
		}
	}

	/**
	 * @param array $js
	 *
	 * @return array
	 */
	public static function generated_js( $js = array() ) {
		$js['sch'] = array(
			'content'  => file_get_contents( PUM_SCH::$DIR . '/assets/js/pum-sch-site' . PUM_Site_Assets::$suffix . '.js' ),
			'priority' => 5,
		);

		return $js;
	}

	/**
	 * @param int $popup_id
	 */
	public static function enqueue_popup_assets( $popup_id = 0 ) {
		$popup = pum_get_popup( $popup_id );

		if ( ! pum_is_popup( $popup ) ) {
			return;
		}

		$schedules = $popup->get_setting( 'schedules', array() );

		if ( empty( $schedules )) {
			// Check for deprecated settings storage.
			$schedules = $popup->get_meta( 'popup_schedules', true );
		}

		// This condition should match that in classes/Popup.php::conditions() method.
		if ( count( $schedules ) ) {
			wp_enqueue_script( 'moment' );
			wp_enqueue_script( 'moment-timezone-2012-2022' );
			wp_enqueue_script( 'pum-sch' );
		}
	}

	/**
	 * @param $vars
	 *
	 * @return mixed
	 */
	public static function pum_vars( $vars ) {
		$vars['gmt_offset'] = get_option( 'gmt_offset' );
		$vars['server_timezone'] = get_option( 'timezone_string' );

		return $vars;
	}
}
