<?php

// Exit if accessed directly

/*******************************************************************************
 * Copyright (c) 2018, WP Popup Maker
 ******************************************************************************/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PUM_SCH Popup class
 */
class PUM_SCH_Popup {

	/**
	 * Initialize Hooks & Filters
	 */
	public static function init() {
		add_filter( 'pum_popup_get_conditions', array( __CLASS__, 'conditions' ), 10, 3 );
	}

	/**
	 * @param $conditions
	 * @param $popup_id
	 * @param $filters
	 *
	 * @return mixed
	 */
	public static function conditions( $conditions, $popup_id, $filters ) {

		if ( is_admin() ) {
			return $conditions;
		}

		if ( empty( $filters['js_only'] ) || ! $filters['js_only'] ) {
			return $conditions;
		}

		$popup = pum_get_popup( $popup_id );

		$schedules = $popup->get_setting( 'schedules', array() );

		if ( $schedules && is_array( $schedules ) && ! empty( $schedules ) ) {
			$array = array(
				array(
					'target'    => 'scheduled',
					'schedules' => $schedules,
				),
			);

			array_unshift( $conditions, $array );
		}

		return $conditions;
	}

}
