=== Popup Maker - Scheduling ===
Contributors: wppopupmaker, danieliser
Author URI: https://wppopupmaker.com/
Plugin URI: https://wppopupmaker.com/extensions/scheduling/
Tags: 
Requires at least: 3.6
Tested up to: 4.7.2
Stable tag: 1.1.0

== Description ==


== Changelog ==

= v1.1.0 - 05/16/2018 =
* Feature: Added Office Hours & Chosen Dates schedule types.
* Improvement: Separated Date & Time fields for better control, added options to ignore time for "All Day" schedules.
* Improvement: Updated schedule settings preview descriptions to be more helpful.
* Improvement: Updated for full Popup Maker v1.7 support.
* Improvement: Upgraded to the latest version of FlatPickr date fields to address some prior issues.
* Improvement: Upgraded to the latest version of MomentJS and improved the timezone calculations in edge cases.
* Fix: Bug with range date pickers.
* Fix: Bug with End times not appearing in table view.

= v1.0.1 =
* Tweak: Updated to v1.5 fields api.
* Fix: Bug where schedules overwrote Advanced Targeting Conditions.

= v1.0.0 =
* Initial Release
