var PUM_SCH;
(function ($) {
    "use strict";

    var I10n = pum_admin_vars.I10n,
        schedules = {
            get_schedules: function () {
                return window.pum_popup_settings_editor.schedules;
            },
            get_schedule: function (type) {
                var _schedules = schedules.get_schedules();
                return _schedules[type] !== undefined ? _schedules[type] : false;
            },
            template: {
                form: function (type, values, callback) {
                    var schedule = schedules.get_schedule(type),
                        modalID = 'pum_schedule_settings',
                        firstTab = Object.keys(schedule.fields)[0],
                        $cookies = $('.pum-field-cookies .list-table tbody tr');

                    values = values || {};
                    values.type = type;
                    values.index = values.index >= 0 ? values.index : null;

                    // Add hidden index & type fields.
                    schedule.fields[firstTab] = $.extend(true, schedule.fields[firstTab], {
                        index: {
                            type: 'hidden',
                            name: 'index'
                        },
                        type: {
                            type: 'hidden',
                            name: 'type'
                        }
                    });

                    PUM_Admin.modals.reload('#' + modalID, PUM_Admin.templates.modal({
                        id: modalID,
                        title: schedule.modal_title || schedule.name,
                        classes: 'tabbed-content',
                        save_button: values.index !== null ? I10n.update : I10n.add,
                        content: PUM_Admin.forms.render({
                            id: 'pum_schedule_settings_form',
                            tabs: schedule.tabs || {},
                            fields: schedule.fields || {}
                        }, values || {})
                    }));

                    $('#' + modalID + ' form').on('submit', function (event) {

                        if (typeof callback === 'function') {
                            callback.apply(this, arguments);
                        }

                        event.preventDefault();
                        PUM_Admin.modals.closeAll();

                    });
                },
                editor: function (args) {
                    var data = $.extend(true, {}, {
                        schedules: [],
                        name: ''
                    }, args);

                    data.schedules = PUM_Admin.utils.object_to_array(data.schedules);

                    return PUM_Admin.templates.render('pum-schedules-editor', data);
                },
                row: function (args) {
                    var data = $.extend(true, {}, {
                        index: '',
                        type: '',
                        name: '',
                        settings: {}
                    }, args);

                    return PUM_Admin.templates.render('pum-schedule-row', data);
                },
                selectbox: function (args) {
                    var data = $.extend(true, {}, {
                        id: null,
                        name: null,
                        type: 'select',
                        group: '',
                        index: '',
                        value: null,
                        select2: true,
                        classes: [],
                        options: schedules.select_list()
                    }, args);

                    if (data.id === null) {
                        data.id = 'popup_settings_schedules_' + data.index + '_type';
                    }

                    if (data.name === null) {
                        data.name = 'popup_settings[schedules][' + data.index + '][type]';
                    }

                    return PUM_Admin.templates.field(data);
                }
            },
            getLabel: function (type) {
                var schedule = schedules.get_schedule(type);
                return schedule ? schedule.name : '';
            },
            getSettingsDesc: function (type, values) {
                var schedule = schedules.get_schedule(type);
                return PUM_Admin.templates.renderInline(schedule ? schedule.settings_column : '', values);
            },
            renumber: function () {
                $('#pum_popup_schedules_list').find('tbody tr').each(function () {
                    var $this = $(this),
                        index = $this.parent().children().index($this);

                    $this.attr('data-index', index).data('index', index);

                    $this.find(':input, [name]').each(function () {
                        if (this.name && this.name !== '') {
                            this.name = this.name.replace(/\[\d*?\]/, "[" + index + "]");
                        }
                    });
                });
            },
            refreshDescriptions: function () {
                $('#pum_popup_schedules_list').find('tbody tr').each(function () {
                    var $row = $(this),
                        type = $row.find('.popup_schedules_field_type').val(),
                        values = JSON.parse($row.find('.popup_schedules_field_settings:first').val());

                    $row.find('td.settings-column').html(PUM_SCH.getSettingsDesc(type, values));
                });
            },
            rows: {
                add: function (editor, schedule) {
                    var $editor = $(editor),
                        data = {
                            index: schedule.index !== null && schedule.index >= 0 ? schedule.index : $editor.find('table.list-table tbody tr').length,
                            type: schedule.type,
                            name: $editor.data('field_name'),
                            settings: schedule.settings || {}
                        },
                        $row = $editor.find('tbody tr').eq(data.index),
                        $new_row = PUM_Admin.templates.render('pum-schedule-row', data);

                    if ($row.length) {
                        $row.replaceWith($new_row);
                    } else {
                        $editor.find('tbody').append($new_row);
                    }

                    $editor.addClass('has-list-items');

                    schedules.renumber();
                    schedules.refreshDescriptions();
                },
                remove: function ($schedule) {
                    var $editor = $schedule.parents('.pum-popup-schedule-editor');

                    $schedule.remove();
                    schedules.renumber();

                    if ($editor.find('table.list-table tbody tr').length === 0) {
                        $editor.removeClass('has-list-items');

                        $('#pum-first-schedule')
                            .val(null)
                            .trigger('change');
                    }
                }
            }
        };

    // Import this module.
    window.PUM_Admin = window.PUM_Admin || {};
    window.PUM_Admin.schedules = schedules;

    // Deprecated.
    window.PUM_SCH = schedules;

    $(document)
        .on('pum_init', function () {
            PUM_Admin.schedules.renumber();
            PUM_Admin.schedules.refreshDescriptions();

            $('#pum-first-schedule')
                .val(null)
                .trigger('change');
        })
        /**
         * @deprecated 1.7.0
         */
        .on('select2:select pumselect2:select', '#pum-first-schedule', function () {
            var $this = $(this),
                $editor = $this.parents('.pum-popup-schedule-editor'),
                type = $this.val(),
                values = {};

            // Set Current Editor.
            PUM_Admin.schedules.current_editor = $editor;

            PUM_Admin.schedules.template.form(type, values, function () {
                var $form = $(this),
                    type = $form.find('input#type').val(),
                    values = $form.pumSerializeObject(),
                    index = parseInt(values.index);

                if (index === false || index < 0) {
                    index = $editor.find('tbody tr').length;
                }

                PUM_Admin.schedules.rows.add($editor, {
                    index: index,
                    type: type,
                    settings: values
                });
            });

            $this
                .val(null)
                .trigger('change');
        })
        .on('click', '.pum-popup-schedule-editor .pum-add-new', function () {
            PUM_Admin.schedules.current_editor = $(this).parents('.pum-popup-schedule-editor');
            var template = wp.template('pum-schedule-add-type');
            PUM_Admin.modals.reload('#pum_schedule_add_type_modal', template({I10n: I10n}));
        })
        .on('click', '.pum-popup-schedule-editor .edit', function (event) {
            var $this = $(this),
                $editor = $this.parents('.pum-popup-schedule-editor'),
                $row = $this.parents('tr:first'),
                type = $row.find('.popup_schedules_field_type').val(),
                values = _.extend({}, JSON.parse($row.find('.popup_schedules_field_settings:first').val()), {
                    index: $row.parent().children().index($row),
                    type: type,
                    // TODO Compare if this (older) method (from existing pum-sch) or the above of merging to the core values object is preferrable
                    settings: JSON.parse($row.find('.popup_schedules_field_settings:first').val())
                });

            event.preventDefault();

            PUM_Admin.schedules.template.form(type, values, function () {
                var $form = $(this),
                    type = $form.find('input#type').val(),
                    index = $form.find('input#index').val(),
                    values = $form.pumSerializeObject();

                // Set Current Editor.
                PUM_Admin.schedules.current_editor = $editor;

                if (index === false || index < 0) {
                    index = $editor.find('tbody tr').length;
                }

                PUM_Admin.schedules.rows.add($editor, {
                    index: index,
                    type: type,
                    settings: values
                });
            });
        })
        .on('click', '.pum-popup-schedule-editor .remove', function (event) {
            var $this = $(this),
                $editor = $this.parents('.pum-popup-schedule-editor'),
                $row = $this.parents('tr:first');

            // Set Current Editor.
            PUM_Admin.schedules.current_editor = $editor;

            event.preventDefault();

            if (window.confirm(I10n.confirm_delete_schedule)) {
                PUM_Admin.schedules.rows.remove($row);
            }
        })
        .on('submit', '#pum_schedule_add_type_modal .pum-form', function (event) {
            var $editor = PUM_Admin.schedules.current_editor,
                type = $('#popup_schedule_add_type').val(),
                values = {};

            event.preventDefault();

            PUM_Admin.schedules.template.form(type, values, function () {
                var $form = $(this),
                    type = $form.find('input#type').val(),
                    values = $form.pumSerializeObject(),
                    index = parseInt(values.index);

                // Set Current Editor.
                PUM_Admin.schedules.current_editor = $editor;

                if (!index || index < 0) {
                    index = $editor.find('tbody tr').length;
                }

                PUM_Admin.schedules.rows.add($editor, {
                    index: index,
                    type: type,
                    settings: values
                });
            });
        });
}(jQuery));