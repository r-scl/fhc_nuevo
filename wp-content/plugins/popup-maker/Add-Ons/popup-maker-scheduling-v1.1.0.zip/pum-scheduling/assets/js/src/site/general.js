var PUM_SCH;
(function ($) {
    "use strict";

    var gmt_offset = pum_vars.gmt_offset || "00:00",
        server_timezone = pum_vars.server_timezone || null,
        missing_setting_return_value = false;

    $.extend($.fn.popmake.conditions, {
        scheduled: function (settings) {
            var schedules = settings.schedules,
                i,
                schedule,
                checks = [];

            for (i = 0; schedules.length > i; i++) {
                schedule = schedules[i];
                if (typeof $.fn.popmake.schedules[schedule.type] === 'function') {
                    checks.push($.fn.popmake.schedules[schedule.type](processSettings(schedule.settings)));
                }
            }

            return checks.indexOf(true) >= 0;
        }
    });

    function convertMomentToServerTime(_moment) {
        var offset = parseInt(gmt_offset);

        if (server_timezone && server_timezone !== '') {
            offset = moment.tz(server_timezone).format("Z");
        }

        return _moment.clone().utcOffset(offset, true);
    }

    function processSettings(settings) {
        settings = $.extend({}, {
            localtime: false,
            start_date: null,
            start_time: null,
            end_date: null,
            end_time: null,
            all_day: 'yes',
            chosen_dates: null,
            days_of_week: null,
            // @deprecated vars.
            datetime: null,
            start: '',
            end: ''
        }, settings);

        /**
         * If all day set start/end times correctly.
         *
         * Explicitly only for certain types of schedules.
         */
        if (['start','end','range','dates'].indexOf(settings.type) >= 0 && settings.all_day === 'yes') {
            settings.start_time = '00:00:00';
            settings.end_time = '23:59:59';
        }

        /**
         * Build start datetime & moment.
         */
        if (settings.start_date) {
            settings.start_datetime = settings.start_date + ' ' + settings.start_time;
            settings.start = moment(settings.start_datetime);

            if (!settings.localtime) {
                settings.start = convertMomentToServerTime(settings.start);
            }
        }

        /**
         * Build end datetime & moment.
         */
        if (settings.end_date) {
            settings.end_datetime = settings.end_date + ' ' + settings.end_time;
            settings.end = moment(settings.end_datetime);

            if (!settings.localtime) {
                settings.end = convertMomentToServerTime(settings.end);
            }
        }

        /**
         * Build chosen_dates array.
         */
        if (settings.chosen_dates) {
            settings.chosen_dates = settings.chosen_dates.split(',').map($.trim);
        }

        /**
         * Build days_of_week array.
         */
        if (settings.days_of_week) {
            settings.days_of_week = Object.keys(settings.days_of_week) || [];
        }

        return settings;
    }

    $.fn.popmake.schedules = $.fn.popmake.schedules || {};

    $.extend($.fn.popmake.schedules, {
        start: function (settings) {
            if (!settings.start_date) {
                return missing_setting_return_value;
            }

            return moment().isAfter(settings.start);
        },
        end: function (settings) {
            if (!settings.end_date) {
                return missing_setting_return_value;
            }

            return moment().isBefore(settings.end);
        },
        dates: function (settings) {
            if (!settings.chosen_dates || !settings.chosen_dates.length) {
                return missing_setting_return_value;
            }

            var current = moment(),
                chosen_dates = settings.chosen_dates,
                start,
                end;

            for (var i = 0; i < chosen_dates.length; i++) {
                // Check if this is the chosen date is the same as today.
                if (current.isSame(chosen_dates[i], 'd')) {
                    // If its an all day schedule return true.
                    if (settings.all_day === 'yes') {
                        return true;
                    }

                    start = moment(chosen_dates[i] + ' ' + settings.start_time);
                    end = moment(chosen_dates[i] + ' ' + settings.end_time);

                    if (!settings.localtime) {
                        start = convertMomentToServerTime(start);
                        end = convertMomentToServerTime(end);
                    }

                    return current.isSameOrAfter(start) && current.isSameOrBefore(end);
                }
            }

            return false;
        },
        range: function (settings) {
            if (!settings.start_date || !settings.end_date) {
                return missing_setting_return_value;
            }

            var current = moment();

            return current.isSameOrAfter(settings.start) && current.isSameOrBefore(settings.end);
        },
        office_hours: function (settings) {
            if (!settings.days_of_week) {
                return missing_setting_return_value;
            }

            var current = moment(),
                today = current.day(),
                start = moment(settings.start_time, 'H:m'),
                end = moment(settings.end_time, 'H:m'),
                day_of_week;

            if (!settings.localtime) {
                start = convertMomentToServerTime(start);
                end = convertMomentToServerTime(end);
            }

            for (var i = 0; i < settings.days_of_week.length; i++) {
                day_of_week = parseInt(settings.days_of_week[i].replace('d', ''));

                // Check if this is the chosen date is the same as today.
                if (day_of_week !== today) {
                    continue;
                }

                return current.isSameOrAfter(start) && current.isSameOrBefore(end);
            }

            return false;
        }
    });


}(window.jQuery));