/*******************************************************************************
 * Copyright (c) 2018, WP Popup Maker
 ******************************************************************************/
(function ($) {
    "use strict";

    var datepicker = {
        init: function () {
            var $date = $('.pum-date:not(.pum-flatpickr-initialized)'),
                $time = $('.pum-time:not(.pum-flatpickr-initialized)'),
                $dates = $('.pum-dates:not(.pum-flatpickr-initialized)'),
                $datetime = $('.pum-datetime:not(.pum-flatpickr-initialized)'),
                $daterange = $('.pum-date-range:not(.pum-flatpickr-initialized)'),
                $datetimerange = $('.pum-datetime-range:not(.pum-flatpickr-initialized)');

            if ($date.length) {
                $date
                    .addClass('pum-flatpickr-initialized')
                    .flatpickr({
                        wrap: true,
                        static: true
                    });
            }

            if ($time.length) {
                $time
                    .addClass('pum-flatpickr-initialized')
                    .flatpickr({
                        wrap: true,
                        static: true,
                        enableTime: true,
                        noCalendar: true,
                        dateFormat: "H:i"
                    });
            }

            if ($dates.length) {
                $dates
                    .addClass('pum-flatpickr-initialized')
                    .flatpickr({
                        wrap: true,
                        mode: "multiple",
                        static: true
                    });
            }

            if ($datetime.length) {
                $datetime
                    .addClass('pum-flatpickr-initialized')
                    .flatpickr({
                        wrap: true,
                        enableTime: true,
                        static: true
                    });
            }

            if ($daterange.length) {
                $daterange
                    .addClass('pum-flatpickr-initialized')
                    .flatpickr({
                        wrap: true,
                        mode: "range",
                        static: true
                    });
            }

            if ($datetimerange.length) {
                $daterange
                    .addClass('pum-flatpickr-initialized')
                    .flatpickr({
                        wrap: true,
                        enableTime: true,
                        mode: "range",
                        static: true
                    });
            }

        }
    };

// Import this module.
    window.PUM_Admin = window.PUM_Admin || {};
    window.PUM_Admin.datepicker = datepicker;

    $(document).on('pum_init', datepicker.init);
}(jQuery));