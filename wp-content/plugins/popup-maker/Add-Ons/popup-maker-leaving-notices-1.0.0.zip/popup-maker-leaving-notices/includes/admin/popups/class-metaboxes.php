<?php

// Exit if accessed directly
if( ! defined( 'ABSPATH' ) ) exit;

/**
 * Main PopMake_Age_Verification_Modals_Admin_Popup_Metaboxes class
 *
 * @since       1.0.0
 */
class PopMake_Leaving_Notices_Admin_Popup_Metaboxes {

    public static function init() {
        add_action( 'add_meta_boxes', array( __CLASS__, 'register' ) );
        add_filter( 'popmake_popup_meta_fields', array( __CLASS__, 'meta_fields' ) );
        add_filter( 'popmake_popup_meta_field_groups', array( __CLASS__, 'meta_field_groups' ) );
        add_filter( 'popmake_popup_meta_field_group_leaving_notices', array( __CLASS__, 'meta_field_group_leaving_notices' ) );
        add_filter( 'popmake_popup_leaving_notices_defaults', array( __CLASS__, 'leaving_notices_defaults' ) );
    }
    
    
    public static function register() {
        /** Age Verification Modals Meta **/
        add_meta_box( 'popmake_popup_leaving_notices', __( 'Leaving Notices', 'popup-maker-leaving-notices' ),  array( __CLASS__, 'leaving_notices_meta_box' ), 'popup', 'normal', 'high' );
    }

    public static function meta_fields( $fields ) {
        return array_merge( $fields, array(
            'popup_leaving_notices_defaults_set',
        ) );
    }

    public static function meta_field_groups( $groups ) {
        return array_merge( $groups, array(
            'leaving_notices',
        ) );
    }

    public static function meta_field_group_leaving_notices( $fields ) {
        return array_merge( $fields, array(
            'enabled',
            'target_blank',
        ) );
    }


    public static function leaving_notices_defaults( $defaults ) {
        return array_merge( $defaults, array(
            'enabled'      => NULL,
            'target_blank' => NULL,
        ) );
    }

    /**
     * Popup AJAX Login Modals Metabox
     *
     * Extensions (as well as the core plugin) can add items to the popup display
     * configuration metabox via the `popmake_popup_leaving_notices_modals_meta_box_fields` action.
     *
     * @since 1.0
     * @return void
     */
    public static function leaving_notices_meta_box() {
        global $post; ?>
        <input type="hidden" name="popup_leaving_notices_defaults_set" value="true" />
        <div id="popmake_popup_leaving_notices_modals_fields" class="popmake_meta_table_wrap">
            <table class="form-table">
                <tbody>
                    <?php do_action( 'popmake_popup_leaving_notices_meta_box_fields', $post->ID );?>
                </tbody>
            </table>
        </div><?php
    }


}
PopMake_Leaving_Notices_Admin_Popup_Metaboxes::init();
