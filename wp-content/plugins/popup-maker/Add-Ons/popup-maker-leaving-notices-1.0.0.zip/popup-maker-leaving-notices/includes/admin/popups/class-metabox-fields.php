<?php

// Exit if accessed directly
if( ! defined( 'ABSPATH' ) ) exit;

/**
 * Main PopMake_Leaving_Notices_Admin_Popup_Metabox_Fields class
 *
 * @since       1.0.0
 */
class PopMake_Leaving_Notices_Admin_Popup_Metabox_Fields {

	public static function init() {
		add_action( 'popmake_popup_leaving_notices_meta_box_fields', array( __CLASS__, 'enabled' ), 10 );
		add_action( 'popmake_popup_leaving_notices_meta_box_fields', array( __CLASS__, 'target_blank' ), 20 );
	}

	public static function enabled( $popup_id ) { ?>
		<tr>
		<th scope="row"><?php _e( 'Enable Leaving Notice', 'popup-maker-leaving-notices' );?></th>
		<td>
			<input type="checkbox" value="true" name="popup_leaving_notices_enabled" id="popup_leaving_notices_enabled" <?php checked( popmake_get_popup_leaving_notices( $popup_id, 'enabled' ), 'true' );?>/>
			<label for="popup_leaving_notices_enabled" class="description"><?php _e( 'Checking this will cause popup to open when the user tries to leave your site by clicking a link.', 'popup-maker-leaving-notices' );?></label>
		</td>
		</tr><?php
	}

	public static function target_blank( $popup_id ) { ?>
		<tr>
		<th scope="row"><?php _e( 'Open in New Window', 'popup-maker-leaving-notices' );?></th>
		<td>
			<input type="checkbox" value="true" name="popup_leaving_notices_target_blank" id="popup_leaving_notices_target_blank" <?php checked( popmake_get_popup_leaving_notices( $popup_id, 'target_blank' ), 'true' );?>/>
			<label for="popup_leaving_notices_target_blank" class="description"><?php _e( 'Continue links will open in a new window or tab.', 'popup-maker-leaving-notices' );?></label>
		</td>
		</tr><?php
	}

}
PopMake_Leaving_Notices_Admin_Popup_Metabox_Fields::init();
