<?php

// Exit if accessed directly
if( !defined( 'ABSPATH' ) ) {
	exit;
}

class PopMake_Leaving_Notices_Site {

	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'scripts' ) );
		add_filter( 'the_popup_content', array( __CLASS__, 'popup_content_filter' ), 10, 2 );
		add_filter( 'popmake_get_the_popup_classes', array( __CLASS__, 'popup_classes' ), 5, 2 );
		add_filter( 'popmake_get_the_popup_data_attr', array( __CLASS__, 'popup_data_attr' ), 0, 2 );
	}

	public static function popup_data_attr( $data_attr, $popup_id ) {
		if ( popmake_get_popup_leaving_notices( $popup_id, 'enabled' )) {
			$data_attr['meta']['leaving_notices'] = popmake_get_popup_leaving_notices( $popup_id );
		}
		return $data_attr;
	}

	public static function popup_content_filter( $content, $popup_id ) {
		if ( popmake_get_popup_leaving_notices( $popup_id, 'enabled' ) && ! has_shortcode( $content, 'continue_link' ) ) {
			$content .= '[continue_link]';
		}

		return $content;
	}

	public static function popup_classes( $classes, $popup_id ) {
		if ( popmake_get_popup_leaving_notices( $popup_id, 'enabled' ) ) {
			$classes[] = 'leaving-notice';
		}
		return $classes;
	}



	public static function scripts() {
		// Use minified libraries if SCRIPT_DEBUG is turned off
		$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';

		wp_enqueue_script( 'popmake_leaving_notices_js', POPMAKE_LEAVINGNOTICES_URL . 'assets/js/scripts' . $suffix . '.js', array( 'jquery', 'popup-maker-site' ), POPMAKE_LEAVINGNOTICES_VER, true );
		wp_enqueue_style( 'popmake_leaving_notices_css', POPMAKE_LEAVINGNOTICES_URL . 'assets/css/styles' . $suffix . '.css', POPMAKE_LEAVINGNOTICES_VER );
	}


}
PopMake_Leaving_Notices_Site::init();
