<?php

// Exit if accessed directly
if( !defined( 'ABSPATH' ) ) {
	exit;
}

class PopMake_Leaving_Notices_Admin {

	public static function init() {
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'scripts' ), 100 );
		add_action( 'admin_init', array( __CLASS__, 'install_check' ) );
	}

	public function install_check() {
		$version = get_option( 'popmake_leaving_notices_version' );
		update_option( 'popmake_leaving_notices_version', POPMAKE_LEAVINGNOTICES_VER );
	}

	public static function scripts( $hook ) {
		global $popmake_popup_page;

		// Use minified libraries if SCRIPT_DEBUG is turned off
		$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';

		if( $hook == $popmake_popup_page ) {
			wp_enqueue_script( 'popmake_leaving_notices_admin_js', POPMAKE_LEAVINGNOTICES_URL . '/assets/js/admin' . $suffix . '.js', array( 'jquery', 'popup-maker-admin' ) );
			wp_enqueue_style( 'popmake_leaving_notices_admin_css', POPMAKE_LEAVINGNOTICES_URL . '/assets/css/admin' . $suffix . '.css' );
		}
	}


}
PopMake_Leaving_Notices_Admin::init();
