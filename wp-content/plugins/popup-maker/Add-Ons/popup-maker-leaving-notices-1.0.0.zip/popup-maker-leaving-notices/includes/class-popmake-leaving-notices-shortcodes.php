<?php

// Exit if accessed directly
if( !defined( 'ABSPATH' ) ) {
	exit;
}

class PopMake_Leaving_Notices_Shortcodes {

	public static function init() {
		add_shortcode( 'continue_link', array( __CLASS__, 'continue_link' ) );
	}

	public static function continue_link( $atts ) {

		extract( shortcode_atts( array(
			'text' => __( 'Continue', 'popup-maker-leaving-notices' )
		), $atts, 'continue_link' ) );


		$target_blank = popmake_get_popup_leaving_notices( null, 'target_blank', false );

		ob_start(); ?>

		<div class="popmake-continue-link">
			<a class="do-default" href="#" <?php echo $target_blank ? 'target="_blank"' : ''; ?>><?php echo $text; ?></a>
		</div><?php

		return ob_get_clean();
	}


}
PopMake_Leaving_Notices_Shortcodes::init();
