<?php
/**
 * Plugin Name:     Popup Maker - Leaving Notices
 * Plugin URI:      https://wppopupmaker.com/extensions/leaving-notices/
 * Description:     Quickly create leaving notices to warn your users they are about to leave your site via external links.
 * Version:         1.0.0
 * =
 * Author:          Daniel Iser
 * Author URI:      https://wppopupmaker.com/
 * Text Domain:     popup-maker-leaving-notices
 *
 * @package         PopMake\LeavingNotices
 * @author          Daniel Iser
 * @copyright       Copyright (c) 2015
 *
 */


// Exit if accessed directly
if( !defined( 'ABSPATH' ) ) {
    exit;
}

if( !class_exists( 'PopMake_Leaving_Notices' ) ) {

    /**
     * Main PopMake_Leaving_Notices class
     *
     * @since       1.0.0
     */
    class PopMake_Leaving_Notices {
        /**
         * @var         PopMake_Leaving_Notices $instance The one true PopMake_Leaving_Notices
         * @since       1.0.0
         */
        private static $instance;


        /**
         * Get active instance
         *
         * @access      public
         * @since       1.0.0
         * @return      object self::$instance The one true PopMake_Leaving_Notices
         */
        public static function instance() {
            if( !self::$instance ) {
                self::$instance = new PopMake_Leaving_Notices();
                self::$instance->setup_constants();
                self::$instance->includes();
                self::$instance->load_textdomain();

                self::$instance->register_fields();
                self::$instance->hooks();

            }

            return self::$instance;
        }


        /**
         * Setup plugin constants
         *
         * @access      private
         * @since       1.0.0
         * @return      void
         */
        private function setup_constants() {
            // Plugin version
            define( 'POPMAKE_LEAVINGNOTICES_VER', '1.0.0' );

            // Plugin path
            define( 'POPMAKE_LEAVINGNOTICES_DIR', plugin_dir_path( __FILE__ ) );

            // Plugin URL
            define( 'POPMAKE_LEAVINGNOTICES_URL', plugin_dir_url( __FILE__ ) );
        }


        /**
         * Include necessary files
         *
         * @access      private
         * @since       1.0.0
         * @return      void
         */
        private function includes() {
            // Include scripts
            require_once POPMAKE_LEAVINGNOTICES_DIR . 'includes/class-popmake-leaving-notices-shortcodes.php';
            require_once POPMAKE_LEAVINGNOTICES_DIR . 'includes/class-popmake-leaving-notices-site.php';
            require_once POPMAKE_LEAVINGNOTICES_DIR . 'includes/class-popmake-leaving-notices-admin.php';
            require_once POPMAKE_LEAVINGNOTICES_DIR . 'includes/functions.php';
            require_once POPMAKE_LEAVINGNOTICES_DIR . 'includes/admin/popups/class-metaboxes.php';
            require_once POPMAKE_LEAVINGNOTICES_DIR . 'includes/admin/popups/class-metabox-fields.php';
        }


        /**
         * Run action and filter hooks
         *
         * @access      private
         * @since       1.0.0
         * @return      void
         *
         */
        private function hooks() {
            // Register settings
            //add_filter( 'popmake_settings_extensions', array( $this, 'settings' ), 1 );

            // Handle licensing
            if( class_exists( 'PopMake_License' ) ) {
                new PopMake_License( __FILE__, 'Leaving Notices', POPMAKE_LEAVINGNOTICES_VER, 'Daniel Iser' );
            }
        }


        /**
         * Internationalization
         *
         * @access      public
         * @since       1.0.0
         * @return      void
         */
        public function load_textdomain() {
            // Set filter for language directory
            $lang_dir = POPMAKE_LEAVINGNOTICES_DIR . '/languages/';
            $lang_dir = apply_filters( 'popmake_leaving_notices_languages_directory', $lang_dir );

            // Traditional WordPress plugin locale filter
            $locale = apply_filters( 'plugin_locale', get_locale(), 'popup-maker-leaving-notices' );
            $mofile = sprintf( '%1$s-%2$s.mo', 'popup-maker-leaving-notices', $locale );

            // Setup paths to current locale file
            $mofile_local   = $lang_dir . $mofile;
            $mofile_global  = WP_LANG_DIR . '/popup-maker-leaving-notices/' . $mofile;

            if( file_exists( $mofile_global ) ) {
                // Look in global /wp-content/languages/popup-maker-leaving-notices/ folder
                load_textdomain( 'popup-maker-leaving-notices', $mofile_global );
            } elseif( file_exists( $mofile_local ) ) {
                // Look in local /wp-content/plugins/popup-maker-leaving-notices/languages/ folder
                load_textdomain( 'popup-maker-leaving-notices', $mofile_local );
            } else {
                // Load the default language files
                load_plugin_textdomain( 'popup-maker-leaving-notices', false, $lang_dir );
            }
        }


        /**
         * Add settings
         *
         * @access      public
         * @since       1.0.0
         * @param       array $settings The existing Popup Maker settings array
         * @return      array The modified Popup Maker settings array
         */
        public function settings( $settings ) {
            $new_settings = array(
                array(
                    'id'    => 'popmake_leaving_notices_settings',
                    'name'  => '<strong>' . __( 'Leaving Notices Settings', 'popup-maker-leaving-notices' ) . '</strong>',
                    'desc'  => __( 'Configure Leaving Notices Settings', 'popup-maker-leaving-notices' ),
                    'type'  => 'header',
                )
            );

            return array_merge( $settings, $new_settings );
        }


        public function register_fields() {

            if ( version_compare( POPMAKE_VERSION, '1.3', '>=' ) ) {

                Popmake_Popup_Fields::instance()->register_section(
                    'leaving_notices',
                    __( 'Leaving Notices', 'popup-maker-leaving-notices' )
                );

                Popmake_Popup_Fields::instance()->add_fields( 'leaving_notices', array(
                    'enabled'        => array(
                        'label'       => __( 'Enable Leaving Notice', 'popup-maker-leaving-notices' ),
                        'description' => __( 'Checking this will cause popup to open when the user tries to leave your site by clicking a link.', 'popup-maker-leaving-notices' ),
                        'type'        => 'checkbox',
                        'std'         => false,
                        'priority'    => 0,
                    ),
                    'target_blank'        => array(
                        'class' => 'leaving-notices-enabled',
                        'label'       => __( 'Open in New Window', 'popup-maker-leaving-notices' ),
                        'description' => __( 'Continue links will open in a new window or tab.', 'popup-maker-leaving-notices' ),
                        'type'        => 'checkbox',
                        'std'         => false,
                        'priority'    => 5,
                    ),
                    /*
                    'type'         => array(
                        'class' => 'leaving-notices-enabled',
                        'label'       => __( 'Type', 'popup-maker-leaving-notices' ),
                        'description' => __( 'Choose the type of exit prevention to use.', 'popup-maker-leaving-notices' ),
                        'type'        => 'select',
                        'std'         => 'soft',
                        'priority'    => 5,
                        'options'     => apply_filters( 'popmake_eip_exit_popup_type_options', array(
                            __( 'Soft', 'popup-maker-leaving-notices' ) => 'soft',
                            __( 'Hard', 'popup-maker-leaving-notices' ) => 'hard',
                            __( 'Both', 'popup-maker-leaving-notices' ) => 'both',
                            __( 'Hard Alert Only', 'popup-maker-leaving-notices' ) => 'alert',
                        ) )
                    ),
                    'top_sensitivity' => array(
                        'class' => 'leaving-notices-enabled soft-only',
                        'label'       => __( 'Top Sensitivity', 'popup-maker-leaving-notices' ),
                        'description' => __( 'This defines the distance from the top of the browser window where the users mouse movement is detected.', 'popup-maker-leaving-notices' ),
                        'type'        => 'rangeslider',
                        'std'         => 10,
                        'priority'    => 10,
                        'step'        => apply_filters( 'popup_leaving_notices_top_sensitivity_step', 1 ),
                        'min'         => apply_filters( 'popup_leaving_notices_top_sensitivity_min', 1 ),
                        'max'         => apply_filters( 'popup_leaving_notices_top_sensitivity_max', 50 ),
                        'unit'        => __( 'px', 'popup-maker-leaving-notices' ),
                    ),
                    'delay_sensitivity' => array(
                        'class' => 'leaving-notices-enabled soft-only',
                        'label'       => __( 'False Positive Delay', 'popup-maker-leaving-notices' ),
                        'description' => __( 'This defines the delay used for false positive detection. A higher value reduces false positives, but increases chances of not opening in time.', 'popup-maker-leaving-notices' ),
                        'type'        => 'rangeslider',
                        'std'         => 350,
                        'priority'    => 15,
                        'step'        => apply_filters( 'popup_leaving_notices_delay_sensitivity_step', 25 ),
                        'min'         => apply_filters( 'popup_leaving_notices_delay_sensitivity_min', 100 ),
                        'max'         => apply_filters( 'popup_leaving_notices_delay_sensitivity_max', 750 ),
                        'unit'        => __( 'ms', 'popup-maker-leaving-notices' ),
                    ),
                    'hard_message'    => array(
                        'class' => 'leaving-notices-enabled hard-only',
                        'label'       => __( 'Prompt Message', 'popup-maker-leaving-notices' ),
                        'placeholder' => __( 'Are you sure you want to leave?', 'popup-maker-leaving-notices' ),
                        'description' => __( 'Enter the message displayed in the interrupt prompt.', 'popup-maker-leaving-notices' ),
                        'std'         => __( 'Please take a moment to check out a special offer just for you!', 'popup-maker-leaving-notices' ),
                        'priority'    => 20,
                    ),
                    'cookie_trigger' => array(
                        'class' => 'leaving-notices-enabled',
                        'label'       => __( 'Cookie Trigger', 'popup-maker' ),
                        'description' => __( 'When do you want to create the cookie.', 'popup-maker' ),
                        'type'        => 'select',
                        'std'         => 'close',
                        'priority'    => 25,
                        'options'     => apply_filters( 'popmake_eip_cookie_trigger_options', array(
                            __( 'Disabled', 'popup-maker' ) => 'disabled',
                            __( 'On Open', 'popup-maker' )  => 'open',
                            __( 'On Close', 'popup-maker' ) => 'close',
                            __( 'Manual', 'popup-maker' )   => 'manual',
                        ) ),
                    ),
                    'cookie_time'    => array(
                        'class' => 'leaving-notices-enabled',
                        'label'       => __( 'Cookie Time', 'popup-maker' ),
                        'placeholder' => __( '364 days 23 hours 59 minutes 59 seconds', 'popup-maker' ),
                        'description' => __( 'Enter a plain english time before cookie expires.', 'popup-maker' ),
                        'std'         => '1 month',
                        'priority'    => 30,
                    ),
                    'cookie_path'    => array(
                        'class' => 'leaving-notices-enabled',
                        'label'       => __( 'Sitewide Cookie', 'popup-maker' ),
                        'description' => __( '	This will prevent the popup from auto opening on any page until the cookie expires.', 'popup-maker' ),
                        'type'        => 'checkbox',
                        'std'         => true,
                        'priority'    => 35,
                    ),
                    'cookie_key'     => array(
                        'class' => 'leaving-notices-enabled',
                        'label'       => __( 'Cookie Key', 'popup-maker' ),
                        'description' => __( 'Resetting this will cause all existing cookies to be invalid.', 'popup-maker' ),
                        'std'         => '',
                        'priority'    => 40,
                    ),

                    */
                ) );

            }

        }


    }
} // End if class_exists check


/**
 * The main function responsible for returning the one true PopMake_Leaving_Notices
 * instance to functions everywhere
 *
 * @since       1.0.0
 * @return      PopMake_Leaving_Notices The one true PopMake_Leaving_Notices
 */
function popmake_leaving_notices_load() {
    if( ! class_exists( 'Popup_Maker' ) ) {
        if( ! class_exists( 'PopMake_Extension_Activation' ) ) {
            require_once 'includes/class.extension-activation.php';
        }

        $activation = new PopMake_Extension_Activation( plugin_dir_path( __FILE__ ), basename( __FILE__ ) );
        $activation = $activation->run();
    } else {
        PopMake_Leaving_Notices::instance();
    }
}
add_action( 'plugins_loaded', 'popmake_leaving_notices_load' );


/**
 * The activation hook is called outside of the singleton because WordPress doesn't
 * register the call from within the class, since we are preferring the plugins_loaded
 * hook for compatibility, we also can't reference a function inside the plugin class
 * for the activation function. If you need an activation function, put it here.
 *
 * @since       1.0.0
 * @return      void
 */
function popmake_leaving_notices_activation() {
    /* Activation functions here */
}
register_activation_hook( __FILE__, 'popmake_leaving_notices_activation' );
