(function ($) {
    "use strict";

}(jQuery));