(function ($) {
    "use strict";

    if ($.expr[':'].external === undefined) {
        $.expr[':'].external = function (obj) {
            return obj && obj.href && !obj.href.match(/^mailto:/)
                && (obj.hostname != document.location.hostname);
        };
    }

    if ($.expr[':'].internal === undefined && $.expr[':'].external !== undefined) {
        $.expr[':'].internal = function (obj) {
            return $(obj).is(':not(:external)');
        };
    }

    $('.popmake.leaving-notice')
        .on('popmakeInit', function () {
            var $this = $(this);

            $this.find('.popmake-continue-link a').on('click', function (e) {
                $this.popmake('close');
            });
        })
        .on('popmakeBeforeOpen', function () {
            var $this = $(this),
                trigger = $($.fn.popmake.last_open_trigger),
                url = '#';

            if (trigger.length && trigger.prop('href') !== '') {
                url = trigger.prop('href');
            }

            if ($this.has(trigger).length) {
                $this.addClass('preventOpen');
            }

            $this.find('.popmake-continue-link a').prop('href', url);
        });
}(jQuery));