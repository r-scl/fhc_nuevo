<?php
/**
 * Plugin Name:     Popup Maker - Aweber Integration
 * Plugin URI:      https://wppopupmaker.com
 * Description:     Adds Aweber Integration To Popup Maker
 * Version:         1.0.2
 * Author:          Frank Corso
 * Author URI:      https://wppopupmaker.com
 * Text Domain:     pum-aweber-integration
 *
 * @package         PopMake\Pum_Aweber_Integration
 * @author          Frank Corso
 * @copyright       Copyright (c) 2015
 */


// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'PUM_Aweber_Integration' ) ) {

	/**
	 * Main Pum_Aweber_Integration class
	 *
	 * @since       1.0.0
	 */
	class PUM_Aweber_Integration {

		/**
		 * @var         Pum_Aweber_Integration $instance The one true Pum_Aweber_Integration
		 * @since       1.0.0
		 */
		private static $instance;


		/**
		 * Get active instance
		 *
		 * @access      public
		 * @since       1.0.0
		 * @return      object self::$instance The one true Pum_Aweber_Integration
		 */
		public static function instance() {
			if ( ! self::$instance ) {
				self::$instance = new PUM_Aweber_Integration();
				self::$instance->setup_constants();
				self::$instance->includes();
				self::$instance->load_textdomain();
				self::$instance->hooks();
			}

			return self::$instance;
		}


		/**
		 * Setup plugin constants
		 *
		 * @access      private
		 * @since       1.0.0
		 * @return      void
		 */
		private function setup_constants() {
			// Plugin version
			define( 'PUM_AWEBER_INTEGRATION_VER', '1.0.2' );

			// Plugin path
			define( 'PUM_AWEBER_INTEGRATION_DIR', plugin_dir_path( __FILE__ ) );

			// Plugin URL
			define( 'PUM_AWEBER_INTEGRATION_URL', plugin_dir_url( __FILE__ ) );

			//Aweber app ID
			define( 'PUM_AW_INT_APP_ID', '1739a30a' );
		}


		/**
		 * Include necessary files
		 *
		 * @access      private
		 * @since       1.0.0
		 * @return      void
		 */
		private function includes() {
			// Include scripts
			require_once PUM_AWEBER_INTEGRATION_DIR . 'includes/scripts.php';
			require_once PUM_AWEBER_INTEGRATION_DIR . 'includes/functions.php';

			require_once PUM_AWEBER_INTEGRATION_DIR . 'includes/pum-newsletters/class-pum-newsletter.php';
			require_once PUM_AWEBER_INTEGRATION_DIR . 'includes/class-pum-newsletter-aweber.php';
		}


		/**
		 * Run action and filter hooks
		 *
		 * @access      private
		 * @since       1.0.0
		 * @return      void
		 */
		private function hooks() {
			// Register settings
			add_filter( 'popmake_settings_extensions', array( $this, 'settings' ), 1 );

			// Handle licensing
			if ( class_exists( 'PopMake_License' ) ) {
				$license = new PopMake_License( __FILE__, 'Aweber Integration', PUM_AWEBER_INTEGRATION_VER, 'Frank Corso' );
			}
		}


		/**
		 * Internationalization
		 *
		 * @access      public
		 * @since       1.0.0
		 * @return      void
		 */
		public function load_textdomain() {
			// Set filter for language directory
			$lang_dir = PUM_AWEBER_INTEGRATION_DIR . '/languages/';
			$lang_dir = apply_filters( 'pum_aweber_integration_languages_directory', $lang_dir );

			// Traditional WordPress plugin locale filter
			$locale = apply_filters( 'plugin_locale', get_locale(), 'pum-aweber-integration' );
			$mofile = sprintf( '%1$s-%2$s.mo', 'pum-aweber-integration', $locale );

			// Setup paths to current locale file
			$mofile_local  = $lang_dir . $mofile;
			$mofile_global = WP_LANG_DIR . '/pum-aweber-integration/' . $mofile;

			if ( file_exists( $mofile_global ) ) {
				// Look in global /wp-content/languages/pum-aweber-integration/ folder
				load_textdomain( 'pum-aweber-integration', $mofile_global );
			} elseif ( file_exists( $mofile_local ) ) {
				// Look in local /wp-content/plugins/pum-aweber-integration/languages/ folder
				load_textdomain( 'pum-aweber-integration', $mofile_local );
			} else {
				// Load the default language files
				load_plugin_textdomain( 'pum-aweber-integration', false, $lang_dir );
			}
		}


		/**
		 * Add settings
		 *
		 * @access      public
		 * @since       1.0.0
		 *
		 * @param       array $settings The existing Popup Maker settings array
		 *
		 * @return      array The modified Popup Maker settings array
		 * @todo        Needs to create settings to allow user to enter their API Key
		 */
		public function settings( $settings ) {
			$new_settings = array(
				array(
					'id'   => 'aw_int_settings',
					'name' => '<strong>' . __( 'Aweber Integration Settings', 'pum-aweber-integration' ) . '</strong>',
					'desc' => __( 'Configure Aweber Integration Settings', 'pum-aweber-integration' ),
					'type' => 'header',
				),
				array(
					'id'   => 'aw_int_api_key',
					'name' => '<strong>' . __( 'Aweber Auth Code', 'pum-aweber-integration' ) . '</strong>',
					'desc' => __( 'Your Aweber Auth Code. Click here to get it: <a target="_blank" href="https://auth.aweber.com/1.0/oauth/authorize_app/' . PUM_AW_INT_APP_ID . '">Click to authorize</a>', 'pum-aweber-integration' ),
					'type' => 'text',
				),
				array(
					'id'   => 'aw_int_success_message',
					'name' => '<strong>' . __( 'Success Message', 'pum-aweber-integration' ) . '</strong>',
					'desc' => __( 'Message to show user when successfuly subscribed.', 'pum-aweber-integration' ),
					'type' => 'text',
				),
				array(
					'id'   => 'aw_int_invalid_email_message',
					'name' => '<strong>' . __( 'Invalid Email Message', 'pum-aweber-integration' ) . '</strong>',
					'desc' => __( 'Message to show user when an invalid email is entered.', 'pum-aweber-integration' ),
					'type' => 'text',
				),
				array(
					'id'   => 'aw_int_error_message',
					'name' => '<strong>' . __( 'Error Message', 'pum-aweber-integration' ) . '</strong>',
					'desc' => __( 'Message to show user when an errored occurred.', 'pum-aweber-integration' ),
					'type' => 'text',
				),
				array(
					'id'   => 'aw_int_already_subscribed_message',
					'name' => '<strong>' . __( 'Already Subscribed Message', 'pum-aweber-integration' ) . '</strong>',
					'desc' => __( 'Message to show user who is already subscribed.', 'pum-aweber-integration' ),
					'type' => 'text',
				),
				array(
					'id'   => 'aw_int_access_key',
					'type' => 'hidden',
				),
				array(
					'id'   => 'aw_int_access_secret',
					'type' => 'hidden',
				),
				array(
					'id'   => 'aw_int_consumer_key',
					'type' => 'hidden',
				),
				array(
					'id'   => 'aw_int_consumer_secret',
					'type' => 'hidden',
				),
			);

			return array_merge( $settings, $new_settings );
		}
	}
} // End if class_exists check


/**
 * The main function responsible for returning the one true Pum_Aweber_Integration
 * instance to functions everywhere
 *
 * @since       1.0.0
 * @return      Pum_Aweber_Integration The one true Pum_Aweber_Integration
 */
function pum_aweber_integration_load() {
	if ( ! class_exists( 'Popup_Maker' ) ) {
		if ( ! class_exists( 'PopMake_Extension_Activation' ) ) {
			require_once 'includes/class.extension-activation.php';
		}

		$activation = new PopMake_Extension_Activation( plugin_dir_path( __FILE__ ), basename( __FILE__ ) );
		$activation = $activation->run();
	} else {
		PUM_Aweber_Integration::instance();
	}
}

add_action( 'plugins_loaded', 'pum_aweber_integration_load' );


/**
 * The activation hook is called outside of the singleton because WordPress doesn't
 * register the call from within the class, since we are preferring the plugins_loaded
 * hook for compatibility, we also can't reference a function inside the plugin class
 * for the activation function. If you need an activation function, put it here.
 *
 * @since       1.0.0
 * @return      void
 */
function pum_aweber_integration_activation() {
	/* Activation functions here */
}

register_activation_hook( __FILE__, 'pum_aweber_integration_activation' );
