<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class that handles all of the newsletter for Aweber
 *
 * @package     PopMake\Pum_Aweber_Integration\PUM_Newsletter_Aweber
 * @since 1.0.0
 */
class PUM_Newsletter_Aweber extends PUM_Newsletter {

	/**
	 * Subscribes the user to the list
	 *
	 * @access    public
	 * @since        1.0.0
	 * @return    array The array used to send results and message to shortcode
	 */
	public function subscribe_to_email( $fields, $json_response ) {

		//Only run this function if the service is aweber
		if ( strtolower( $this->service ) !== strtolower( $fields['service'] ) && ( strtolower( popmake_get_option( 'newsletter_default' ) ) !== strtolower( $this->service ) ) ) {
			return $json_response;
		}

		//Loads api key
		$api_key       = popmake_get_option( 'aw_int_api_key' );
		$consumer_key    = popmake_get_option( 'aw_int_consumer_key' );
		$consumer_secret = popmake_get_option( 'aw_int_consumer_secret' );
		$access_key    = popmake_get_option( 'aw_int_access_key' );
		$access_secret = popmake_get_option( 'aw_int_access_secret' );
		if ( ! $api_key || empty( $api_key ) ) {
			$json_response["api_error_message"] = 'API Key not given';

			return $json_response;
		}

		//includes the wrapper if needed
		if ( ! class_exists( "AWeberAPI" ) ) {
			require_once( PUM_AWEBER_INTEGRATION_DIR . "includes/aweber_api/aweber_api.php" );
		}

		//Check to make sure the fields are present
		if ( 'none' == $fields["list_id"] ) {
			$json_response["message"] = 'List ID is invalid';

			return $json_response;
		}

		//Loads variables from submission
		$list                    = trim( str_replace( 'awlist', '', $fields["list_id"] ) );
		$name                    = ! empty( $fields["name"] ) ? $fields["name"] : '';
		$email                   = $fields["email"];
		$json_response["result"] = 'success';

		//Tries to subscribe user to Aweber list
		try {

			//Gets user's Aweber account
			$aweber  = new AWeberAPI( $consumer_key, $consumer_secret );
			$account = $aweber->getAccount( $access_key, $access_secret );

			//subscribe them
			$listURL     = "/accounts/{$account->id}/lists/{$list}";
			$list        = $account->loadFromUrl( $listURL );
			$subscribers = $list->subscribers;

			$results = $subscribers->create( array(
				'email' => $email,
				'name'  => trim( $name ),
			) );
		} catch ( AWeberAPIException $exc ) {
			//If doesn't subscribe, log error
			$json_response["api_error_message"] = $exc->type . ' : ' . $exc->message;
			$json_response["result"]            = 'error';

			//Add returned message to api err msg and then change error_type
			if ( 'WebServiceError' === $exc->type && strpos( $exc->message, 'already subscribed.' ) !== false ) {
				$json_response["error_type"] = 'already_subscribed';
			}

		}

		return $json_response;
	}
}

$args                  = array( 'list_id' );
$messages              = array(
	'error'              => popmake_get_option( 'aw_int_error_message' ),
	'email'              => popmake_get_option( 'aw_int_invalid_email_message' ),
	'success'            => popmake_get_option( 'aw_int_success_message' ),
	'already_subscribed' => popmake_get_option( 'aw_int_already_subscribed_message' ),
);
$pum_newsletter_aweber = new PUM_Newsletter_Aweber( $args, $messages, 'aweber' );
