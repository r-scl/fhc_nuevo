<?php
/**
 * Helper Functions
 *
 * @package     PopMake\Pum_Aweber_Integration\Functions
 * @since       1.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter( 'popmake_settings_extensions_sanitize', 'aw_int_save_settings' );

/**
 * Retrieves Access Key And Secret
 *
 * Uses the Aweber auth code to retrieve key and secret. Then stores them into the extension settings
 *
 * @since 1.0.0
 *
 * @param array $settings Settings passed by the extensions settings tab upon saving
 *
 * @return array The modified settings
 */
function aw_int_save_settings( $settings ) {

	if ( isset( $settings["aw_int_api_key"] ) && ! empty( $settings["aw_int_api_key"] ) ) {

		// Test for changed api token.
		$has_changed = popmake_get_option( 'aw_int_api_key', '' ) != $settings["aw_int_api_key"];

		// Test for missing keys.
		$key_check = array(
			! empty( $settings["aw_int_access_key"] ),
			! empty( $settings["aw_int_access_secret"] ),
			! empty( $settings["aw_int_consumer_key"] ),
			! empty( $settings["aw_int_consumer_secret"] ),
		);

		if ( $has_changed || in_array( false, $key_check ) ) {
			//includes the wrapper if needed
			if ( ! class_exists( "AWeberAPI" ) ) {
				require_once( PUM_AWEBER_INTEGRATION_DIR . "includes/aweber_api/aweber_api.php" );
			}

			try {
				//Sets up connection to authorized app
				$auth = AWeberAPI::getDataFromAweberID( $settings["aw_int_api_key"] );
				list( $settings["aw_int_consumer_key"], $settings["aw_int_consumer_secret"], $settings["aw_int_access_key"], $settings["aw_int_access_secret"] ) = $auth;

			} catch ( AWeberAPIException $exc ) {
				unset( $settings["aw_int_consumer_key"], $settings["aw_int_consumer_secret"], $settings["aw_int_access_key"], $settings["aw_int_access_secret"] );
			}
		}
	} else {
		unset( $settings["aw_int_consumer_key"], $settings["aw_int_consumer_secret"], $settings["aw_int_access_key"], $settings["aw_int_access_secret"] );
	}

	return $settings;
}

if ( ! function_exists( 'popmake_hidden_callback' ) ) {

	/**
	 * Hidden Callback
	 *
	 * Renders hidden fields in settings
	 *
	 * @since 1.0.0
	 *
	 * @param array $args Arguments passed by the setting
	 *
	 * @global $popmake_options Array of all the POPMAKE Options
	 * @return void
	 */
	function popmake_hidden_callback( $args ) {

		global $popmake_options;
		if ( isset( $popmake_options[ $args['id'] ] ) ) {
			$value = $popmake_options[ $args['id'] ];
		} else {
			$value = isset( $args['std'] ) ? $args['std'] : '';
		}

		$html = '<input type="hidden" id="popmake_settings[' . $args['id'] . ']" name="popmake_settings[' . $args['id'] . ']" value="' . esc_attr( stripslashes( $value ) ) . '"/>';

		echo $html;
	}
}
