var PUMNewsletter;

(function ($) {
    PUMNewsletter = {

        //Function to submit the subscription form
        submit: function ($form) {
            var data = {
                action: 'pum_sub_form_submit',
                sub_data: $form.serialize()
            };

            $form.find('.sub_form_button').prop('disabled', true);
            $form.addClass('pum-sub-form-loading');
            $form.prepend('<span class="spinner-loader">Loading…</span>');

            $.ajax({
                url: pum_sub_ajax_object.ajaxurl,
                type: 'POST',
                dataType: 'json',
                data: data
            })
                .done(function (response) {
                    PUMNewsletter.response($form, response);
                })
                .fail(function (jqXHR, textStatus, errorThrown) {
                    console.log("Error: type of " + textStatus + " with message of " + errorThrown);
                });
        },

        //Function for displaying success or error message
        response: function ($form, response) {
            var data = response.data,
                error,
                i;

            $form.find('.spinner-loader').remove();

            if (response.success) {
                $($form).trigger('pumNewsletterSuccess');
                $form.addClass('pum-newsletter-success');
                $form.empty();
                $form.append('<p class="pum-newsletter-success-msg">' + data.message + '</p>');
            } else {
                //Log any api error message
                console.log(data.errors);

                //Trigger main error event, add main error class, and reset form
                $($form).trigger('pumNewsletterError');
                $form.addClass('pum-newsletter-error');
                $form.removeClass('pum-sub-form-loading');
                $form.find('.sub_form_button').prop('disabled', false);

                for (i = 0; data.errors.length > i; i++) {
                    error = data.errors[i];
                    $form.find('.pum-newsletter-error-msg').append($('<span>').text(error.message));

                    //Trigger event and add class for given error_type
                    switch (error.error_type) {
                    case 'already_subscribed':
                        $($form).trigger('pumNewsletterErrorAlreadySubscribed');
                        $form.addClass('pum-newsletter-error-already-subscribed');
                        break;
                    case 'empty_email':
                        $($form).trigger('pumNewsletterErrorEmptyEmail');
                        $form.addClass('pum-newsletter-error-empty-email');
                        break;
                    case 'empty_name_email':
                        $($form).trigger('pumNewsletterErrorEmptyNameEmail');
                        $form.addClass('pum-newsletter-error-empty-name-email');
                        break;
                    case 'invalid_email':
                        $($form).trigger('pumNewsletterErrorInvalidEmail');
                        $form.addClass('pum-newsletter-error-invalid-email');
                        break;
                    default:
                        $($form).trigger('pumNewsletterErrorDefault');
                        $form.addClass('pum-newsletter-error-default');
                    }
                }
            }
        }

    };

    $(document)
        .on('submit', 'form.pum_sub_form', function (event) {
            event.preventDefault();
            PUMNewsletter.submit($(this));
        });

}(jQuery));
