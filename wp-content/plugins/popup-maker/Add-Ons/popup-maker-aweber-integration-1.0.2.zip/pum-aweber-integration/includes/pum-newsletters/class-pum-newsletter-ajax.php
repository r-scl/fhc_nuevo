<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class that handles the ajax functions for the extension
 *
 * @package     PopMake\Pum_MailChimp_Integration\PUM_Newsletter_Ajax
 * @since 1.0.0
 */
class PUM_Newsletter_Ajax {

	/**
	 * Attaches the functions to the hooks
	 *
	 * @since 1.0.0
	 * @return void
	 * @access public
	 */
	public static function init() {
		add_action( 'wp_ajax_pum_sub_form_submit', array( 'PUM_Newsletter_Ajax', 'ajax_submit_shortcode' ) );
		add_action( 'wp_ajax_nopriv_pum_sub_form_submit', array( 'PUM_Newsletter_Ajax', 'ajax_submit_shortcode' ) );
	}

	/**
	 * Submits the form using ajax
	 *
	 * @access public
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_submit_shortcode() {

		$json_response_data = array();

		//Places the sub form data into $field_values
		parse_str( $_POST["sub_data"], $field_values );

		$errors = array();

		//Check to make sure the fields are present
		if ( ! isset( $field_values["email"] ) || empty( $field_values["email"] ) ) {
			$errors[] = array(
				'message'    => apply_filters( 'pum_newsletter_email_message', 'Email provided is not a valid email address.' ),
				'error_type' => 'empty_email',
				'field'      => 'email',
			);
		} elseif ( ! is_email( $field_values["email"] ) ) {
			$errors[] = array(
				'message'    => apply_filters( 'pum_newsletter_email_message', __( 'Please enter a valid email.', 'pum-mailchimp-integration' ) ),
				'error_type' => 'invalid_email',
				'field'      => 'email',
			);
		}

		//Runs through field validation
		$errors = apply_filters( 'pum_newsletter_validation', $errors, $field_values );

		if ( ! empty( $errors ) ) {
			wp_send_json_error( array( 'errors' => $errors ) );
			exit;
		}

		// Allow sanitization of fields.
		$field_values = apply_filters( 'pum_newsletter_sanitization', $field_values );

		//Runs through email service classes
		$api_response = apply_filters( 'pum_newsletter_ajax', $field_values, array(
			'result'            => 'error', //Accepted values are 'success' and 'error'
			'api_error_message' => '',
			'message'           => '',
		) );

		//If success was returned, then show success message
		if ( 'success' === $api_response["result"] ) {
			$json_response_data["message"] = apply_filters( 'pum_newsletter_success_message', __( 'You have been subscribed correctly!', 'pum-mailchimp-integration' ) );
		} else {
			//If not successful, show the correct error type's message
			switch ( $api_response["error_type"] ) {
				case 'already_subscribed':
					$json_response_data["message"] = apply_filters( 'pum_newsletter_already_sub_err_msg', __( 'You are already a subscriber.', 'pum-mailchimp-integration' ) );
					break;

				default:
					$errors[] = array(
						'message'           => apply_filters( 'pum_newsletter_err_message', __( 'Error occurred when subscribing. Please try again.', 'pum-mailchimp-integration' ) ),
						'error_type'        => isset( $api_response["error_type"] ) ? $api_response["error_type"] : '',
						'field'             => null,
						'api_error_message' => $api_response["api_error_message"],
					);
					break;
			}
		}

		if ( ! empty( $errors ) ) {
			wp_send_json_error( array( 'errors' => $errors ) );
		} else {
			wp_send_json_success( $json_response_data );
		}

		//Don't want anything extra going or wasting extra resources
		die();
	}
}

PUM_Newsletter_Ajax::init();
