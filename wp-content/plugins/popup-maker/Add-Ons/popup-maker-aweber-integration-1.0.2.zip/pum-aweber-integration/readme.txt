=== Popup Maker - Aweber Integration ===
Contributors: wppopupmaker, danieliser
Author URI: https://wppopupmaker.com/
Plugin URI: https://wppopupmaker.com/extensions/aweber-integration/
Tags: 
Requires at least: 3.6
Tested up to: 4.7.4
Stable tag: 1.0.2

== Description ==

== Changelog ==

= v1.0.2 =
* Improvment: Updated to work with the newer Aweber API authentication methods.

= v1.0.1 =
* Updated PUM-Newsletter SDK with better error handling & improved JS.

= v1.0 =
* Initial Release
