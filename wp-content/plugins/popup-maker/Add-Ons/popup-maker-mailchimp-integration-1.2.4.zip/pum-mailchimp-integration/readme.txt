=== Popup Maker - MailChimp Integration ===
Contributors: wppopupmaker, danieliser, frankcorso
Author URI: https://wppopupmaker.com/
Plugin URI: https://wppopupmaker.com/extensions/mailchimp-integration/
Tags:
Requires at least: 3.6
Tested up to: 4.8
Stable tag: 1.2.4

== Description ==

== Changelog ==

= v1.2.4 - 09/11/2017 =
* Fix: Added proper tests for core plugin being active.
* Fix: Issues with PHP 5.2 compatibility resolved.

= v1.2.3 - 06/22/2017 =
* Feature: Use field values in your success & error messages.
* Tweak: Added BLM style CSS enhancements.
* Improvement: Better error handling.
* Fix: Removed empty css assets from loading.

= v1.2.2 - 06/11/2017 =
* Fix: Bug that caused php errors when no interest groups were selected.

= v1.2.1 - 06/05/2017 =
* Fix: Bug that caused MailChimp api key setting fields to not render.

= v1.2.0 - 05/28/2017 =
* Feature: New PUM Newsletter sdk including new shortcode builder with live form previews in the editor.
* Feature: Choose a list for each form.
* Feature: Choose which interest groups a user should be added to for each form.
* Feature: Easy API Key check button to get immediate feedback on whether your key is valid.
* Feature: New Cookies:
  * Subscription Form: Successful
  * Subscription Form: Already Subscribed
* Feature: Customizable form labels
* Feature: Per form double opt in options.


= v1.1.1 - 04/13/2017 =
* Feature: Added name_optional & name_disabled attributes to the forms.

= v1.1.0 - 12/7/2015 =
* Adds ability to enable double opt-in confirmation emails

= v1.0.0 - 11/24/2015 =
* Initial Release