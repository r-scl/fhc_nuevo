<?php
/**
 * Plugin Name:     Popup Maker - MailChimp Integration
 * Plugin URI:      https://wppopupmaker.com/extensions/mailchimp-integration/
 * Description:     Adds MailChimp Integration To Popup Maker
 * Version:         1.2.4
 * Author:          WP Popup Maker
 * Author URI:      https://wppopupmaker.com/
 * Text Domain:     pum-mailchimp-integration
 *
 * @package         PUM\Integration
 * @author          Daniel Iser, Originally by Frank Corso
 * @copyright       Copyright (c) 2017
 */


// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Autoloader
 *
 * @param $class
 */
function pum_mci_autoloader( $class ) {

	// project-specific namespace prefix
	$prefix = 'PUM_MCI_';

	// base directory for the namespace prefix
	$base_dir = dirname( __FILE__ ) . '/classes/';

	// does the class use the namespace prefix?
	$len = strlen( $prefix );
	if ( strncmp( $prefix, $class, $len ) !== 0 ) {
		// no, move to the next registered autoloader
		return;
	}

	// get the relative class name
	$relative_class = substr( $class, $len );

	// replace the namespace prefix with the base directory, replace namespace
	// separators with directory separators in the relative class name, append
	// with .php
	$file = $base_dir . str_replace( '_', '/', $relative_class ) . '.php';

	// if the file exists, require it
	if ( file_exists( $file ) ) {
		require_once $file;
	}
}

if ( ! function_exists( 'spl_autoload_register' ) ) {
	include 'includes/compat.php';
}

spl_autoload_register( 'pum_mci_autoloader' ); // Register autoloader

/**
 * Main Pum_MailChimp_Integration class
 */
class PUM_MCI {

	/**
	 * @var int $download_id for EDD.
	 */
	public static $ID = 47915;

	/**
	 * @var string
	 */
	public static $NAME = 'MailChimp Integration';

	/**
	 * @var string
	 */
	public static $VER = '1.2.4';

	/**
	 * @var int DB Version
	 */
	public static $DB_VER = 2;

	/**
	 * @var string
	 */
	public static $URL = '';

	/**
	 * @var string
	 */
	public static $DIR = '';

	/**
	 * @var string
	 */
	public static $FILE = '';

	/**
	 * @var self $instance
	 */
	private static $instance;

	/**
	 * @var PUM_MCI_Provider
	 */
	public $provider;

	/**
	 * Get active instance
	 *
	 * @return self $instance
	 */
	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self;
			self::$instance->setup_constants();
			self::$instance->load_textdomain();
			self::$instance->includes();
			self::$instance->init();
		}

		return self::$instance;
	}

	/**
	 * Setup plugin constants
	 */
	private function setup_constants() {
		self::$DIR  = plugin_dir_path( __FILE__ );
		self::$URL  = plugins_url( '/', __FILE__ );
		self::$FILE = __FILE__;
	}

	/**
	 * Internationalization
	 */
	public function load_textdomain() {
		load_plugin_textdomain( 'pum-mailchimp-integration', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
	}

	/**
	 * Include necessary files
	 */
	private function includes() {
		require_once self::$DIR . 'includes/functions.php';
	}

	/**
	 * Run action and filter hooks
	 */
	private function init() {
		PUM_MCI_Admin::init();
		PUM_MCI_Site::init();
		PUM_MCI_Admin_Ajax::init();
		PUM_MCI_Updates::init();

		// Initialize the provider.
		$this->provider = new PUM_MCI_Provider();

		// Handle licensing
		if ( class_exists( 'PUM_Extension_License' ) ) {
			new PUM_Extension_License( self::$FILE, self::$NAME, self::$VER, 'WP Popup Maker', null, null, self::$ID );
		}
	}
}

class PUM_MailChimp_Integration extends PUM_MCI {}

function pum_mci() {
	return PUM_MCI::instance();
}

/**
 * Get the ball rolling. Fire up the correct version.
 */
function pum_mci_init() {
	if ( ! class_exists( 'Popup_Maker' ) && ! class_exists( 'PUM' ) ) {
		if ( ! class_exists( 'PUM_Extension_Activation' ) ) {
			require_once 'includes/pum-sdk/class-pum-extension-activation.php';
		}

		$activation = new PUM_Extension_Activation( plugin_dir_path( __FILE__ ), basename( __FILE__ ) );
		$activation->run();
	} else {
		// Initialize the Newsletter SDK.
		require_once 'includes/pum-newsletters/start.php';

		pum_mci();
	}
}

add_action( 'plugins_loaded', 'pum_mci_init' );
