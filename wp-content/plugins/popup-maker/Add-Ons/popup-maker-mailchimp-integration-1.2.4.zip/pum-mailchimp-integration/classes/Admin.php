<?php

/*******************************************************************************
 * Copyright (c) 2017, WP Popup Maker
 ******************************************************************************/
class PUM_MCI_Admin {

	public static function init() {
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
	}

	public static function assets() {
		if( ! popmake_is_admin_page() ) {
			return;
		}

		// Use minified libraries if SCRIPT_DEBUG is turned off
		$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
		wp_enqueue_script( 'pum-mci-admin', PUM_MCI::$URL . '/assets/js/pum-mailchimp-integration-admin' . $suffix . '.js', array( 'jquery', 'popup-maker-admin' ) );
		wp_enqueue_style( 'pum-mci-admin', PUM_MCI::$URL . '/assets/css/pum-mailchimp-integration-admin' . $suffix . '.css' );

		/**
		 * Include pum_newsletter_vars from the sdk.
		 */
		wp_localize_script( 'pum-mci-admin', 'pum_newsletter_vars', pum_get_newsletter_admin_localized_vars() );
	}
}