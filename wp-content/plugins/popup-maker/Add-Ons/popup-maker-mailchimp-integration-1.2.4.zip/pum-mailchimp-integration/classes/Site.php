<?php

/*******************************************************************************
 * Copyright (c) 2017, WP Popup Maker
 ******************************************************************************/
class PUM_MCI_Site {

	public static function init() {
		//add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
	}

	public static function assets() {
		// Use minified libraries if SCRIPT_DEBUG is turned off
		$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
		wp_enqueue_script( 'pum-mci', PUM_MCI::$URL . '/assets/js/pum-mailchimp-integration-site' . $suffix . '.js', array( 'jquery', 'popup-maker-site' ) );
		wp_enqueue_style( 'pum-mci', PUM_MCI::$URL . '/assets/css/pum-mailchimp-integration-site' . $suffix . '.css' );
	}
}