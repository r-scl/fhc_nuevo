<?php

/*******************************************************************************
 * Copyright (c) 2017, WP Popup Maker
 ******************************************************************************/
class PUM_MCI_Updates {

	public static function init() {
		add_action( 'admin_init', array( __CLASS__, 'check' ) );
	}

	public static function check() {

		$stored  = get_option( 'pum_mci_db_version', false );
		$current = PUM_MCI::$DB_VER;

		if ( ! $stored ) {
			$stored = PUM_Options::get( 'mc_int_api_key', false ) ? 1 : PUM_MCI::$DB_VER;
			update_option( 'pum_mci_db_version', $stored );
		}

		if ( $current - $stored > 0 ) {

			$start_time = microtime( true );

			while ( $stored < $current ) {
				$stored ++;

				if ( is_callable( array( __CLASS__, 'update_to_' . $stored ) ) ) {
					call_user_func( array( __CLASS__, 'update_to_' . $stored ) );
				}

				update_option( 'pum_mci_db_version', $stored );

				if ( microtime( true ) - $start_time > 30 ) {
					break;
				}
			}
		}
	}

	public static function update_to_2() {
		$api_key                    = PUM_Options::get( 'mc_int_api_key', false );
		$double_opt_in              = PUM_Options::get( 'mc_double_opt_in', false );
		$success_message            = PUM_Options::get( 'mc_int_success_message', false );
		$invalid_email_message      = PUM_Options::get( 'mc_int_invalid_email_message', false );
		$error_message              = PUM_Options::get( 'mc_int_error_message', false );
		$already_subscribed_message = PUM_Options::get( 'mc_int_already_subscribed_message', false );

		$pum_options = PUM_Options::get_all();

		$new_options = array(
			'mci_api_key'                    => $api_key,
			'mci_double_opt_in'              => $double_opt_in,
			'mci_success_message'            => $success_message,
			'mci_invalid_email_message'      => $invalid_email_message,
			'mci_error_message'              => $error_message,
			'mci_already_subscribed_message' => $already_subscribed_message,
		);

		foreach ( $new_options as $key => $val ) {
			if ( ! empty( $val ) ) {
				$pum_options[ $key ] = $val;
			}
		}

		unset( $pum_options['mc_int_api_key'], $pum_options['mc_double_opt_in'], $pum_options['mc_int_success_message'], $pum_options['mc_int_invalid_email_message'], $pum_options['mc_int_error_message'], $pum_options['mc_int_already_subscribed_message'] );

		update_option( 'popmake_settings', $pum_options );

		// Re-init the global settings.
		PUM_Options::init();

		// Refresh API Lists.
		pum_mci_check_api_key( $api_key );
	}

}