<?php

/*******************************************************************************
 * Copyright (c) 2017, WP Popup Maker
 ******************************************************************************/
class PUM_MCI_Provider extends PUM_Newsletter_Provider {

	/**
	 * @var string
	 */
	public $opt_prefix = 'mci_';

	/**
	 * @var string
	 */
	public $id = 'mailchimp';

	/**
	 * @var string
	 */
	public $name = 'MailChimp';

	/**
	 * PUM_MCI_Provider constructor.
	 */
	public function __construct() {
		parent::__construct();
		add_action( 'print_media_templates', array( $this, 'print_media_templates' ) );
	}

	/**
	 * Returns true if the api key is valid and enabled.
	 *
	 * @return bool
	 */
	public function enabled() {
		$api = pum_mci_get_api();

		return (bool) $api;
	}

	/**
	 * Adds a custom success message for double opt in subscribers.
	 *
	 * @param string $context
	 * @param array $values
	 *
	 * @return string
	 */
	public function get_message( $context, $values = array() ) {
		$double_opt_in = ! empty( $mc_args['double_opt_in'] ) ? $mc_args['double_opt_in'] : PUM_Options::get( 'mci_double_opt_in', 'enable' );

		if ( $context == 'success' && $double_opt_in != 'disable' ) {
			$context = 'double_opt_in_success';
		}

		return parent::get_message( $context, $values );
	}


	/**
	 * Registers the fields for this providers shortcode tab.
	 *
	 * @return array
	 */
	public function fields() {
		return array(
			'list_id'          => array(
				'label'   => __( 'List', 'pum-mailchimp-integration' ),
				'desc'    => __( 'Choose which list this form will submit to.', 'pum-mailchimp-integrationr' ),
				'type'    => 'select',
				'options' => pum_mci_get_list_selectlist(),
			),
			'interests'        => array(
				'label' => __( 'Interest Groups', 'pum-mailchimp-integrationr' ),
				'type'  => 'mci_interests',
				'class' => 'pum-field-multicheck',
			),
			'update_if_exists' => array(
				'label' => __( 'Update if Exists', 'pum-mailchimp-integration' ),
				'desc'  => __( 'If the user is already on your list update their name & interests.', 'pum-mailchimp-integrationr' ),
				'type'  => 'checkbox',
			),
			'double_opt_in'    => array(
				'label'   => __( 'Enable Double Opt-In', 'pum-mailchimp-integration' ),
				'desc'    => __( 'Enable the double opt-in to send users confirmation emails upon signing up', 'pum-mailchimp-integration' ),
				'type'    => 'select',
				'std'     => PUM_Options::get( 'mci_double_opt_in', 'enable' ),
				'options' => array_flip( array(
					'enable'  => __( 'Enable', 'pum-mailchimp-integration' ),
					'disable' => __( 'Disable', 'pum-mailchimp-integration' ),
				) ),
			),
		);
	}

	/**
	 * Default values for mc fields.
	 *
	 * @return array
	 */
	public function defaults() {
		return array(
			'list_id'          => '',
			'interests'        => array(),
			'double_opt_in'    => PUM_Options::get( 'mci_double_opt_in', 'enable' ),
			'update_if_exists' => false,
		);
	}

	/**
	 * @param array $values
	 *
	 * @return array $values
	 */
	public function form_sanitization( $values = array() ) {
		$values["mc_args"] = isset( $values["mc_args"] ) ? (array) json_decode( $values["mc_args"] ) : array();
		$name              = isset( $values["name"] ) ? $values["name"] : '';

		//Creates last name
		$name = explode( " ", $name );
		if ( ! isset( $name[1] ) ) {
			$name[1] = '';
		}

		$values['fname'] = $name[0];
		$values['lname'] = $name[1];

		$values['email'] = sanitize_email( $values["email"] );

		return $values;
	}

	/**
	 * @param WP_Error $errors
	 * @param array $values
	 *
	 * @return WP_Error
	 */
	public function form_validation( \WP_Error $errors, $values = array() ) {

		if ( ! pum_mci_is_api_key_valid() || ! pum_mci_get_api() ) {
			$errors->add( 'invalid_api_key', __( 'MailChimp API key is missing or invalid.', 'pum-mailchimp-integration' ) );

			return $errors;
		}

		$valid_lists = pum_mci_get_list_ids();

		//Check to make sure the fields are present
		if ( ! in_array( $values["list_id"], (array) $valid_lists ) ) {
			$errors->add( 'invalid_list_id', __( 'Invlaid List ID', 'pum-mailchimp-integration' ) );

			return $errors;
		}

		return $errors;
	}

	/**
	 * Subscribes the user to the list
	 *
	 * @param $values
	 * @param array $response
	 * @param \WP_Error $errors
	 *
	 * @return void
	 */
	public function form_submission( $values, &$response, \WP_Error &$errors ) {
		$email_hash    = md5( $values['email'] );
		$double_opt_in = ! empty( $values["mc_args"]['double_opt_in'] ) ? $values["mc_args"]['double_opt_in'] : PUM_Options::get( 'mci_double_opt_in', 'enable' );

		/**
		 * Reference: https://developer.mailchimp.com/documentation/mailchimp/reference/lists/members/
		 */
		$subscriber = array(
			'email_address' => sanitize_email( $values["email"] ),
			'status'        => 'disable' != $double_opt_in ? 'pending' : 'subscribed',
			'merge_fields'  => array(
				'FNAME' => $values['fname'],
				'LNAME' => $values['lname'],
			),
		);

		if ( ! empty( $values['interests'] ) ) {
			$interests = array();

			$_interests = explode( ',', $values['interests'] );

			foreach ( $_interests as $interest_id ) {
				$interests[ $interest_id ] = true;
			}

			$subscriber['interests'] = $interests;
		}

		$subscriber = apply_filters( 'pum_mailchimp_sub_list_args', $subscriber );

		$api = pum_mci_get_api();

		// Send request to MC API.
		if ( isset( $values["mc_args"]['update_if_exists'] ) ) {
			$api_response = $api->put( "/lists/{$values['list_id']}/members/{$email_hash}", $subscriber );
		} else {
			$api_response = $api->post( "/lists/{$values['list_id']}/members", $subscriber );
		}

		// Check the response.
		if ( ! $api->success() ) {

			if ( $api_response['title'] == 'Member Exists' ) {

				// Generate empty error code.
				$errors->add( 'already_subscribed', '' );

			} elseif ( strpos( $api_response['detail'], 'looks fake or invalid, please enter a real email address.' ) > 0 ) {

				$errors->add( 'invalid_email', pum_get_newsletter_provider_message( $this->id, 'invalid_email' ), 'email' );

			} else {

				$errors->add( 'api_errors', '' );
				$response['api_errors'] = array(
					'message'  => esc_js( $api->getLastError() ),
					'response' => $api_response,
				);

			}
		}
	}

	/**
	 * Contains array of field ids that will be inserted as a single json value be inserted into in the subscription forms.
	 *
	 * @var array
	 */
	public $form_args_keys = array(
		'update_if_exists',
		'double_opt_in',
	);

	/**
	 * Render fields.
	 *
	 * @param $shortcode_atts
	 */
	public function render_fields( $shortcode_atts ) {
		$mc_args = array();

		foreach ( $this->fields() as $key => $field ) {
			if ( in_array( $key, $this->form_args_keys ) ) {
				$mc_args[ $key ] = $shortcode_atts[ $key ];
			} else {
				switch ( $key ) {
					case 'interests':
						if ( is_array( $shortcode_atts[ $key ] ) ) {
							$shortcode_atts[ $key ] = implode( ',', $shortcode_atts[ $key ] );
						}
						echo '<input type="hidden" name="' . $key . '" value="' . $shortcode_atts[ $key ] . '" />';
						break;

					default:
						echo '<input type="hidden" name="' . $key . '" value="' . $shortcode_atts[ $key ] . '" />';
						break;
				}
			}
		}

		echo '<input type="hidden" name="mc_args" value="' . esc_attr( json_encode( $mc_args ) ) . '" />';

	}

	/**
	 * Register MC global settings
	 *
	 * @param array $settings
	 *
	 * @return array
	 */
	public function register_settings( $settings = array() ) {
		$new_settings = array(
			array(
				'id'   => 'mci_int_settings',
				'name' => __( 'MailChimp Integration Settings', 'pum-mailchimp-integration' ),
				'desc' => __( 'Configure MailChimp Integration Settings', 'pum-mailchimp-integration' ),
				'type' => 'header',
			),
			array(
				'id'      => 'mci_api_key',
				'name'    => __( 'MailChimp API Key', 'pum-mailchimp-integration' ),
				'desc'    => __( 'Your MailChimp API Key which can be found on the Account page in MailChimp.', 'pum-mailchimp-integration' ),
				'type'    => 'mc_api_key',
				'doclink' => 'https://docs.wppopupmaker.com',
			),
			array(
				'id'      => 'mci_double_opt_in',
				'name'    => __( 'Enable Double Opt-In', 'pum-mailchimp-integration' ),
				'desc'    => __( 'Enable the double opt-in to send users confirmation emails upon signing up', 'pum-mailchimp-integration' ),
				'type'    => 'select',
				'std'     => 'enable',
				'options' => array(
					'enable'  => __( 'Enable', 'pum-mailchimp-integration' ),
					'disable' => __( 'Disable', 'pum-mailchimp-integration' ),
				),
			),
			array(
				'id'   => 'mci_success_message',
				'name' => __( 'Success Message', 'pum-mailchimp-integration' ),
				'desc' => __( 'Message to show user when successfuly subscribed.', 'pum-mailchimp-integration' ),
				'type' => 'text',
			),
			array(
				'id'   => 'mci_double_opt_in_success_message',
				'name' => __( 'Double Opt In Success Message', 'pum-mailchimp-integration' ),
				'desc' => __( 'Message to show user when submitting the form that requires double opt in.', 'pum-mailchimp-integration' ),
				'type' => 'text',
			),
			array(
				'id'   => 'mci_invalid_email_message',
				'name' => __( 'Invalid Email Message', 'pum-mailchimp-integration' ),
				'desc' => __( 'Message to show user when an invalid email is entered.', 'pum-mailchimp-integration' ),
				'type' => 'text',
			),
			array(
				'id'   => 'mci_error_message',
				'name' => __( 'Error Message', 'pum-mailchimp-integration' ),
				'desc' => __( 'Message to show user when an errored occurred.', 'pum-mailchimp-integration' ),
				'type' => 'text',
			),
			array(
				'id'   => 'mci_already_subscribed_message',
				'name' => __( 'Already Subscribed Message', 'pum-mailchimp-integration' ),
				'desc' => __( 'Message to show user who is already subscribed.', 'pum-mailchimp-integration' ),
				'type' => 'text',
			),
		);

		return array_merge( $settings, $new_settings );
	}

	/**
	 *
	 */
	public function print_media_templates() { ?>

        <script type="text/html" id="tmpl-pum-field-mci_interests"><?php

			$lists = pum_mci_get_lists();

			if ( $lists ) {

				foreach ( $lists as $list ) {

					$categories = pum_mci_get_list_interest_categories( $list['id'] );

					if ( ! pum_mci_get_list_interests( $list['id'] ) || ! is_array( $categories ) ) {
						/**
						 * No Interest Categories, skip this one.
						 */
						continue;
					}

					?>

                    <!--<# if (!data.value) { data.value = []; } #>-->

                    <div id="pum-mci-list-<?php echo $list['id']; ?>" class="pum-mci-list-options">

						<?php foreach ( $categories as $category ) {

							$interests = pum_mci_get_list_interests( $list['id'], $category['id'] );

							if ( ! is_array( $interests ) ) {
								/**
								 * No Interests, skip this one.
								 */
								continue;
							} ?>

                            <label><?php echo $category['title']; ?></label>

							<?php foreach ( $interests as $interest ) : ?>
                                <!--<# var meta_data = PUM_Templates.prepareMeta({meta: {checked: data.value.indexOf('<?php echo $interest['id']; ?>') >= 0}}); #>-->
                                <input type="checkbox" id="{{data.id}}_<?php echo $interest['id']; ?>" name="{{data.name}}[<?php echo $interest['id']; ?>]" value="1" {{{meta_data.meta}}}/>&nbsp;
                                <label for="{{data.id}}_<?php echo $interest['id']; ?>"><?php echo $interest['name']; ?></label>
                                <br/><?php
							endforeach;


						} ?>

                    </div>
					<?php
				}
			} ?>
        </script>

		<?php
	}
}
