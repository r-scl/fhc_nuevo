<?php
/*******************************************************************************
 * Copyright (c) 2017, WP Popup Maker
 ******************************************************************************/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class PUM_MCI_Admin_Settings
 */
class PUM_MCI_Admin_Ajax {

	/**
	 * Initialize settings
	 */
	public static function init() {
		add_filter( 'wp_ajax_pum_mci_check_api_key', array( __CLASS__, 'check_api_key' ) );
	}

	/**
	 * Check an api key, save the key, and its status if valid, as well as the current set of lists.
	 */
	public static function check_api_key() {
		check_ajax_referer( 'pum-mci-check-api-key', 'nonce' );

		if ( empty( $_REQUEST['key'] ) ) {
			wp_send_json_error( __( 'Please enter your api key.', 'pum-mailchimp-integration' ) );
			die();
		}


		if ( pum_mci_check_api_key( $_REQUEST['key'] ) ) {
			$count = count( pum_mci_get_list_ids() );

			wp_send_json_success( sprintf( __( 'Your api key is valid. We found %d lists.', 'pum-mailchimp-integration' ), $count ) );
		} else {
			wp_send_json_error( __( 'Your api key does not appear to be valid.', 'pum-mailchimp-integration' ) );
		}
		die();
	}

}
