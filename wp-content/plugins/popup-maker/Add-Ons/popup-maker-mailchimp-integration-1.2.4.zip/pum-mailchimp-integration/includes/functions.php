<?php
/**
 * Helper Functions
 *
 * @package     PopMake\Pum_MailChimp_Integration\Functions
 * @since       1.0.0
 */


// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tests a new key and stores it, also pre-builds caches.
 *
 * @param $key
 *
 * @return bool
 */
function pum_mci_check_api_key( $key ) {
	try {
		$api = new PUM_MCI_MailChimp_API( $key );

		$lists = $api->get( 'lists' );

		if ( $lists === false ) {
			wp_send_json_error( __( 'Your api key does not appear to be valid.', 'pum-mailchimp-integration' ) );
		}

		PUM_Options::update( 'mci_api_key', $key );
		PUM_Options::update( 'mci_api_key_is_valid', true );

		pum_mci_prebuild_list_data();

		return true;
	} catch ( Exception $e ) {
	    return false;
    }

}

/**
 * Renders the MC API key field.
 *
 * @param $args
 */
function popmake_mc_api_key_callback( $args ) {
	global $popmake_options;

	if ( isset( $popmake_options[ $args['id'] ] ) ) {
		$value = $popmake_options[ $args['id'] ];
	} else {
		$value = isset( $args['std'] ) ? $args['std'] : '';
	}

	$size = ( isset( $args['size'] ) && ! is_null( $args['size'] ) ) ? $args['size'] : 'regular';

	$valid = ! empty( $value ) && PUM_Options::get( 'mci_api_key_is_valid', false );

	$icon = $valid ? 'yes' : 'no';

	$type = ! empty( $value ) ? 'password' : 'text'; ?>

    <input type="<?php esc_attr_e( $type ); ?>" class="<?php esc_attr_e( $size ); ?>-text" id="popmake_settings[<?php esc_attr_e( $args['id'] ); ?>]" name="popmake_settings[<?php esc_attr_e( $args['id'] ); ?>]" value="<?php esc_attr_e( stripslashes( $value ) ); ?>" />
    <button type="button" class="pum-mci-check-api-key">
		<?php _e( 'Check', 'popup-maker' ); ?>
        <i class="dashicons dashicons-<?php echo $icon; ?>" style="display: <?php echo ! empty( $value ) ? 'inline-block' : 'none'; ?>;"></i>
    </button>
	<?php wp_nonce_field( 'pum-mci-check-api-key', null ); ?>

	<?php if ( ! empty( $args['desc'] ) ) : ?><br />
        <label for="popmake_settings[<?php esc_attr_e( $args['id'] ); ?>]"><?php esc_html_e( $args['desc'] ); ?></label>
	<?php endif;
}

/**
 * @return bool|string
 */
function pum_mci_get_api_key() {
	return PUM_Options::get( 'mci_api_key', false );
}

/**
 * @return bool
 */
function pum_mci_is_api_key_valid() {
	return (bool) PUM_Options::get( 'mci_api_key_is_valid', false );
}

/**
 * @param null $key
 *
 * @return bool|PUM_MCI_MailChimp_API
 */
function pum_mci_get_api( $key = null ) {
	if ( ! $key ) {
		$key = pum_mci_get_api_key();
	}

	if ( ! $key ) {
		return false;
	}

	if ( ! pum_mci_is_api_key_valid() ) {
		return false;
	}

	static $instances = array();

	if ( isset( $instances[ $key ] ) ) {
		return $instances[ $key ];
	}

	try {
		$instances[ $key ] = new PUM_MCI_MailChimp_API( $key );

		return $instances[ $key ];
	} catch ( Exception $e ) {
		return false;
	}
}

/**
 * @return array|false
 */
function pum_mci_get_lists() {
	$lists = PUM_Options::get( 'mci_lists', false );

	if ( $lists === false ) {

		try {
			$api = pum_mci_get_api();

			if ( ! $api ) {
			    return false;
            }

			$lists = $api->get( 'lists' );

			if ( $lists === false ) {
				return false;
			}

			$lists = $lists['lists'];

			PUM_Options::update( 'mci_lists', $lists );
		} catch ( Exception $e ) {
			return false;
		}

	}

	return $lists;
}

/**
 * @return array|bool
 */
function pum_mci_get_list_ids() {
	$lists = pum_mci_get_lists();

	if ( ! $lists ) {
		return false;
	}

	$ids = array();

	foreach( $lists as $list ) {
		$ids[] = $list['id'];
	}

	return $ids;
}

function pum_mci_get_list_selectlist() {
	$lists = pum_mci_get_lists();

	if ( ! $lists ) {
		return false;
	}

	$selectlist = array();

	foreach( $lists as $list ) {
		$selectlist[ $list['name'] ] = $list['id'];
	}

	return $selectlist;
}

/**
 * @param $list_id
 *
 * @return bool
 */
function pum_mci_get_list_interest_categories( $list_id ) {
	$list_interest_categories = PUM_Options::get( 'mci_list_interest_categories', array() );

	if ( ! isset( $list_interest_categories[ $list_id ] ) ) {

		try {
			$api = pum_mci_get_api();

			if ( ! $api ) {
			    return false;
            }

			$interest_categories = $api->get( "lists/{$list_id}/interest-categories" );

			if ( $interest_categories === false ) {
				return false;
			}

			$list_interest_categories[ $list_id ] = $interest_categories['categories'];

			PUM_Options::update( 'mci_list_interest_categories', $list_interest_categories );
		} catch ( Exception $e ) {
			return false;
		}

	}

	return $list_interest_categories[ $list_id ];
}

function pum_mci_get_list_interest_category( $list_id, $category_id ) {
	$categories = pum_mci_get_list_interest_categories( $list_id );

	if ( ! $categories ) {
		return false;
	}

	return isset( $categories[ $category_id ] ) ? $categories[ $category_id ] : false;
}

/**
 * @param $list_id
 *
 * @return array|bool
 */
function pum_mci_get_list_interest_category_ids( $list_id ) {
    $categories = pum_mci_get_list_interest_categories( $list_id );

    if ( ! $categories || ! is_array( $categories ) ) {
        return false;
    }

    $ids = array();

    foreach( $categories as $category ) {
        $ids[] = $category['id'];
    }

    return $ids;
}



/**
 * @param $list_id
 * @param null $category_id
 *
 * @return bool|array
 */
function pum_mci_get_list_interests( $list_id, $category_id = null ) {
	$list_interests = PUM_Options::get( 'mci_list_interests', array() );

	if ( ! isset( $list_interests[ $list_id ] ) ) {

	    $categories = ! empty( $category_id ) ? array( $category_id ) : pum_mci_get_list_interest_category_ids( $list_id );

	    if ( ! $categories || empty( $categories ) ) {
	        return false;
        }

		try {
			$api = pum_mci_get_api();

			if ( ! $api ) {
			    return false;
            }

			foreach ( $categories as $cat_id ) {
				$interests = $api->get( "lists/{$list_id}/interest-categories/{$cat_id}/interests" );

				if ( $interests !== false ) {
					$list_interests[ $list_id ][ $cat_id ] = $interests['interests'];
				}
            }

			PUM_Options::update( 'mci_list_interests', $list_interests );
		} catch ( Exception $e ) {
			return false;
		}

	}

	if ( isset( $category_id ) ) {
	    return isset( $list_interests[ $list_id ][ $category_id ] ) ? $list_interests[ $list_id ][ $category_id ] : false;
    }

	return isset( $list_interests[ $list_id ] ) ? $list_interests[ $list_id ] : false;
}

/**
 * Flush stored list api data.
 */
function pum_mci_flush_lists() {
	PUM_Options::delete( 'mci_list_interests' );
	PUM_Options::delete( 'mci_list_interest_categories' );
	PUM_Options::delete( 'mci_lists' );
}


/**
 *
 */
function pum_mci_prebuild_list_data() {
    pum_mci_flush_lists();

	$lists = pum_mci_get_list_ids();

	foreach( $lists as $id ) {
		// Precache list data.
		pum_mci_get_list_interests( $id );
	}
}