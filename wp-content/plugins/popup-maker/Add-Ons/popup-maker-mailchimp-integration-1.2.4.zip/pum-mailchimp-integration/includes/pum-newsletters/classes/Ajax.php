<?php
/*******************************************************************************
 * Copyright (c) 2017, WP Popup Maker
 ******************************************************************************/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class that handles the ajax functions for the extension
 */
class PUM_Newsletter_Ajax {

	public static $errors;

	/**
	 * Attaches the functions to the hooks
	 */
	public static function init() {
		add_action( 'wp_ajax_pum_sub_form_submit', array( __CLASS__, 'ajax_submit_shortcode' ) );
		add_action( 'wp_ajax_nopriv_pum_sub_form_submit', array( __CLASS__, 'ajax_submit_shortcode' ) );
	}

	/**
	 * Submits the form using ajax
	 */
	public static function ajax_submit_shortcode() {
		self::$errors = new \WP_Error;

		$values = ! empty( $_REQUEST ) ? ! empty( $_REQUEST['values'] ) ? $_REQUEST['values'] : $_REQUEST : array();

		$values['provider'] = ! empty( $values['provider'] ) && $values['provider'] != 'none' ? sanitize_text_field( $values['provider'] ) : PUM_Options::get( 'newsletter_default_provider' );

		if ( ! $values['provider'] ) {
			wp_send_json_error();
		}

		do_action( 'pum_newsletter_form_override', $values );

		// Allow sanitization & manipulation of form values prior to usage.
		$values = apply_filters( 'pum_newsletter_form_sanitization', $values );

		if ( ! isset( $values["email"] ) || empty( $values["email"] ) ) {
			self::$errors->add( 'empty_email', '', 'email' );
		} elseif ( ! is_email( $values["email"] ) ) {
			self::$errors->add( 'invalid_email', '', 'email' );
		}

		// Allow validation of the data.
		self::$errors = apply_filters( 'pum_newsletter_form_validation', self::$errors, $values );

		if ( self::$errors->get_error_code() ) {
			self::send_errors( self::$errors );
		}

		$response = array();

		// Process the submission and pass the $response array as a reference variable.
		do_action_ref_array( 'pum_newsletter_form_submission', array( $values, &$response, &self::$errors ) );

		if ( ! self::$errors->get_error_code() ) {

			$response["message"] = pum_get_newsletter_provider_message( $values['provider'], 'success', $values );
			self::send_success( $response );

		} elseif ( self::$errors->get_error_code() == 'already_subscribed' ) {

			$response["message"] = pum_get_newsletter_provider_message( $values['provider'], 'already_subscribed', $values );
			self::send_success( $response );

		} else {

			switch ( self::$errors->get_error_code() ) {

				case 'api_errors':
					$response['message'] = pum_get_newsletter_provider_message( $values['provider'], 'error', $values );
					break;
			}

			self::send_errors( self::$errors, $response );
		}
		// Don't let it keep going.
		die();
	}

	public static function send_success( $response ) {
		wp_send_json_success( array_filter( $response ) );
		die;
	}


	public static function prepare_errors( \WP_Error $_errors ) {
		if ( ! $_errors || ! is_wp_error( $_errors ) ) {
			$_errors = self::$errors;
		}

		$errors = array();

		foreach ( $_errors->get_error_codes() as $code ) {
			$errors[] = array(
				'code'    => $code,
				'field'   => $_errors->get_error_data( $code ),
				'message' => $_errors->get_error_message( $code ),
			);
		}

		return $errors;
	}

	/**
	 * @param $errors \WP_Error
	 * @param array $extra_response_args
	 */
	public static function send_errors( \WP_Error $errors, $extra_response_args = array() ) {
		if ( ! $errors || ! is_wp_error( $errors ) ) {
			$errors = self::$errors;
		}

		$response = array_merge( $extra_response_args, array(
			'errors' => self::prepare_errors( $errors ),
		) );

		wp_send_json_error( $response );

		die();
	}

}
