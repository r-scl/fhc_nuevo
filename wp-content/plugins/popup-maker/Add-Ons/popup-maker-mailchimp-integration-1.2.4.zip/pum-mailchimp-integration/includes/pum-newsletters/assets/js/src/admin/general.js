/*******************************************************************************
 * Copyright (c) 2017, WP Popup Maker
 ******************************************************************************/
(function ($) {

    if (typeof window.pum_newsletter_initialized !== 'undefined') {
        return;
    }

    window.pum_newsletter_initialized = true;

    function check_provider() {
        var $provider = $('#pum-shortcode-editor-pum_sub_form #pum_shortcode_attrs_provider'),
            provider = $provider.val() !== 'none' ? $provider.val() : pum_newsletter_vars.default_provider,
            $provider_tabs = $('.pum-modal-content .tabs .tab a[href^="#pum-shortcode-editor-pum_sub_form_provider_"]'),
            $provider_contents = $('[id^="pum-shortcode-editor-pum_sub_form_provider_"]'),
            $selected_tab = $('.pum-modal-content .tabs .tab a[href="#pum-shortcode-editor-pum_sub_form_provider_' + provider + '"]'),
            $selected_contents = $('[id="pum-shortcode-editor-pum_sub_form_provider_' + provider + '"]');

        $provider_tabs.each(function() {
            console.log(this);
            $(this).parent().hide();
        });

        $provider_contents.find(':input').attr('disable', true);

        if ($selected_tab.length) {
            $selected_tab.parent().show();
            $selected_contents.find(':input').attr('disable', false);
        }
    }


    $(document)
        .on('pumInit pum_init', '#pum-shortcode-editor-pum_sub_form', check_provider)
        .on('change', '#pum-shortcode-editor-pum_sub_form #pum_shortcode_attrs_provider', check_provider);

}(jQuery));