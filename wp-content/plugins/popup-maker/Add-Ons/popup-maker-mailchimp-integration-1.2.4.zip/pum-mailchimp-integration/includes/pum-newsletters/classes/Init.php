<?php
/*******************************************************************************
 * Copyright (c) 2017, WP Popup Maker
 ******************************************************************************/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PUM_Newsletter_Init {

	public static function run() {
		add_filter( 'popmake_settings_extensions', array( __CLASS__, 'global_settings' ), 1 );
		add_action( 'init', array( __CLASS__, 'register_shortcodes' ) );

		add_filter( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ), 0 );
		add_filter( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_page_assets' ) );
		add_filter( 'popmake_enqueue_scripts', array( __CLASS__, 'enqueue_popup_scripts' ), 10, 2 );
		add_filter( 'popmake_enqueue_styles', array( __CLASS__, 'enqueue_popup_styles' ), 10, 2 );

		add_filter( 'pum_get_cookies', array( __CLASS__, 'register_cookies' ) );

		PUM_Newsletter_Ajax::init();
		PUM_Newsletter_Providers::instance();

		do_action( 'pum_newsletter_init' );
	}

	/**
	 * Register new shortcode.
	 */
	public static function register_shortcodes() {
		new PUM_Newsletter_Shortcode_Form();
	}

	/**
	 * Add settings
	 *
	 * @param array $settings The existing Popup Maker settings array
	 *
	 * @return array The modified Popup Maker settings array
	 */
	public static function global_settings( $settings ) {
		return apply_filters( 'pum_newsletter_settings', array_merge( $settings, array(
			array(
				'id'      => 'newsletter_default_provider',
				'name'    => __( 'Default Newsletter Provider', 'popup-maker' ),
				'desc'    => __( 'The default maling provider used for the subscription form.', 'popup-maker' ),
				'type'    => 'select',
				'options' => apply_filters( 'pum_newsletter_default', array_flip( PUM_Newsletter_Providers::selectlist() ) ),
			),
		) ) );
	}

	/**
	 * Register assets.
	 */
	public static function register_assets() {
		// Use minified libraries if SCRIPT_DEBUG is turned off
		$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';

		wp_register_style( 'pum-newsletter-site', PUM_NEWSLETTER_URL . 'assets/css/pum-newsletter-site' . $suffix . '.css', null, PUM_NEWSLETTER_VERSION );
		wp_register_script( 'pum-newsletter-site', PUM_NEWSLETTER_URL . 'assets/js/pum-newsletter-site' . $suffix . '.js', array( 'jquery' ), PUM_NEWSLETTER_VERSION, true );
		wp_localize_script( 'pum-newsletter-site', 'pum_sub_vars', array(
			'ajaxurl' => admin_url( 'admin-ajax.php' ),
			'message_position' => 'top',
		) );
	}

	/**
	 * Checks if the popup used our forms, loads the needed JS.
	 *
	 * @param $scripts
	 * @param $popup_id
	 *
	 * @return mixed
	 */
	public static function enqueue_popup_scripts( $scripts, $popup_id ) {

		$popup = pum_popup( $popup_id );

		if ( has_shortcode( $popup->post_content, 'pum_sub_form' ) ) {
			$scripts['pum-newsletter-site'] = 'pum-newsletter-site';
		}

		return $scripts;
	}


	/**
	 * Checks if the popup used our forms, loads the needed CSS.
	 *
	 * @param $styles
	 * @param $popup_id
	 *
	 * @return mixed
	 */
	public static function enqueue_popup_styles( $styles, $popup_id ) {
		$popup = pum_popup( $popup_id );

		if ( has_shortcode( $popup->post_content, 'pum_sub_form' ) ) {
			$styles['pum-newsletter-site'] = 'pum-newsletter-site';
		}

		return $styles;
	}

	/**
	 * Checks the current page content for the newsletter shortcode.
	 */
	public static function enqueue_page_assets() {
		global $post;

		if ( ! empty( $post ) && has_shortcode( $post->post_content, 'pum_sub_form' ) ) {
			wp_enqueue_script( 'pum-newsletter-site' );
			wp_enqueue_style( 'pum-newsletter-site' );
		}
	}

	public static function register_cookies( $cookies = array() ) {
		return array_merge( $cookies, array(
			'pum_sub_form_success'             => array(
				'labels' => array(
					'name' => __( 'Subscription Form: Successful', 'popup-maker-ajax-login-modals' ),
				),
				'fields' => pum_get_cookie_fields(),
			),
			'pum_sub_form_already_subscribed' => array(
				'labels' => array(
					'name' => __( 'Subscription Form: Already Subscribed', 'popup-maker-ajax-login-modals' ),
				),
				'fields' => pum_get_cookie_fields(),
			),
		) );
	}
}

