<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( did_action( 'pum_newsletter_init' ) ) {
	/**
	 * Already initialized.
	 */
	return;
}

define( 'PUM_NEWSLETTER_VERSION', '2.0.0' );
define( 'PUM_NEWSLETTER_URL', plugins_url( '/', __FILE__ ) );
define( 'PUM_NEWSLETTER_PATH', plugin_dir_path( __FILE__ ) );

require_once 'includes/autoload.php';
require_once 'includes/functions.php';

/**
 * Get things started.
 */
PUM_Newsletter_Init::run();