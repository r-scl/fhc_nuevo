var PUMNewsletter;
(function ($) {
    'use strict';

    var messages   = {
            add: function ($form, messages, type) {
                var $messages = $form.find('.pum-form__messages'),
                    i         = 0;

                type = type || 'success';
                messages = messages || [];

                if (!$messages.length) {
                    $messages = $('<div class="pum-form__messages">').hide();
                    switch (pum_sub_vars.message_position) {
                    case 'bottom':
                        $form.append($messages.addClass('pum-form__messages--bottom'));
                        break;
                    case 'top':
                        $form.prepend($messages.addClass('pum-form__messages--top'));
                        break;
                    }
                }

                if (['bottom', 'top'].indexOf(pum_sub_vars.message_position) >= 0) {
                    for (; messages.length > i; i++) {
                        this.add_message($messages, messages[i].message, type);
                    }
                } else {
                    /**
                     * Per Field Messaging
                     */
                    for (; messages.length > i; i++) {

                        if (messages[i].field !== undefined) {
                            this.add_field_error($form, messages[i]);
                        } else {
                            this.add_message($messages, messages[i].message, type);
                        }
                    }
                }

                if ($messages.is(':hidden') && $('.pum-form__message', $messages).length) {
                    $messages.slideDown();
                }
            },
            add_message: function ($container, message, type) {
                var $message = $('<p class="pum-form__message">').html(message);

                type = type || 'success';

                $message.addClass('pum-form__message--' + type);

                $container.append($message);

                if ($container.is(':visible')) {
                    $message.hide().slideDown();
                }
            },
            add_field_error: function ($form, error) {
                var $field   = $('[name="' + error.field + '"]', $form),
                    $wrapper = $field.parents('.pum-form__field').addClass('pum-form__field--error');

                this.add_message($wrapper, error.message, 'error');
            },
            clear_all: function ($form, hide) {
                var $messages = $form.find('.pum-form__messages'),
                    messages  = $messages.find('.pum-form__message'),
                    $errors   = $form.find('.pum-form__field.pum-form__field--error');

                hide = hide || false;

                // Remove forms main messages container.
                if ($messages.length) {
                    messages.slideUp('fast', function () {
                        $(this).remove();

                        if (hide) {
                            $messages.hide();
                        }
                    });

                }

                // Remove per field messages.
                if ($errors.length) {
                    $errors.removeClass('pum-form__field--error').find('p.pum-form__message').remove();
                }
            },
            scroll_to_first: function ($form) {
                scrollTo($('.pum-form__field.pum-form__field--error', $form).eq(0));
            }
        },
        form       = {
            validation: {
                errors: []
            },
            responseHandler: function ($form, response) {
                var data = response.data;

                if (response.success) {
                    /**
                     * If there are no errors process the successful submission.
                     */
                    form.success($form, data);
                } else {
                    /**
                     * Process any errors
                     */
                    form.errors($form, data);
                }
            },
            display_errors: function ($form, errors) {
                messages.add($form, errors || this.validation.errors, 'error');
            },
            beforeAjax: function ($form) {
                var $btn     = $form.find('[type="submit"]'),
                    $loading = $btn.find('.pum-form__loader');

                messages.clear_all($form);

                if (!$loading.length) {
                    $loading = $('<span class="pum-form__loader"></span>');
                    if ($btn.attr('value') !== '') {
                        $loading.insertAfter($btn);
                    } else {
                        $btn.append($loading);
                    }
                }

                $btn.prop('disabled', true);
                $loading.show();

                $form
                    .addClass('pum-form--loading')
                    .removeClass('pum-form--errors');
            },
            afterAjax: function ($form) {
                var $btn     = $form.find('[type="submit"]'),
                    $loading = $btn.find('.pum-form__loader');

                $btn.prop('disabled', false);
                $loading.hide();

                $form.removeClass('pum-form--loading');
            },
            success: function ($form, data) {
                if (data.message !== undefined && data.message !== '') {
                    messages.add($form, [{message: data.message}]);
                }

                $form
                    .trigger('success', [data])
                    .trigger('pumNewsletterSuccess', [data])
                    .addClass('pum-newsletter-success');

                $form[0].reset();

                window.pum.hooks.doAction('pum-sub-form.success', data, $form);

                if (!$form.data('noredirect') && data.redirect !== undefined && data.redirect) {
                    if (data.redirect !== '') {
                        window.location = data.redirect;
                    } else {
                        window.location.reload(true);
                    }
                }
            },
            errors: function ($form, data) {
                if (data.errors !== undefined && data.errors.length) {
                    console.log(data.errors);

                    form.display_errors($form, data.errors);

                    messages.scroll_to_first($form);

                    $form
                        .addClass('pum-form--errors')
                        .trigger('pumNewsletterError', [data])
                        .trigger('errors', [data]);

                    window.pum.hooks.doAction('pum-sub-form.errors', data, $form);
                }
            },
            submit: function (event) {
                var $form  = $(this),
                    values = $form.serializeObject();

                event.preventDefault();
                event.stopPropagation();

                form.beforeAjax($form);

                $.ajax({
                        type: 'POST',
                        dataType: 'json',
                        url: pum_sub_vars.ajaxurl,
                        data: {
                            action: 'pum_sub_form_submit',
                            values: values
                        }
                    })
                    .always(function () {
                        form.afterAjax($form);
                    })
                    .done(function (response) {
                        form.responseHandler($form, response);
                    })
                    .error(function (jqXHR, textStatus, errorThrown) {
                        console.log('Error: type of ' + textStatus + ' with message of ' + errorThrown);
                    });
            }
        },
        inputTypes = 'color,date,datetime,datetime-local,email,hidden,month,number,password,range,search,tel,text,time,url,week'.split(','),
        inputNodes = 'select,textarea'.split(','),
        rName      = /\[([^\]]*)\]/g;

    function scrollTo(target, callback) {
        var $target = $(target) || $();

        if (!$target.length) {
            return;
        }

        $('html, body').animate({
            scrollTop: $target.offset().top - 100
        }, 1000, 'swing', function () {
            // Find the first :input that isn't a button or hidden type.
            var $input = $target.find(':input:not([type="button"]):not([type="hidden"]):not(button)').eq(0);

            if ($input.hasClass('wp-editor-area')) {
                tinyMCE.execCommand('mceFocus', false, $input.attr('id'));
            } else {
                $input.focus();
            }

            if (typeof callback === 'function') {
                callback();
            }
        });
    }

    // ugly hack for IE7-8
    function isInArray(array, needle) {
        return $.inArray(needle, array) !== -1;
    }

    function storeValue(container, parsedName, value) {

        var part = parsedName[0];

        if (parsedName.length > 1) {
            if (!container[part]) {
                // If the next part is eq to '' it means we are processing complex name (i.e. `some[]`)
                // for this case we need to use Array instead of an Object for the index increment purpose
                container[part] = parsedName[1] ? {} : [];
            }
            storeValue(container[part], parsedName.slice(1), value);
        } else {

            // Increment Array index for `some[]` case
            if (!part) {
                part = container.length;
            }

            container[part] = value;
        }
    }

    function serializeObject(options) {
        $.extend({}, options);

        var values   = {},
            settings = $.extend(true, {
                include: [],
                exclude: [],
                includeByClass: ''
            }, options);

        this.find(':input').each(function () {

            var parsedName;

            // Apply simple checks and filters
            if (!this.name || this.disabled ||
                isInArray(settings.exclude, this.name) ||
                (settings.include.length && !isInArray(settings.include, this.name)) ||
                this.className.indexOf(settings.includeByClass) === -1) {
                return;
            }

            // Parse complex names
            // JS RegExp doesn't support "positive look behind" :( that's why so weird parsing is used
            parsedName = this.name.replace(rName, '[$1').split('[');
            if (!parsedName[0]) {
                return;
            }

            if (this.checked ||
                isInArray(inputTypes, this.type) ||
                isInArray(inputNodes, this.nodeName.toLowerCase())) {

                // Simulate control with a complex name (i.e. `some[]`)
                // as it handled in the same way as Checkboxes should
                if (this.type === 'checkbox') {
                    parsedName.push('');
                }

                // jQuery.val() is used to simplify of getting values
                // from the custom controls (which follow jQuery .val() API) and Multiple Select
                storeValue(values, parsedName, $(this).val());
            }
        });

        return values;
    }

    $.fn.serializeObject = serializeObject;


    // Deprecated
    PUMNewsletter = form;

    $(document)
        .ready(function () {
            $.fn.popmake.cookies = $.fn.popmake.cookies || {};

            $.extend($.fn.popmake.cookies, {
                pum_sub_form_success: function (settings) {
                    var $popup = PUM.getPopup(this);
                    $popup.find('form.pum-sub-form').on('success', function () {
                        $popup.popmake('setCookie', settings);
                    });
                },
                pum_sub_form_already_subscribed: function (settings) {
                    var $popup = PUM.getPopup(this);
                    $popup.find('form.pum-sub-form').on('success', function () {
                        $popup.popmake('setCookie', settings);
                    });
                }
            });
        })
        .on('submit', 'form.pum-sub-form', form.submit)
        .on('success', 'form.pum-sub-form', function (event) {
            var $form    = $(event.target),
                settings = $form.data('settings'),
                $popup   = $form.parents('.pum');

            if (!settings) {
                return;
            }

            settings = $.extend({
                openpopup: false,
                openpopup_id: 0,
                closepopup: false,
                closedelay: 0
            }, settings);

            if ($popup.length && settings.closepopup) {
                setTimeout(function () {
                    $popup.popmake('close');

                    // Trigger another if set up.
                    if (settings.openpopup && PUM.getPopup(settings.openpopup_id).length) {
                        PUM.open(settings.openpopup_id);
                    }
                }, parseInt(settings.closedelay) * 1000);
            } else if (settings.openpopup) {
                $popup = PUM.getPopup(settings.openpopup_id);

                if ($popup.length) {
                    $popup.popmake('open');
                }
            }
        });

}(jQuery));
