<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'pum_newsletter_autoloader' ) ) {
	/**
	 * Class Autoloader
	 *
	 * @param $class
	 */
	function pum_newsletter_autoloader( $class ) {

		// project-specific namespace prefix
		$prefix = 'PUM_Newsletter_';

		// base directory for the namespace prefix
		$base_dir = PUM_NEWSLETTER_PATH . 'classes/';

		// does the class use the namespace prefix?
		$len = strlen( $prefix );
		if ( strncmp( $prefix, $class, $len ) !== 0 ) {
			// no, move to the next registered autoloader
			return;
		}

		// get the relative class name
		$relative_class = substr( $class, $len );

		// replace the namespace prefix with the base directory, replace namespace
		// separators with directory separators in the relative class name, append
		// with .php
		$file = $base_dir . str_replace( '_', '/', $relative_class ) . '.php';

		// if the file exists, require it
		if ( file_exists( $file ) ) {
			require_once $file;
		}
	}
}

if ( ! function_exists( 'spl_autoload_register' ) ) {
	include 'compat.php';
}

spl_autoload_register( 'pum_newsletter_autoloader' ); // Register autoloader
