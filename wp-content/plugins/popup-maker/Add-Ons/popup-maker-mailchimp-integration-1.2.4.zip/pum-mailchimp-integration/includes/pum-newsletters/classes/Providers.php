<?php
/*******************************************************************************
 * Copyright (c) 2017, WP Popup Maker
 ******************************************************************************/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class PUM_Newsletter_Providers
 *
 * This class maintains a global set of all registered PUM newsletter providers.
 */
class PUM_Newsletter_Providers {

	/**
	 * @var PUM_Newsletter_Providers The one true PUM_Newsletter_Providers
	 */
	private static $instance;

	private $providers = array();

	/**
	 * Main PUM_Newsletter_Providers Instance
	 *
	 * @return PUM_Newsletter_Providers
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof self ) ) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	public function add_provider( PUM_Newsletter_Provider $provider ) {
		$this->providers[ $provider->id ] = $provider;
	}

	/**
	 * @return array PUM_Shortcode
	 */
	public function get_providers() {
		return $this->providers;
	}

	public static function selectlist() {
		$selectlist = array();

		foreach ( self::instance()->get_providers() as $id => $provider ) {
			$selectlist[ $provider->name ] = $id;
		}

		return $selectlist;
	}

}

