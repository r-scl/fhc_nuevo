/*******************************************************************************
 * Copyright (c) 2017, WP Popup Maker
 ******************************************************************************/
(function ($) {

    /**
     * Check API key when the "Check" button is clicked.
     */
    $(document)
        .on('click', 'button.pum-mci-check-api-key', function () {
            var $this = $(this),
                $icon = $this.find('i'),
                $keyField = $this.prev('input'),
                $nonceField = $this.next('input'),
                key = $keyField.val(),
                nonce = $nonceField.val();

            $this.attr('disabled', true);

            $icon
                .removeClass('dashicons-no')
                .removeClass('dashicons-yes')
                .addClass('dashicons-update spin')
                .show();

            $.ajax({
                method: 'POST',
                url: ajaxurl,
                data: {
                    action: 'pum_mci_check_api_key',
                    key: key,
                    nonce: nonce
                }
            }).done(function (response) {
                $this.attr('disabled', false);
                $icon.removeClass('dashicons-update spin');

                if (key === '') {
                    $icon.hide();
                }

                if (response.success) {
                    $icon.addClass('dashicons-yes');
                } else {
                    $icon.addClass('dashicons-no');
                }
            });
        })
        .on('focusout change', '[name="popmake_settings[mc_int_api_key]"]', function () {
            var $this = $(this),
                $button = $(this).next('button');

            if ($this.val() !== '') {
                $button.trigger('click');
            } else {
                $button.find('i').hide();
            }

        });


}(jQuery));
/*******************************************************************************
 * Copyright (c) 2017, WP Popup Maker
 ******************************************************************************/
(function ($) {

    function check_list() {
        var $list_id = $('#pum-shortcode-editor-pum_sub_form_provider_mailchimp #pum_shortcode_attrs_list_id'),
            list_id = $list_id.val(),
            $list_options = $('#pum-mci-list-' + list_id),
            $all_options = $('.pum-mci-list-options');

        $all_options.hide();
        $all_options.find('input[type="checkbox"]').attr('disabled', true);

        if ($list_options.length) {
            $list_options.show();
            $list_options.find('input[type="checkbox"]').attr('disabled', false);
        }
    }

    /**
     * Check API key when the "Check" button is clicked.
     */
    $(document)
        .on('pumInit pum_init', '#pum-shortcode-editor-pum_sub_form', check_list)
        .on('change', '#pum-shortcode-editor-pum_sub_form_provider_mailchimp #pum_shortcode_attrs_list_id', check_list);


}(jQuery));
/*******************************************************************************
 * Copyright (c) 2017, WP Popup Maker
 ******************************************************************************/
(function ($) {

    if (typeof window.pum_newsletter_initialized !== 'undefined') {
        return;
    }

    window.pum_newsletter_initialized = true;

    function check_provider() {
        var $provider = $('#pum-shortcode-editor-pum_sub_form #pum_shortcode_attrs_provider'),
            provider = $provider.val() !== 'none' ? $provider.val() : pum_newsletter_vars.default_provider,
            $provider_tabs = $('.pum-modal-content .tabs .tab a[href^="#pum-shortcode-editor-pum_sub_form_provider_"]'),
            $provider_contents = $('[id^="pum-shortcode-editor-pum_sub_form_provider_"]'),
            $selected_tab = $('.pum-modal-content .tabs .tab a[href="#pum-shortcode-editor-pum_sub_form_provider_' + provider + '"]'),
            $selected_contents = $('[id="pum-shortcode-editor-pum_sub_form_provider_' + provider + '"]');

        $provider_tabs.each(function() {
            console.log(this);
            $(this).parent().hide();
        });

        $provider_contents.find(':input').attr('disable', true);

        if ($selected_tab.length) {
            $selected_tab.parent().show();
            $selected_contents.find(':input').attr('disable', false);
        }
    }


    $(document)
        .on('pumInit pum_init', '#pum-shortcode-editor-pum_sub_form', check_provider)
        .on('change', '#pum-shortcode-editor-pum_sub_form #pum_shortcode_attrs_provider', check_provider);

}(jQuery));