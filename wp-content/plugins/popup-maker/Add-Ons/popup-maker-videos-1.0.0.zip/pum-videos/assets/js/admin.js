var PUM_SCH;
(function ($) {
    "use strict";

    var I10n = pum_admin.I10n,
        defaults = pum_admin.defaults,
        $schedule_table = $('#pum_popup_schedules_list');

    PUM_SCH = {
        init: function () {
            PUM_SCH.datetime();
        },
        datetime: function() {

            var $datetime = $('.pum-datetime:not(.initialized)'),
                $daterange = $('.pum-date-range:not(.initialized)'),
                $datetimerange = $('.pum-datetime-range:not(.initialized)');

            if ($datetime.length) {
                $datetime.addClass('initialize-datetime');
                flatpickr('.initialize-datetime', {
                    wrap: true,
                    enableTime: true
                });
                $datetime.removeClass('initialize-datetime').addClass('initialized');
            }

            if ($daterange.length) {
                $daterange.addClass('initialize-date-range');
                flatpickr('.initialize-date-range', {
                    wrap: true,
                    mode: "range"
                });
                $daterange.removeClass('initialize-date-range').addClass('initialized');
            }

            if ($datetimerange.length) {
                $datetimerange.addClass('initialize-datetime-range');
                flatpickr('.initialize-datetime-range', {
                    wrap: true,
                    enableTime: true,
                    mode: "range"
                });
                $datetimerange.removeClass('initialize-datetime-range').addClass('initialized');
            }
        },
        getLabel: function (type) {
            return I10n.labels.schedules[type].name;
        },
        getSettingsDesc: function (type, values) {
            var options = {
                    evaluate:    /<#([\s\S]+?)#>/g,
                    interpolate: /\{\{\{([\s\S]+?)\}\}\}/g,
                    escape:      /\{\{([^\}]+?)\}\}(?!\})/g,
                    variable:    'data'
                },
                template = _.template(I10n.labels.schedules[type].settings_column, null, options);
            values.I10n = I10n;
            return template(values);
        },
        renumber: function () {
            $schedule_table.find('tbody tr').each(function () {
                var $this = $(this),
                    index = $this.parent().children().index($this),
                    originalIndex = $this.data('index');

                $this.data('index', index);

                $this.find('[name]').each(function () {
                    var replace_with = "[" + index + "]";
                    this.name = this.name.replace("[" + originalIndex + "]", replace_with).replace("[]", replace_with);
                });
            });
        },
        refreshDescriptions: function () {
            $schedule_table.find('tbody tr').each(function () {
                var $row = $(this),
                    type = $row.find('.popup_schedules_field_type').val(),
                    values = JSON.parse($row.find('.popup_schedules_field_settings:first').val());

                $row.find('td.settings-column').html(PUM_SCH.getSettingsDesc(type, values));
            });
        },
        initEditForm: function () {

        }
    };

    $(document)
        .on('pum_init', PUM_SCH.init)
        .on('select2:select pumselect2:select', '#pum-first-schedule', function () {
            var $this = $(this),
                type = $this.val(),
                id = 'pum-schedule-settings-' + type,
                modalID = '#' + id.replace(/-/g,'_'),
                template = wp.template(id),
                data = {};

            data.schedule_settings = defaults.schedules[type] !== undefined ? defaults.schedules[type] : {};
            data.schedule_settings.name = 'pum-' + $('#post_ID').val();
            data.save_button_text = I10n.add;
            data.index = null;

            if (!template.length) {
                alert('Something went wrong. Please refresh and try again.');
            }

            PUMModals.reload(modalID, template(data));
            PUM_SCH.initEditForm();

            $this
                .val(null)
                .trigger('change');
        })
        .on('click', '#pum_popup_schedules .add-new', function () {
            var template = wp.template('pum-schedule-add-type');
            PUMModals.reload('#pum_schedule_add_type_modal', template());
        })
        .on('click', '#pum_popup_schedules_list .edit', function (e) {
            var $this = $(this),
                $row = $this.parents('tr:first'),
                type = $row.find('.popup_schedules_field_type').val(),
                id = 'pum-schedule-settings-' + type,
                modalID = '#' + id.replace(/-/g, '_'),
                template = wp.template(id),
                data = {
                    index: $row.parent().children().index($row),
                    type: type,
                    schedule_settings: JSON.parse($row.find('.popup_schedules_field_settings:first').val())
                };

            e.preventDefault();

            data.save_button_text = I10n.save;

            if (!template.length) {
                alert('Something went wrong. Please refresh and try again.');
            }

            PUMModals.reload(modalID, template(data));
            PUM_SCH.initEditForm();
        })
        .on('click', '#pum_popup_schedules_list .remove', function (e) {
            var $this = $(this),
                $row = $this.parents('tr:first');

            e.preventDefault();

            if (window.confirm(I10n.confirm_delete_schedule)) {
                $row.remove();

                if (!$schedule_table.find('tbody tr').length) {
                    $('#pum-first-schedule')
                        .val(null)
                        .trigger('change');

                    $('#pum_popup_schedule_fields').removeClass('has-schedules');
                }

                PUM_SCH.renumber();
            }
        })
        .on('submit', '#pum_schedule_add_type_modal .pum-form', function (e) {
            var type = $('#popup_schedule_add_type').val(),
                id = 'pum-schedule-settings-' + type,
                modalID = '#' + id.replace(/-/g,'_'),
                template = wp.template(id),
                data = {};

            e.preventDefault();

            data.schedule_settings = defaults.schedules[type] !== undefined ? defaults.schedules[type] : {};
            data.schedule_settings.name = 'pum-' + $('#post_ID').val();
            data.save_button_text = I10n.add;
            data.index = null;

            if (!template.length) {
                alert('Something went wrong. Please refresh and try again.');
            }

            PUMModals.reload(modalID, template(data));
            PUM_SCH.initEditForm();
        })
        .on('submit', '.schedule-editor .pum-form', function (e) {
            var $form = $(this),
                type = $form.find('input.type').val(),
                values = $form.pumSerializeObject(),
                index = parseInt(values.index),
                $row = index >= 0 ? $schedule_table.find('tbody tr').eq(index) : null,
                template = wp.template('pum-schedule-row'),
                $new_row,
                $trigger,
                trigger_settings;

            e.preventDefault();

            if (!index || index < 0) {
                values.index = $schedule_table.find('tbody tr').length;
            }

            values.I10n = I10n;

            $new_row = template(values);

            if (!$row) {
                $schedule_table.find('tbody').append($new_row);
            } else {
                $row.replaceWith($new_row);
            }

            PUMModals.closeAll();
            PUM_SCH.renumber();

            $('#pum_popup_schedule_fields').addClass('has-schedules');

            if (PUMTriggers.new_schedule >= 0) {
                $trigger = $('#pum_popup_triggers_list tbody tr').eq(PUMTriggers.new_schedule).find('.popup_triggers_field_settings:first');
                trigger_settings = JSON.parse($trigger.val());

                trigger_settings.schedule.name[trigger_settings.schedule.name.indexOf('add_new')] = values.schedule_settings.name;

                $trigger.val(JSON.stringify(trigger_settings));

                PUMTriggers.new_schedule = false;
                PUMTriggers.refreshDescriptions();
            }
        })
        .ready(function () {
            PUM_SCH.refreshDescriptions();
            $('#pum-first-schedule')
                .val(null)
                .trigger('change');
        });


}(jQuery));