/*******************************************************************************
 * Copyright (c) 2017, WP Popup Maker
 ******************************************************************************/
(function ($, document, undefined) {
    "use strict";

    $.extend($.fn.popmake.cookies, {
        video_played: function (settings) {
            var $popup = PUM.getPopup(this)
            $popup.one('video.play video.playing', function () {
                $popup.popmake('setCookie', settings);
            });
        },
        video_paused: function (settings) {
            var $popup = PUM.getPopup(this)
            $popup.one('video.pause', function () {
                $popup.popmake('setCookie', settings);
            });
        },
        video_ended: function (settings) {
            var $popup = PUM.getPopup(this)
            $popup.one('video.ended', function () {
                $popup.popmake('setCookie', settings);
            });
        }
    });

}(jQuery, document));
/*******************************************************************************
 * Copyright (c) 2017, WP Popup Maker
 ******************************************************************************/
(function ($) {
    "use strict";

    var plyr = window.plyr || {
                setup: function () {
                }
            },
        defaults = pum_vars.video_option_defaults;

    function init_player($popup) {
        var selector = '#' + $popup.attr('id') + ' .pum-video:first-child',
            player = plyr.setup(selector, {debug: pum_debug_mode});

        player[0]
            .on('ready', function (event) {
                $popup.trigger('video.ready', [event]);
            })
            .on('canplaythrough', function (event) {
                $popup.trigger('video.canplaythrough', [event]);
            })
            .on('ended', function (event) {
                $popup.trigger('video.ended', [event]);
            })
            .on('pause', function (event) {
                $popup.trigger('video.pause', [event]);
            })
            .on('play', function (event) {
                $popup.trigger('video.play', [event]);
            })
            .on('playing', function (event) {
                $popup.trigger('video.playing', [event]);
            })
            .on('progress', function (event) {
                $popup.trigger('video.progress', [event]);
            })
            .on('seeked', function (event) {
                $popup.trigger('video.seeked', [event]);
            })
            .on('seeking', function (event) {
                $popup.trigger('video.seeking', [event]);
            })
            .on('timeupdate', function (event) {
                $popup.trigger('video.timeupdate', [event]);
            })
            .on('volumechange', function (event) {
                $popup.trigger('video.volumechange', [event]);
            })
            .on('enterfullscreen', function (event) {
                $popup.trigger('video.enterfullscreen', [event]);
            })
            .on('exitfullscreen', function (event) {
                $popup.trigger('video.exitfullscreen', [event]);
            })
            .on('captionsenabled', function (event) {
                $popup.trigger('video.captionsenabled', [event]);
            })
            .on('captionsdisabled', function (event) {
                $popup.trigger('video.captionsdisabled', [event]);
            })
            .on('destroyed', function (event) {
                $popup.trigger('video.destroyed', [event]);
                // Automatic cleanup.
                $popup.data('player', false);
            });

        return player[0];
    }

    $(document)
        .on('pumInit', '.pum-has-videos', function () {
            var $popup = PUM.getPopup(this),
                player;

            if (!$popup.find('.pum-video:first').length) {
                return;
            }

            player = init_player($popup);

            $popup.data('player', player);
        })
        .on('pumBeforeOpen', '.pum-has-videos', function () {
            var $popup = PUM.getPopup(this),
                player = $popup.data('player'),
                seekto,
                play = function () {
                    switch (PUM.getSetting($popup, 'videos.on_open', 'resume')) {
                    case 'resume':
                    default:
                        seekto = parseFloat($popup.data('player-paused-at'));

                        if (seekto) {
                            player.seek(seekto);
                            $popup.data('player-paused-at', false);
                        }
                        break;
                    case 'rewind':
                        // Rewind to beginning.
                        player.restart();
                        break;

                    case 'seek':
                        seekto = parseFloat(PUM.getSetting($popup, 'videos.seektime', 0));
                        // Seek to specified time.
                        player.seek(seekto);
                        break;
                    }

                    // Play
                    player.play();
                };

            if (!player) {
                return;
            }

            if (PUM.getSetting($popup, 'videos.autoplay', false)) {
                if (player.isReady()) {
                    play();
                } else {
                    player.on('ready', function () {
                        play();
                    });
                }
            }

            // Go Fullscreen
            if (PUM.getSetting($popup, 'videos.fullscreen', false)) {
                player.toggleFullscreen();
            }
        })
        .on('pumBeforeClose', '.pum-has-videos', function () {
            var $popup = PUM.getPopup(this),
                player = $popup.data('player'),
                paused = false;

            if (!player) {
                return;
            }

            switch (PUM.getSetting($popup, 'videos.on_close', 'pause')) {
            case 'pause':
            default:
                player.pause();
                paused = player.getCurrentTime();
                break;
            case 'stop':
                player.stop();
                break;
            case 'destroy':
                player.destroy();
                break;
            }

            $popup.data('player-paused-at', paused);
        })
        .on('video.play video.progress', '.pum', function (event, player_event) {
            var $player = $(this).find('.plyr:first');

            if ($player.hasClass('plyr--stopped')) {
                $player
                    .addClass('plyr--playing')
                    .removeClass('plyr--stopped');
            }
        })
        .on('video.pause', '.pum', function (event, player_event) {
            var $player = $(this).find('.plyr:first');

            if (!$player.hasClass('plyr--stopped')) {
                $player
                    .addClass('plyr--stopped')
                    .removeClass('plyr--playing');
            }
        })
        .on('video.ended', '.pum', function (event, player_event) {
            // If close on finish is enabled close the popup.
            if (PUM.getSetting(this, 'videos.close_on_finish', false)) {
                PUM.close(this);
            }
        })
    ;


}(jQuery));