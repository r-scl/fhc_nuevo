<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Class PUM_Videos_Admin_Popup_Metabox_Video
 */
class PUM_Videos_Admin_Popup_Metabox_Video {

	/**
	 * Initialize the needed actions & filters.
	 */
	public static function init() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'register_metabox' ) );
		add_action( 'pum_save_popup', array( __CLASS__, 'save_popup' ) );
	}

	/**
	 * Register the metabox for popup post type.
	 *
	 * @return void
	 */
	public static function register_metabox() {
		add_meta_box( 'pum_popup_videos', __( 'Video Settings', 'pum-videos' ), array(
			__CLASS__,
			'render_metabox',
		), 'popup', 'normal', 'high' );
	}

	/**
	 * Display Metabox
	 *
	 * @return void
	 */
	public static function render_metabox() {
		global $post;

		$pum_videos = PUM_Videos_Popup::get_video_settings( $post->ID );

		$pum_videos = PUM_Videos_Popup::parse_video_settings( ! $pum_videos ? array() : $pum_videos );

		?>

		<div id="pum_popup_video_fields" class="pum_meta_table_wrap  popmake_meta_table_wrap tabbed-form">
			<p>
				<strong><?php _e( 'These settings control how videos work inside the popup.', 'pum-videos' ); ?></strong>
			</p>

			<div class="field pum-field  pum-field-autoplay  pum-field-checkbox">
				<label for="pum_videos_autoplay"><?php _e( 'Start video when popup opens.', 'pum-videos' ); ?></label>
				<input type="checkbox" id="pum_videos_autoplay" name="pum_videos[autoplay]" value="1" <?php checked( 1, $pum_videos['autoplay'] ); ?> />
				<p class="pum-desc"><?php _e( 'This will cause any video in the popup to start playing immediately after opening.', 'pum-videos' ); ?></p>
			</div>

			<div class="field pum-field  pum-field-fullscreen  pum-field-checkbox">
				<label for="pum_videos_fullscreen"><?php _e( 'Automatically go fullscreen when video starts playing.', 'pum-videos' ); ?></label>
				<input type="checkbox" id="pum_videos_fullscreen" name="pum_videos[fullscreen]" value="1" <?php checked( 1, $pum_videos['fullscreen'] ); ?> />
				<p class="pum-desc"><?php _e( 'Note: This only works with click triggers.', 'pum-videos' ); ?></p>
			</div>


			<div class="field pum-field  pum-field-close_on_finish  pum-field-checkbox">
				<label for="pum_videos_close_on_finish"><?php _e( 'Close popup when video ends.', 'pum-videos' ); ?></label>
				<input type="checkbox" id="pum_videos_close_on_finish" name="pum_videos[close_on_finish]" value="1" <?php checked( 1, $pum_videos['close_on_finish'] ); ?> />
				<p class="pum-desc"><?php _e( 'This will cause the popup to close when a video within the popup finishes.', 'pum-videos' ); ?></p>
			</div>

			<div class="field pum-field  pum-field-on_open  pum-field-radio">
				<label for="pum_videos_on_open"><?php _e( 'When the popup is opened:', 'pum-videos' ); ?></label>

				<input type="radio" id="pum_videos_on_open_resume" name="pum_videos[on_open]" value="resume" <?php checked( 'resume', $pum_videos['on_open'] ); ?> />
				<label for="pum_videos_on_open_resume"><?php _e( 'Resume the video if it was previously paused', 'pum-videos' ); ?></label><br/>

				<input type="radio" id="pum_videos_on_open_rewind" name="pum_videos[on_open]" value="rewind" <?php checked( 'rewind', $pum_videos['on_open'] ); ?> />
				<label for="pum_videos_on_open_rewind"><?php _e( 'Rewind the video to the beginning', 'pum-videos' ); ?></label><br/>

				<input type="radio" id="pum_videos_on_open_seek" name="pum_videos[on_open]" value="seek" <?php checked( 'seek', $pum_videos['on_open'] ); ?> />
				<label for="pum_videos_on_open_seek"><?php _e( 'Seek to a specific time in the video', 'pum-videos' ); ?></label><br/>

				<p class="pum-desc"><?php _e( 'This will determine how the video acts when the popup opens.', 'pum-videos' ); ?></p>
			</div>

			<div class="field pum-field  pum-field-seektime  pum-field-number">
				<label for="pum_videos_seektime"><?php _e( 'Time to skip to on open.', 'pum-videos' ); ?></label>
				<input type="number" class="normal-text" id="pum_videos_seektime" name="pum_videos[seektime]" value="<?php esc_attr_e( $pum_videos['seektime'] ); ?>" />
				<p class="pum-desc"><?php _e( 'Enter the time you want to skip to in seconds.', 'pum-videos' ); ?></p>
			</div>

			<div class="field pum-field  pum-field-on_close  pum-field-radio">
				<label for="pum_videos_on_close"><?php _e( 'When the popup is closed:', 'pum-videos' ); ?></label>

				<input type="radio" id="pum_videos_on_close_pause" name="pum_videos[on_close]" value="pause" <?php checked( 'pause', $pum_videos['on_close'] ); ?> />
				<label for="pum_videos_on_close_pause"><?php _e( 'Pause the video for easy resuming', 'pum-videos' ); ?></label><br/>

				<input type="radio" id="pum_videos_on_close_stop" name="pum_videos[on_close]" value="stop" <?php checked( 'stop', $pum_videos['on_close'] ); ?> />
				<label for="pum_videos_on_close_stop"><?php _e( 'Stop the video which resets to the beginning', 'pum-videos' ); ?></label><br/>

				<input type="radio" id="pum_videos_on_close_destroy" name="pum_videos[on_close]" value="destroy" <?php checked( 'destroy', $pum_videos['on_close'] ); ?> />
				<label for="pum_videos_on_close_destroy"><?php _e( 'Destroy the video player, generally not recommeneded', 'pum-videos' ); ?></label><br/>

				<p class="pum-desc"><?php _e( 'This will determine how the video acts when the popup closes.', 'pum-videos' ); ?></p>
			</div>

		</div>

		<script type="text/javascript">
			(function ($) {
				function update_seek_to() {
					var $val = $('input[name="pum_videos[on_open]"]:checked').val(),
						seek_to = $('.pum-field-seektime');

					if ($val === 'seek') {
						seek_to.slideDown('fast');
					} else {
						seek_to.slideUp('fast');
					}
				}

				function update_fullscreen() {
					var $fullscreen = $('.pum-field-fullscreen');

					if ($('#pum_videos_autoplay').is(':checked')) {
						$fullscreen.slideDown('fast');
					} else {
						$fullscreen.slideUp('fast');
					}

				}

				update_seek_to();
				update_fullscreen();

				$(document)
					.on('change click', 'input[name="pum_videos[on_open]"]', update_seek_to)
					.on('click', '#pum_videos_autoplay', update_fullscreen)
			}(jQuery));

		</script>
		<?php
	}

	public static function save_popup( $post_id ) {
		if ( ! empty ( $_POST['pum_videos'] ) ) {
			$pum_videos = PUM_Videos_Popup::parse_video_settings( $_POST['pum_videos'] );

			update_post_meta( $post_id, 'pum_videos', $pum_videos );
		} else {
			delete_post_meta( $post_id, 'pum_videos' );
		}
	}
}
