<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Class class PUM_Videos_Admin_Assets {

 */
class PUM_Videos_Admin_Assets {

	/**
	 * Initialization
	 */
	public static function init() {
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'scripts_styles' ) );
		add_filter( 'pum_admin_var', array( __CLASS__, 'admin_vars' ) );
	}

	/**
	 * Enqueue the site scripts.
	 */
	public static function scripts_styles() {
		// Use minified libraries if SCRIPT_DEBUG is turned off
		$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';

		if ( popmake_is_admin_page() ) {
			wp_enqueue_style( 'flatpickr', PUM_SCH::$URL . 'assets/css/flatpickr' . $suffix . '.css', null, '2.2.4' );
			wp_enqueue_script( 'flatpickr', PUM_SCH::$URL . 'assets/js/flatpickr' . $suffix . '.js', null, '2.2.4', true );
			wp_enqueue_style( 'pum-sch-admin', PUM_SCH::$URL . 'assets/css/admin' . $suffix . '.css', null, PUM_SCH::$VER );
			wp_enqueue_script( 'pum-sch-admin', PUM_SCH::$URL . 'assets/js/admin' . $suffix . '.js', array( 'popup-maker-admin' ), PUM_SCH::$VER, true );
		}
	}

	public static function admin_vars( $vars ) {

		$vars['defaults']['schedules'] = PUM_Videos_Schedules::instance()->get_defaults();
		$vars['I10n']['labels']['schedules'] = PUM_Videos_Schedules::instance()->get_labels();
		$vars['I10n']['confirm_delete_schedule'] = __( "Are you sure you want to delete this schedule?", 'pum-schedules' );

		return $vars;
	}

}