<?php
/*******************************************************************************
 * Copyright (c) 2017, WP Popup Maker
 ******************************************************************************/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class PUM_Videos_Cookies {

	public static function init() {
		add_action( 'pum_get_cookies', array( __CLASS__, 'register' ) );
	}

	/**
	 * Registers the cookies.
	 *
	 * @param array $cookies
	 *
	 * @return array
	 */
	public static function register( $cookies = array() ) {
		return array_merge( $cookies, array(
			'video_played'             => array(
				'labels' => array(
					'name' => __( 'Video Played', 'pum-videos' ),
				),
				'fields' => pum_get_cookie_fields(),
			),
			'video_paused'  => array(
				'labels' => array(
					'name' => __( 'Video Paused', 'pum-videos' ),
				),
				'fields' => pum_get_cookie_fields(),
			),
			'video_ended' => array(
				'labels' => array(
					'name' => __( 'Video Ended', 'pum-videos' ),
				),
				'fields' => pum_get_cookie_fields(),
			),
		) );
	}
}
