<?php
/*******************************************************************************
 * Copyright (c) 2017, WP Popup Maker
 ******************************************************************************/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class PUM_Videos_Video
 */
class PUM_Videos_Popup {

	/**
	 * Checks if content contains an embeddable video url.
	 *
	 * @param $popup_id
	 *
	 * @return bool
	 *
	 */
	public static function test_for_embeds( $popup_id ) {
		global $wp_embed;

		static $checked = array();

		if ( ! array_key_exists( $popup_id, $checked ) ) {
			$popup = pum_popup( $popup_id );

			if ( empty( $popup->post_content ) ) {
				return false;
			}

			$content = $wp_embed->autoembed( $popup->post_content );

			// Initially tests for shortcodes that would default this to true.
			$tests = array(
				has_shortcode( $content, 'pum_video' ),
				has_shortcode( $content, 'video' ),
			);

			if ( in_array( true, $tests ) ) {
				// Short circuit to prevent unneeded regex processing.
				$checked[ $popup_id ] = true;

				return true;
			}

			// Get embedded media.
			$medias = get_media_embedded_in_content( $content, array( 'audio', 'video', 'iframe' ) );

			if ( count( $medias ) ) {
				// Regex wrapper strings.
				$reg1 = '#src="(https?:\/\/';
				$reg2 = ')#im';

				// Patterns to check for.
				$patterns = array(
					'youtube' => $reg1 . '(?:www\.)?(?:youtube\.com\/|youtu\.be\/)[^\s<>"]+' . $reg2,
					'vimeo'   => $reg1 . '(.+\.)?vimeo\.com\/[^\s<>"]+' . $reg2,
				);

				// Check each media for enabled types.
				foreach ( $medias as $media ) {

					// Used to determine if any match was found. Only one match needed.
					$match = false;

					foreach ( $patterns as $pattern ) {

						$match = 1 === preg_match( $pattern, $media );

						if ( $match ) {
							// Prevent more regex matches.
							break;
						}
					}


					if ( $match ) {
						// Prevent more regex matches.
						$tests[] = true;
						break;
					}
				}
			}


			$checked[ $popup_id ] = in_array( true, $tests );
		}

		return $checked[ $popup_id ];
	}


	public static function get_video_settings( $popup_id ) {
		$video_settings = get_post_meta( $popup_id, 'pum_videos', true );

		return $video_settings ? self::parse_video_settings( $video_settings ) : false;
	}

	public static function parse_video_settings( $settings ) {
		return wp_parse_args( $settings, array(
			'autoplay'        => false,
			'fullscreen'      => false,
			'close_on_finish' => false,
			'on_open'         => 'resume',
			'seektime'        => 0,
			'on_close'        => 'pause',
		) );
	}
}
