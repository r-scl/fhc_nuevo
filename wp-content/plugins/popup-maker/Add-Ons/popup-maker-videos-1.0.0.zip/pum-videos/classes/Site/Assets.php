<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Class PUM_Videos_Site_Assets
 */
class PUM_Videos_Site_Assets {

	/**
	 * Initialization
	 */
	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'scripts_styles' ) );
		add_filter( 'pum_vars', array( __CLASS__, 'site_vars' ) );
		add_filter( 'popmake_enqueue_scripts', array( __CLASS__, 'conditionally_load_assets' ), 10, 2 );
		add_filter( 'popmake_enqueue_styles', array( __CLASS__, 'conditionally_load_assets' ), 10, 2 );
	}

	/**
	 * Enqueue the site scripts.
	 */
	public static function scripts_styles() {
		// Use minified libraries if SCRIPT_DEBUG is turned off
		$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';

		wp_register_style( 'pum-videos', PUM_Videos::$URL . 'assets/css/site' . $suffix . '.css', array(), PUM_Videos::$VER, 'all' );

		wp_register_script( 'plyr', PUM_Videos::$URL . 'assets/js/plyr' . $suffix . '.js', null, PUM_Videos::$VER, false );
		wp_enqueue_script( 'pum-videos', PUM_Videos::$URL . 'assets/js/site' . $suffix . '.js?defer', array(
			'popup-maker-site',
			'plyr',
		), PUM_Videos::$VER, true );
	}

	/**
	 * Checks popup content for embedded videos and automatically loads the needed assets.
	 *
	 * @param array $assets
	 * @param null $popup_id
	 *
	 * @return array
	 */
	public static function conditionally_load_assets( $assets = array(), $popup_id = null ) {
		if ( PUM_Videos_Popup::test_for_embeds( $popup_id ) ) {
			$assets['pum-videos'] = 'pum-videos';
		}

		return $assets;
	}

	public static function site_vars( $vars ) {
		$vars['video_option_defaults'] = PUM_Videos_Popup::parse_video_settings( array() );

		return $vars;
	}

}
