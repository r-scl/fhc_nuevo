<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PUM_SCH Site class
 */
class PUM_Videos_Site_Popups {

	/**
	 * Initialize Hooks & Filters
	 */
	public static function init() {
		add_filter( 'pum_popup_get_data_attr', array( __CLASS__, 'data_attr' ), 10, 2 );
		add_filter( 'pum_popup_get_classes', array( __CLASS__, 'classes' ), 10, 2 );
	}

	public static function data_attr( $data, $popup_id ) {

		$videos = PUM_Videos_Popup::get_video_settings( $popup_id );

		if ( $videos && PUM_Videos_Popup::test_for_embeds( $popup_id ) ) {
			$data['videos'] = $videos;
		}

		return $data;
	}

	public static function classes( $classes, $popup_id ) {

		if ( PUM_Videos_Popup::test_for_embeds( $popup_id ) ) {
			$classes['overlay'][] = 'pum-has-videos';
		}

		return $classes;
	}


}
