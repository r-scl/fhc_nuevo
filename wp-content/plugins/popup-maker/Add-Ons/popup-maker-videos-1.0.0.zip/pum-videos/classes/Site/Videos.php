<?php

// Exit if accessed directly

/*******************************************************************************
 * Copyright (c) 2017, WP Popup Maker
 ******************************************************************************/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PUM_Videos_Site_Videos Site class
 */
class PUM_Videos_Site_Videos {

	static $was_enqueued = false;

	static $filter_1 = false;


	/**
	 * Initialize Hooks & Filters
	 */
	public static function init() {
		add_filter( 'pum_popup_content', array( __CLASS__, 'toggle_core_video_scripts' ), 0 );
		add_filter( 'pum_popup_content', array( __CLASS__, 'toggle_core_video_scripts' ), 999 );
		add_filter( 'wp_video_shortcode_class', array( __CLASS__, 'video_shortcode_class' ), 999 );
		add_filter( 'shortcode_atts_video', array( __CLASS__, 'video_shortcode_atts' ) );
		add_filter( 'wp_video_shortcode', array( __CLASS__, 'video_shortcode' ) );
	}


	/**
	 * Removes unneeded enqueued script & style, but only if it was enqueued in the popups content.
	 *
	 * @param $content
	 *
	 * @return mixed
	 */
	public static function toggle_core_video_scripts( $content ) {

		if ( ! self::$filter_1 ) {
			self::$filter_1     = true;
			self::$was_enqueued = wp_script_is( 'wp-mediaelement', 'enqueued' );
		} else {
			self::$filter_1 = false;
			if ( self::$was_enqueued ) {
				wp_enqueue_script( 'wp-mediaelement' );
				wp_enqueue_style( 'wp-mediaelement' );
			} else {
				wp_dequeue_script( 'wp-mediaelement' );
				wp_dequeue_style( 'wp-mediaelement' );
			}
		}

		return $content;

	}

	/**
	 * Adds the pum-video class to the outermost wrapper.
	 *
	 * @param string $output
	 *
	 * @return mixed|string
	 */
	public static function video_shortcode( $output = '' ) {
		if ( ! doing_filter( 'pum_popup_content' ) ) {
			return $output;
		}

		return str_replace( 'class="wp-video"', 'class="wp-video  pum-video"', $output );
	}

	/**
	 * Removes the width to prevent it from being undersized in a popup.
	 *
	 * Plyr styling handles the responsive video sizing.
	 *
	 * @param array $atts
	 *
	 * @return array
	 */
	public static function video_shortcode_atts( $atts = array() ) {
		if ( ! doing_filter( 'pum_popup_content' ) ) {
			return $atts;
		}

		$atts['width'] = false;

		return $atts;
	}

	/**
	 * Remove the wp-video-shortcode class that causes videos to be instantiated.
	 *
	 * @param string $class
	 *
	 * @return mixed|string
	 */
	public static function video_shortcode_class( $class = '' ) {
		if ( ! doing_filter( 'pum_popup_content' ) ) {
			return $class;
		}

		return str_replace( 'wp-video-shortcode', '', $class );;
	}

	public static function data_attr( $data, $popup_id ) {

		$videos = PUM_Videos_Popup::get_video_settings( $popup_id );

		if ( $videos && PUM_Videos_Popup::test_for_embeds( $popup_id ) ) {
			$data['videos'] = $videos;
		}

		return $data;
	}

	public static function classes( $classes, $popup_id ) {

		if ( PUM_Videos_Popup::test_for_embeds( $popup_id ) ) {
			$classes['overlay'][] = 'pum-has-videos';
		}

		return $classes;
	}


}
