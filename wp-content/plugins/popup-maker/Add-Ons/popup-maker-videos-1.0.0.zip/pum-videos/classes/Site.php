<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * PUM_SCH Site class
 */
class PUM_Videos_Site {

	/**
	 * Initialize Hooks & Filters
	 */
	public static function init() {
		PUM_Videos_Site_Popups::init();
		PUM_Videos_Site_Videos::init();
		PUM_Videos_Site_Assets::init();
		add_filter( 'embed_oembed_html', array( __CLASS__, 'convert_videos' ), 20, 4 );
		add_filter( 'embed_oembed_cache', array( __CLASS__, 'convert_videos' ), 20, 4 );
	}

	/**
	 * Convert normal youtube & vimeo embeds to pum-videos.
	 *
	 * @param $html
	 * @param $url
	 * @param $attr
	 * @param $post_ID
	 *
	 * @return bool|string
	 */
	public static function convert_videos( $html, $url, $attr, $post_ID ) {

		if ( ! doing_filter( 'pum_popup_content' ) ) {
			return $html;
		}

		$args = array();
		include_once ABSPATH . WPINC . '/class-oembed.php';

		$wp_oembed = new WP_oEmbed();

		$provider = $wp_oembed->get_provider( $url );

		if ( ! $provider || false === $data = $wp_oembed->fetch( $provider, $url, $args ) ) {
			return false;
		}

		if ( 'video' !== $data->type ) {
			return $html;
		}

		if ( ! in_array( $data->provider_name, array( 'Vimeo', 'YouTube' ) ) ) {
			return $html;
		}

		if ( $data->provider_name == 'YouTube' ) {
			$splode = array_reverse( explode( '/', $data->thumbnail_url ) );

			$video_id = $splode[1];
		} else {
			$video_id = $data->video_id;
		}

		return '<div class="pum-video" data-type="' . strtolower( $data->provider_name ) . '" data-video-id="' . $video_id . '"></div>';
	}

}
