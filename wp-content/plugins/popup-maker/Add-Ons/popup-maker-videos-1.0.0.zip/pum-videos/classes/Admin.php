<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PUM_SCH Site class
 */
class PUM_Videos_Admin {

	/**
	 * Initialize Hooks & Filters
	 */
	public static function init() {
		//PUM_Videos_Admin_Assets::init();
		PUM_Videos_Admin_Popup_Metabox_Video::init();
	}

}
