<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class PUM_Shortcode_Popup_Close
 *
 * Registers the pum_video shortcode.
 */
class PUM_Videos_Shortcode_Video extends PUM_Shortcode {

	public $has_content = false;

	/**
	 * The shortcode tag.
	 */
	public function tag() {
		return 'pum_video';
	}

	public function label() {
		return __( 'Video', 'pum-videos' );
	}

	public function description() {
		return __( 'Insert a responsive video.', 'pum-videos' );
	}

	public function post_types() {
		return array( 'popup' );
	}

	public function fields() {
		return array(
			'options' => array(
				'video_type'     => array(
					'label'    => __( 'Video Type', 'pum-videos' ),
					'type'     => 'select',
					'std'      => 'youtube',
					'priority' => 10,
					'required' => true,
					'options'  => array(
						__( 'Youtube', 'pum-videos' ) => 'youtube',
					),
				),
				'video_id' => array(
					'label'       => __( 'Video ID', 'pum-videos' ),
					'placeholder' => __( 'Video ID', 'pum-videos' ),
					'type'        => 'text',
					'desc'        => __( 'Add additional classes for styling.', 'pum-videos' ),
					'priority'    => 15,
				),
			),
		);
	}


	/**
	 * @return array
	 */
	public function defaults() {
		return array(
			'video_type'     => '',
			'video_id' => '',
		);
	}

	/**
	 * Shortcode handler
	 *
	 * @param  array $atts shortcode attributes
	 * @param  string $content shortcode content
	 *
	 * @return string
	 */
	public function handler( $atts, $content = null ) {
		$atts = $this->shortcode_atts( $atts );

		return '<div class="pum-video" data-type="' . $atts['video_type'] . '" data-video-id="' . $atts['video_id'] . '"></div>';
	}

	public function _template() { ?>
		<script type="text/html" id="tmpl-pum-shortcode-view-pum_video">
			{{attr.type}}: {{attr.video_id}}
		</script><?php
	}

}

