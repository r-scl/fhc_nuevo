<?php
/**
 * Plugin Name: Popup Maker - Videos
 * Plugin URI: https://wppopupmaker.com/extensions/videos/
 * Description: Adds advanced video features to Popup Maker popups.
 * Author: WP Popup Maker
 * Version: 1.0.0
 * Author URI: https://wppopupmaker.com/
 * Text Domain: pum-videos
 * GitLab Plugin URI: https://gitlab.com/PopupMaker/pum-videos
 * GitHub Branch:     master
 *
 * @author       WP Popup Maker
 * @copyright    Copyright (c) 2017, WP Popup Maker
 */


// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Autoloader
 *
 * @param $class
 */
function pum_vid_autoloader( $class ) {

	// project-specific namespace prefix
	$prefix = 'PUM_Videos_';

	// base directory for the namespace prefix
	$base_dir = __DIR__ . '/classes/';

	// does the class use the namespace prefix?
	$len = strlen( $prefix );
	if ( strncmp( $prefix, $class, $len ) !== 0 ) {
		// no, move to the next registered autoloader
		return;
	}

	// get the relative class name
	$relative_class = substr( $class, $len );

	// replace the namespace prefix with the base directory, replace namespace
	// separators with directory separators in the relative class name, append
	// with .php
	$file = $base_dir . str_replace( '_', '/', $relative_class ) . '.php';

	// if the file exists, require it
	if ( file_exists( $file ) ) {
		require_once $file;
	}

}

if ( ! function_exists( 'spl_autoload_register' ) ) {
	include 'includes/compat.php';
}

spl_autoload_register( 'pum_vid_autoloader' ); // Register autoloader

/**
 * Class PUM_Videos
 */
class PUM_Videos {

	/**
	 * @var string
	 */
	public static $NAME = 'Videos';

	/**
	 * @var string
	 */
	public static $VER = '1.0.0';

	/**
	 * @var int DB Version
	 */
	public static $DB_VER = 1;

	/**
	 * @var string
	 */
	public static $URL = '';

	/**
	 * @var string
	 */
	public static $DIR = '';

	/**
	 * @var string
	 */
	public static $FILE = '';

	/**
	 * @var         PUM_Videos $instance The one true PUM_Videos
	 */
	private static $instance;

	/**
	 * Get active instance
	 *
	 * @return      object self::$instance The one true PUM_Videos
	 */
	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self;
			self::$instance->setup_constants();

			self::$instance->load_textdomain();

			self::$instance->includes();
			self::$instance->init();
		}

		return self::$instance;
	}

	/**
	 * Setup plugin constants
	 *
	 * @access      private
	 * @since       1.2.0
	 * @return      void
	 */
	private function setup_constants() {
		self::$DIR  = self::$instance->plugin_path();
		self::$URL  = self::$instance->plugin_url();
		self::$FILE = __FILE__;
		self::$NAME = __( 'Videos', 'pum-videos' );
	}

	/**
	 * Include necessary files
	 */
	private function includes() {

	}

	/**
	 * Initialize everything
	 *
	 * @return      void
	 */
	private function init() {

		PUM_Videos_Site::init();
		PUM_Videos_Admin::init();
		PUM_Videos_Cookies::init();

		// Register Shortcodes
		new PUM_Videos_Shortcode_Video;

		// Handle licensing
		if ( class_exists( 'PUM_Extension_License' ) ) {
			new PUM_Extension_License( self::$FILE, self::$NAME, self::$VER, 'WP Popup Maker' );
		}
	}

	/**
	 * Get the plugin path.
	 * @return string
	 */
	public function plugin_path() {
		return plugin_dir_path( __FILE__ );
	}

	/**
	 * Get the plugin url.
	 * @return string
	 */
	public function plugin_url() {
		return plugins_url( '/', __FILE__ );
	}

	/**
	 * Internationalization
	 */
	public function load_textdomain() {
		load_plugin_textdomain( 'pum-videos', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
	}

	/**
	 * Get Ajax URL.
	 * @return string
	 */
	public function ajax_url() {
		return admin_url( 'admin-ajax.php', 'relative' );
	}

}

/**
 * Get the ball rolling. Fire up the correct version.
 */
function pum_vid_init() {
	if ( ! class_exists( 'Popup_Maker' ) && ! class_exists( 'PUM' ) ) {
		if ( ! class_exists( 'PUM_Extension_Activation' ) ) {
			require_once 'includes/pum-sdk/class-pum-extension-activation.php';
		}

		$activation = new PUM_Extension_Activation( plugin_dir_path( __FILE__ ), basename( __FILE__ ) );
		$activation->run();
	} else {
		PUM_Videos::instance();
	}
}
add_action( 'plugins_loaded', 'pum_vid_init' );
