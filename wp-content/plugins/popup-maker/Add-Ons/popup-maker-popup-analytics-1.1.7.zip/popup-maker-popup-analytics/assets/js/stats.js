(function ($) {
    "use strict";



    
}(jQuery));