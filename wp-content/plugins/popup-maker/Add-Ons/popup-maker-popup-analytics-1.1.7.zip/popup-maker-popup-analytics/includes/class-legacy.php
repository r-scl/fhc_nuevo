<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Main PopMake_Popup_Analytics_Legacy class
 *
 * @since       1.0.0
 */
class PopMake_Popup_Analytics_Legacy {

	public function __construct() {
		add_action( 'init', array( $this, 'setup_post_types' ), 1 );
	}


	public function setup_post_types() {
		register_post_type( 'popup_analytic_event', array(
			'public'          => false,
			'rewrite'         => false,
			'capability_type' => 'post',
			'query_var'       => false,
			'supports'        => array(
				'title',
				'editor',
			),
		) );
	}
}
